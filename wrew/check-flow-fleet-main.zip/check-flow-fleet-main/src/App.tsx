import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Link } from "react-router-dom";
import { AppProvider, useApp } from "./contexts/AppContext";
import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";
import OperatorChat from "./pages/OperatorChat";
import VehicleManagement from "./components/VehicleManagement";
import OperatorManagement from "./components/OperatorManagement";
import ChecklistManagement from "./pages/ChecklistManagement";
import TravelGuideManagement from "./pages/TravelGuideManagement";
import Reports from "./pages/Reports";
import OccurrenceManagement from "./pages/OccurrenceManagement";
import FileHeader from "./pages/FileHeader";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

// Componente temporário para páginas em desenvolvimento
const ComingSoon = ({ title }: { title: string }) => (
  <div className="min-h-screen bg-gradient-to-br from-primary/10 via-background to-info/10 flex items-center justify-center">
    <div className="text-center">
      <h1 className="text-3xl font-bold text-foreground mb-4">{title}</h1>
      <p className="text-muted-foreground mb-6">Esta página está em desenvolvimento</p>
      <Link to="/" className="text-primary hover:underline">Voltar ao Dashboard</Link>
    </div>
  </div>
);

const AppContent = () => {
  const { state } = useApp();

  if (!state.user) {
    return <Login />;
  }

  if (state.user.type === 'operator') {
    return <OperatorChat />;
  }

  return (
    <Routes>
      <Route path="/" element={<Dashboard />} />
      <Route path="/vehicles" element={<VehicleManagement />} />
      <Route path="/operators" element={<OperatorManagement />} />
      <Route path="/checklists" element={<ChecklistManagement />} />
      <Route path="/travel-guides" element={<TravelGuideManagement />} />
      <Route path="/reports" element={<Reports />} />
      <Route path="/occurrences" element={<OccurrenceManagement />} />
      <Route path="/header" element={<FileHeader />} />
      <Route path="*" element={<NotFound />} />
    </Routes>
  );
};

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <AppProvider>
        <BrowserRouter>
          <AppContent />
        </BrowserRouter>
      </AppProvider>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;

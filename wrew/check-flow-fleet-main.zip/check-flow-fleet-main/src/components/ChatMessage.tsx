import { useEffect, useState } from 'react';
import { Check, Clock, User, Bot, AlertCircle, Image } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

interface ChatMessageProps {
  message: {
    id: string;
    type: 'bot' | 'user' | 'system';
    content: string;
    timestamp: Date;
    options?: string[];
    requiresPhoto?: boolean;
    isLoading?: boolean;
    status?: 'pending' | 'completed' | 'error';
    photoUrl?: string;
  };
  onOptionClick?: (option: string) => void;
  onPhotoCapture?: () => void;
  isLatest?: boolean;
  showTimestamp?: boolean;
}

export const ChatMessage = ({ 
  message, 
  onOptionClick, 
  onPhotoCapture,
  isLatest = false,
  showTimestamp = true
}: ChatMessageProps) => {
  const [isVisible, setIsVisible] = useState(false);
  const [showOptions, setShowOptions] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsVisible(true);
      if (message.options) {
        setTimeout(() => setShowOptions(true), 200);
      }
    }, 50);
    return () => clearTimeout(timer);
  }, [message.options]);

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('pt-BR', { 
      hour: '2-digit', 
      minute: '2-digit' 
    });
  };

  const getStatusIcon = () => {
    switch (message.status) {
      case 'completed':
        return <Check className="w-3 h-3 text-success" />;
      case 'error':
        return <AlertCircle className="w-3 h-3 text-destructive" />;
      default:
        return <Clock className="w-3 h-3 text-muted-foreground" />;
    }
  };

  const getMessageAnimation = () => {
    if (message.type === 'bot') {
      return 'animate-slide-in-left';
    }
    return 'animate-slide-in-right';
  };

  return (
    <div 
      className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'} mb-4 
        transition-all duration-300 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-2'}`}
    >
      <div className={`flex items-start gap-3 max-w-[85%] ${message.type === 'user' ? 'flex-row-reverse' : ''}`}>
        {/* Avatar */}
        <div className={`
          flex items-center justify-center w-8 h-8 rounded-full flex-shrink-0
          ${message.type === 'bot' ? 'bg-primary' : 'bg-secondary'}
          ${isLatest ? 'animate-pulse-ring' : ''}
        `}>
          {message.type === 'bot' ? (
            <Bot className="w-4 h-4 text-primary-foreground" />
          ) : (
            <User className="w-4 h-4 text-secondary-foreground" />
          )}
        </div>

        {/* Message Content */}
        <div className={`flex flex-col ${message.type === 'user' ? 'items-end' : 'items-start'}`}>
          {/* Main Message */}
          <div
            className={`
              px-4 py-3 rounded-2xl shadow-sm transition-all duration-300 hover:shadow-md
              ${message.type === 'bot' 
                ? 'bg-card text-card-foreground border border-border' 
                : 'bg-primary text-primary-foreground'
              }
              ${isVisible ? getMessageAnimation() : ''}
              ${message.isLoading ? 'animate-pulse' : ''}
            `}
          >
            <p className="text-sm leading-relaxed whitespace-pre-wrap">
              {message.content}
            </p>

            {/* Photo Preview */}
            {message.photoUrl && (
              <div className="mt-2 animate-fade-in">
                <img 
                  src={message.photoUrl} 
                  alt="Foto capturada" 
                  className="w-24 h-24 object-cover rounded-lg border-2 border-primary/20 cursor-pointer hover:scale-105 transition-transform"
                  onClick={() => window.open(message.photoUrl, '_blank')}
                />
              </div>
            )}

            {/* Photo Capture Button */}
            {message.requiresPhoto && onPhotoCapture && (
              <div className="mt-3 animate-fade-in-up">
                <Button
                  size="sm"
                  onClick={onPhotoCapture}
                  className="flex items-center gap-2 bg-secondary hover:bg-secondary/90"
                >
                  <Image className="w-4 h-4" />
                  Tirar Foto
                </Button>
              </div>
            )}
          </div>

          {/* Options */}
          {message.options && showOptions && (
            <div className="mt-3 flex flex-wrap gap-2 animate-fade-in-up">
              {message.options.map((option, index) => (
                <Button
                  key={`${message.id}-option-${index}`}
                  variant={option === 'NÃO CONFORME' ? 'destructive' : 'outline'}
                  size="sm"
                  onClick={() => onOptionClick?.(option)}
                  className="text-xs transition-all duration-200 hover:scale-105 animate-bounce-in"
                  style={{ animationDelay: `${index * 100}ms` }}
                >
                  {option}
                </Button>
              ))}
            </div>
          )}

          {/* Message Footer */}
          <div className={`
            flex items-center gap-2 mt-2 text-xs text-muted-foreground
            ${message.type === 'user' ? 'flex-row-reverse' : ''}
          `}>
            {showTimestamp && (
              <span className="opacity-70">
                {formatTime(message.timestamp)}
              </span>
            )}
            
            {message.type === 'user' && (
              <div className="flex items-center gap-1">
                {getStatusIcon()}
                <Badge variant="secondary" className="text-xs">
                  {message.status === 'completed' ? 'Enviado' : 
                   message.status === 'error' ? 'Erro' : 'Enviando'}
                </Badge>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ChatMessage;
import { useState, useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger,
  DialogFooter,
  DialogDescription
} from '@/components/ui/dialog';
import { useApp } from '@/contexts/AppContext';
import AdminLayout from '@/components/AdminLayout';
import { 
  Users, 
  Plus, 
  Edit, 
  Trash2, 
  Camera,
  Calendar,
  User,
  TrendingUp,
  IdCard,
  Briefcase,
  Search
} from 'lucide-react';
import { toast } from '@/hooks/use-toast';
import { selectImage, capturePhoto } from '@/utils/imageUpload';

const OperatorManagement = () => {
  const { state, dispatch } = useApp();
  const [editingOperator, setEditingOperator] = useState<any>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [formData, setFormData] = useState({
    name: '',
    cpf: '',
    cnh: '',
    role: '',
    photo: '/placeholder.svg'
  });


  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (editingOperator) {
      dispatch({
        type: 'UPDATE_OPERATOR',
        payload: {
          ...editingOperator,
          ...formData
        }
      });
      toast({
        title: "Operador atualizado",
        description: "As informações do operador foram atualizadas com sucesso.",
      });
    } else {
      dispatch({
        type: 'ADD_OPERATOR',
        payload: {
          id: Date.now().toString(),
          ...formData,
          inspectionsCount: 0,
          createdAt: new Date().toISOString()
        }
      });
      toast({
        title: "Operador cadastrado",
        description: "O operador foi cadastrado com sucesso.",
      });
    }
    
    resetForm();
    setIsDialogOpen(false);
  };

  const handleEdit = (operator: any) => {
    setEditingOperator(operator);
    setFormData({
      name: operator.name,
      cpf: operator.cpf,
      cnh: operator.cnh,
      role: operator.role,
      photo: operator.photo
    });
    setIsDialogOpen(true);
  };

  const handleDelete = (operatorId: string) => {
    if (window.confirm('Tem certeza que deseja excluir este operador?')) {
      dispatch({ type: 'DELETE_OPERATOR', payload: operatorId });
      toast({
        title: "Operador removido",
        description: "O operador foi removido com sucesso.",
        variant: "destructive"
      });
    }
  };

  const resetForm = () => {
    setEditingOperator(null);
    setFormData({
      name: '',
      cpf: '',
      cnh: '',
      role: '',
      photo: '/placeholder.svg'
    });
  };

  const handleAddPhoto = async () => {
    try {
      const result = await selectImage();
      setFormData(prev => ({ ...prev, photo: result.url }));
      toast({
        title: "Foto adicionada",
        description: "A foto do operador foi carregada com sucesso.",
      });
    } catch (error) {
      toast({
        title: "Erro ao carregar foto",
        description: error instanceof Error ? error.message : "Erro desconhecido",
        variant: "destructive"
      });
    }
  };

  const handleCapturePhoto = async () => {
    try {
      const result = await capturePhoto();
      setFormData(prev => ({ ...prev, photo: result.url }));
      toast({
        title: "Foto capturada",
        description: "A foto do operador foi capturada com sucesso.",
      });
    } catch (error) {
      toast({
        title: "Erro ao capturar foto",
        description: error instanceof Error ? error.message : "Erro desconhecido",
        variant: "destructive"
      });
    }
  };

  const formatCPF = (cpf: string) => {
    return cpf.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, '$1.$2.$3-$4');
  };

  // Filtrar operadores
  const filteredOperators = useMemo(() => {
    return state.operators.filter(operator => {
      const searchLower = searchTerm.toLowerCase();
      return (
        operator.name.toLowerCase().includes(searchLower) ||
        operator.cpf.includes(searchTerm) ||
        operator.cnh.includes(searchTerm) ||
        operator.role.toLowerCase().includes(searchLower)
      );
    });
  }, [state.operators, searchTerm]);

  return (
    <AdminLayout currentPage="operators">
      <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-gradient-primary rounded-lg">
            <Users className="w-6 h-6 text-white" />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-foreground">Gestão de Operadores</h2>
            <p className="text-sm text-muted-foreground">
              Gerencie a equipe de operadores da empresa
            </p>
          </div>
        </div>
        
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-gradient-primary hover:opacity-90 flex items-center gap-2">
              <Plus className="w-4 h-4" />
              Novo Operador
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[425px]">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <Users className="w-5 h-5 text-primary" />
                {editingOperator ? 'Editar Operador' : 'Novo Operador'}
              </DialogTitle>
              <DialogDescription>
                {editingOperator ? 'Atualize as informações do operador selecionado.' : 'Cadastre um novo operador na equipe.'}
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="name">Nome Completo *</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                  placeholder="Ex: João Silva Santos"
                  required
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="cpf">CPF *</Label>
                <Input
                  id="cpf"
                  value={formData.cpf}
                  onChange={(e) => setFormData(prev => ({ ...prev, cpf: e.target.value }))}
                  placeholder="000.000.000-00"
                  required
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="cnh">CNH *</Label>
                <Input
                  id="cnh"
                  value={formData.cnh}
                  onChange={(e) => setFormData(prev => ({ ...prev, cnh: e.target.value }))}
                  placeholder="00000000000"
                  required
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="role">Função *</Label>
                <Input
                  id="role"
                  value={formData.role}
                  onChange={(e) => setFormData(prev => ({ ...prev, role: e.target.value }))}
                  placeholder="Ex: Motorista, Operador, Mecânico..."
                  required
                />
              </div>
              
              <div className="space-y-2">
                <Label>Foto do Operador *</Label>
                <div className="flex items-center gap-4">
                  <img 
                    src={formData.photo} 
                    alt="Foto do operador"
                    className="w-16 h-16 object-cover rounded-full border"
                  />
                  <div className="flex gap-2">
                    <Button 
                      type="button" 
                      variant="outline" 
                      onClick={handleAddPhoto}
                      className="flex items-center gap-2"
                    >
                      <Camera className="w-4 h-4" />
                      Galeria
                    </Button>
                    <Button 
                      type="button" 
                      variant="outline" 
                      onClick={handleCapturePhoto}
                      className="flex items-center gap-2"
                    >
                      <Camera className="w-4 h-4" />
                      Câmera
                    </Button>
                  </div>
                </div>
              </div>
              
              <DialogFooter>
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => {
                    resetForm();
                    setIsDialogOpen(false);
                  }}
                >
                  Cancelar
                </Button>
                <Button type="submit" className="bg-gradient-primary hover:opacity-90">
                  {editingOperator ? 'Atualizar' : 'Cadastrar'}
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Barra de Pesquisa */}
      <Card className="shadow-card bg-gradient-card">
        <CardContent className="p-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
            <Input
              placeholder="Pesquisar por nome, CPF, CNH ou função..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </CardContent>
      </Card>

      {/* Operators Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredOperators.map((operator) => (
          <Card key={operator.id} className="shadow-card bg-gradient-card">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <Badge variant="outline" className="bg-primary/10 text-primary">
                  {operator.role}
                </Badge>
                <div className="flex items-center gap-2">
                  <Button 
                    variant="ghost" 
                    size="sm"
                    onClick={() => handleEdit(operator)}
                    className="hover:bg-primary/10"
                  >
                    <Edit className="w-4 h-4" />
                  </Button>
                  <Button 
                    variant="ghost" 
                    size="sm"
                    onClick={() => handleDelete(operator.id)}
                    className="hover:bg-destructive/10 hover:text-destructive"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-center">
                  <img 
                    src={operator.photo} 
                    alt={operator.name}
                    className="w-20 h-20 object-cover rounded-full border-2 border-primary/20"
                  />
                </div>
                
                <div className="space-y-2 text-center">
                  <h3 className="font-medium text-lg">{operator.name}</h3>
                  
                  <div className="flex items-center justify-center gap-2 text-sm">
                    <TrendingUp className="w-4 h-4 text-success" />
                    <span className="text-success font-medium">
                      {operator.inspectionsCount} inspeções
                    </span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredOperators.length === 0 && (
        <Card className="shadow-card bg-gradient-card">
          <CardContent className="py-12 text-center">
            {state.operators.length === 0 ? (
              <>
                <Users className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-medium text-foreground mb-2">
                  Nenhum operador cadastrado
                </h3>
                <p className="text-muted-foreground mb-4">
                  Comece adicionando o primeiro operador da equipe
                </p>
                <Button 
                  onClick={() => setIsDialogOpen(true)}
                  className="bg-gradient-primary hover:opacity-90"
                >
                  Adicionar Primeiro Operador
                </Button>
              </>
            ) : (
              <>
                <Search className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-medium text-foreground mb-2">
                  Nenhum operador encontrado
                </h3>
                <p className="text-muted-foreground mb-4">
                  Tente ajustar os termos de pesquisa
                </p>
                <Button 
                  variant="outline"
                  onClick={() => setSearchTerm('')}
                >
                  Limpar Pesquisa
                </Button>
              </>
            )}
          </CardContent>
        </Card>
      )}
      </div>
    </AdminLayout>
  );
};

export default OperatorManagement;
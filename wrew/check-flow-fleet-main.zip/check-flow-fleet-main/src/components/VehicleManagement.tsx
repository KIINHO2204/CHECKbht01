import { useState, memo, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger,
  DialogFooter,
  DialogDescription
} from '@/components/ui/dialog';
import { useApp } from '@/contexts/AppContext';
import AdminLayout from '@/components/AdminLayout';
import { validatePlate, formatPlate } from '@/utils/validators';
import { useDebounce } from '@/hooks/useDebounce';
import { 
  Car, 
  Plus, 
  Edit, 
  Trash2, 
  Camera,
  Calendar,
  Truck,
  Search,
  Filter,
  Download,
  AlertCircle
} from 'lucide-react';
import { toast } from '@/hooks/use-toast';
import { selectImage, capturePhoto } from '@/utils/imageUpload';

const VehicleCard = memo(({ vehicle, onEdit, onDelete }: {
  vehicle: any;
  onEdit: (vehicle: any) => void;
  onDelete: (id: string) => void;
}) => (
  <Card className="shadow-card bg-gradient-card hover:shadow-elevated transition-all duration-200 hover:scale-105">
    <CardHeader className="pb-3">
      <div className="flex items-center justify-between">
        <Badge variant="outline" className="bg-primary/10 text-primary">
          {vehicle.category}
        </Badge>
        <div className="flex items-center gap-2">
          <Button 
            variant="ghost" 
            size="sm"
            onClick={() => onEdit(vehicle)}
            className="hover:bg-primary/10 hover:scale-110 transition-all"
            aria-label={`Editar veículo ${vehicle.plate}`}
          >
            <Edit className="w-4 h-4" />
          </Button>
          <Button 
            variant="ghost" 
            size="sm"
            onClick={() => onDelete(vehicle.id)}
            className="hover:bg-destructive/10 hover:text-destructive hover:scale-110 transition-all"
            aria-label={`Excluir veículo ${vehicle.plate}`}
          >
            <Trash2 className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </CardHeader>
    <CardContent>
      <div className="space-y-4">
        <div className="flex items-center justify-center">
          <img 
            src={vehicle.photo} 
            alt={`${vehicle.model}`}
            className="w-full h-32 object-cover rounded-md border hover:scale-105 transition-transform cursor-pointer"
            loading="lazy"
          />
        </div>
        
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <span className="font-medium text-lg">{vehicle.plate}</span>
            <Badge variant="secondary" className="text-xs">
              {vehicle.currentKm?.toLocaleString() || 0} km
            </Badge>
          </div>
          
          <p className="font-medium text-foreground">{vehicle.model}</p>
        </div>
      </div>
    </CardContent>
  </Card>
));

VehicleCard.displayName = 'VehicleCard';

const VehicleManagement = memo(() => {
  const { state, addVehicle, updateVehicle, deleteVehicle } = useApp();
  const [editingVehicle, setEditingVehicle] = useState<any>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState('all');
  const [formData, setFormData] = useState({
    plate: '',
    category: '',
    checklistId: '',
    model: '',
    photo: '/placeholder.svg',
    currentKm: 0
  });
  const [formErrors, setFormErrors] = useState<Record<string, string>>({});
  const [isLoading, setIsLoading] = useState(false);

  const debouncedSearchTerm = useDebounce(searchTerm, 300);

  // Obter categorias dos checklists disponíveis
  const availableCategories = state.checklists.map(checklist => ({
    id: checklist.id,
    name: checklist.name
  }));

  const validateForm = useCallback(() => {
    const errors: Record<string, string> = {};
    
    if (!formData.plate.trim()) {
      errors.plate = 'Placa é obrigatória';
    } else if (!validatePlate(formData.plate)) {
      errors.plate = 'Formato de placa inválido (ex: ABC-1234)';
    }
    
    if (!formData.category.trim()) {
      errors.category = 'Categoria é obrigatória';
    }
    
    if (!formData.model.trim()) {
      errors.model = 'Modelo é obrigatório';
    }
    
    if (formData.currentKm < 0) {
      errors.currentKm = 'KM deve ser um valor positivo';
    }
    
    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  }, [formData]);

  const handleSubmit = useCallback(async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) return;
    
    setIsLoading(true);
    
    try {
      const vehicleData = {
        ...formData,
        plate: formatPlate(formData.plate)
      };
      
      if (editingVehicle) {
        updateVehicle({ ...editingVehicle, ...vehicleData });
        toast({
          title: "Veículo atualizado",
          description: "As informações do veículo foram atualizadas com sucesso.",
        });
      } else {
        addVehicle(vehicleData);
        toast({
          title: "Veículo cadastrado",
          description: "O veículo foi cadastrado com sucesso.",
        });
      }
      
      resetForm();
      setIsDialogOpen(false);
    } catch (error) {
      toast({
        title: "Erro",
        description: "Ocorreu um erro ao salvar o veículo. Tente novamente.",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  }, [formData, editingVehicle, validateForm, addVehicle, updateVehicle]);

  const handleEdit = useCallback((vehicle: any) => {
    setEditingVehicle(vehicle);
    setFormData({
      plate: vehicle.plate,
      category: vehicle.category,
      checklistId: vehicle.checklistId,
      model: vehicle.model,
      photo: vehicle.photo,
      currentKm: vehicle.currentKm
    });
    setFormErrors({});
    setIsDialogOpen(true);
  }, []);

  const handleDelete = useCallback((vehicleId: string) => {
    const vehicle = state.vehicles.find(v => v.id === vehicleId);
    if (window.confirm(`Tem certeza que deseja excluir o veículo ${vehicle?.plate}?`)) {
      deleteVehicle(vehicleId);
      toast({
        title: "Veículo removido",
        description: "O veículo foi removido com sucesso.",
      });
    }
  }, [state.vehicles, deleteVehicle]);

  const resetForm = useCallback(() => {
    setEditingVehicle(null);
    setFormData({
      plate: '',
      category: '',
      checklistId: '',
      model: '',
      photo: '/placeholder.svg',
      currentKm: 0
    });
    setFormErrors({});
  }, []);

  const handleAddPhoto = useCallback(async () => {
    try {
      const result = await selectImage();
      setFormData(prev => ({ ...prev, photo: result.url }));
      toast({
        title: "Foto adicionada",
        description: "A foto do veículo foi carregada com sucesso.",
      });
    } catch (error) {
      toast({
        title: "Erro ao carregar foto",
        description: error instanceof Error ? error.message : "Erro desconhecido",
        variant: "destructive"
      });
    }
  }, []);

  const handleCapturePhoto = useCallback(async () => {
    try {
      const result = await capturePhoto();
      setFormData(prev => ({ ...prev, photo: result.url }));
      toast({
        title: "Foto capturada",
        description: "A foto do veículo foi capturada com sucesso.",
      });
    } catch (error) {
      toast({
        title: "Erro ao capturar foto",
        description: error instanceof Error ? error.message : "Erro desconhecido",
        variant: "destructive"
      });
    }
  }, []);

  const handleExport = useCallback(() => {
    // Implementar exportação de dados
    toast({
      title: "Exportação iniciada",
      description: "Os dados dos veículos estão sendo exportados.",
    });
  }, []);

  const filteredVehicles = state.vehicles.filter(vehicle => {
    const matchesSearch = vehicle.plate.toLowerCase().includes(debouncedSearchTerm.toLowerCase()) ||
                         vehicle.model.toLowerCase().includes(debouncedSearchTerm.toLowerCase());
    const matchesFilter = filterType === 'all' || vehicle.category === filterType;
    return matchesSearch && matchesFilter;
  });

  return (
    <AdminLayout currentPage="vehicles">
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-gradient-primary rounded-lg">
              <Car className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2 className="text-2xl font-bold text-foreground">Gestão de Veículos</h2>
              <p className="text-sm text-muted-foreground">
                Gerencie a frota de veículos da empresa ({state.vehicles.length} veículos)
              </p>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              onClick={handleExport}
              className="flex items-center gap-2"
            >
              <Download className="w-4 h-4" />
              Exportar
            </Button>
            
            <Dialog 
              open={isDialogOpen} 
              onOpenChange={(open) => {
                setIsDialogOpen(open);
                if (!open) resetForm();
              }}
            >
              <DialogTrigger asChild>
                <Button className="bg-gradient-primary hover:opacity-90 flex items-center gap-2">
                  <Plus className="w-4 h-4" />
                  Novo Veículo
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[425px]">
                <DialogHeader>
                  <DialogTitle className="flex items-center gap-2">
                    <Car className="w-5 h-5 text-primary" />
                    {editingVehicle ? 'Editar Veículo' : 'Novo Veículo'}
                  </DialogTitle>
                  <DialogDescription>
                    {editingVehicle ? 'Atualize as informações do veículo selecionado.' : 'Cadastre um novo veículo na frota da empresa.'}
                  </DialogDescription>
                </DialogHeader>
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="plate">Placa *</Label>
                    <Input
                      id="plate"
                      value={formData.plate}
                      onChange={(e) => setFormData(prev => ({ ...prev, plate: e.target.value }))}
                      placeholder="ABC-1234"
                      className={formErrors.plate ? 'border-destructive' : ''}
                      disabled={isLoading}
                    />
                    {formErrors.plate && (
                      <div className="flex items-center gap-2 text-sm text-destructive">
                        <AlertCircle className="w-4 h-4" />
                        {formErrors.plate}
                      </div>
                    )}
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="category">Categoria *</Label>
                    <select
                      id="category"
                      value={formData.checklistId}
                      onChange={(e) => {
                        const selectedChecklist = state.checklists.find(c => c.id === e.target.value);
                        setFormData(prev => ({ 
                          ...prev, 
                          checklistId: e.target.value,
                          category: selectedChecklist?.name || ''
                        }));
                      }}
                      className={`w-full p-2 border rounded-md bg-background ${
                        formErrors.category ? 'border-destructive' : 'border-input'
                      }`}
                      disabled={isLoading}
                    >
                      <option value="">Selecione a categoria</option>
                      {availableCategories.map(category => (
                        <option key={category.id} value={category.id}>{category.name}</option>
                      ))}
                    </select>
                    {formErrors.category && (
                      <div className="flex items-center gap-2 text-sm text-destructive">
                        <AlertCircle className="w-4 h-4" />
                        {formErrors.category}
                      </div>
                    )}
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="model">Modelo *</Label>
                    <Input
                      id="model"
                      value={formData.model}
                      onChange={(e) => setFormData(prev => ({ ...prev, model: e.target.value }))}
                      placeholder="Ex: Volvo FH 540"
                      className={formErrors.model ? 'border-destructive' : ''}
                      disabled={isLoading}
                    />
                    {formErrors.model && (
                      <div className="flex items-center gap-2 text-sm text-destructive">
                        <AlertCircle className="w-4 h-4" />
                        {formErrors.model}
                      </div>
                    )}
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="currentKm">KM Atual *</Label>
                    <Input
                      id="currentKm"
                      type="number"
                      value={formData.currentKm}
                      onChange={(e) => setFormData(prev => ({ ...prev, currentKm: parseInt(e.target.value) || 0 }))}
                      placeholder="Ex: 150000"
                      className={formErrors.currentKm ? 'border-destructive' : ''}
                      disabled={isLoading}
                      min="0"
                    />
                    {formErrors.currentKm && (
                      <div className="flex items-center gap-2 text-sm text-destructive">
                        <AlertCircle className="w-4 h-4" />
                        {formErrors.currentKm}
                      </div>
                    )}
                  </div>
                  
                  <div className="space-y-2">
                    <Label>Foto do Veículo *</Label>
                    <div className="flex items-center gap-4">
                      <img 
                        src={formData.photo} 
                        alt="Foto do veículo"
                        className="w-16 h-16 object-cover rounded-md border"
                      />
                      <div className="flex gap-2">
                        <Button 
                          type="button" 
                          variant="outline" 
                          onClick={handleAddPhoto}
                          className="flex items-center gap-2"
                          disabled={isLoading}
                        >
                          <Camera className="w-4 h-4" />
                          Galeria
                        </Button>
                        <Button 
                          type="button" 
                          variant="outline" 
                          onClick={handleCapturePhoto}
                          className="flex items-center gap-2"
                          disabled={isLoading}
                        >
                          <Camera className="w-4 h-4" />
                          Câmera
                        </Button>
                      </div>
                    </div>
                  </div>
                  
                  <DialogFooter>
                    <Button 
                      type="button" 
                      variant="outline" 
                      onClick={() => setIsDialogOpen(false)}
                      disabled={isLoading}
                    >
                      Cancelar
                    </Button>
                    <Button 
                      type="submit" 
                      className="bg-gradient-primary hover:opacity-90"
                      disabled={isLoading}
                    >
                      {isLoading ? 'Salvando...' : (editingVehicle ? 'Atualizar' : 'Cadastrar')}
                    </Button>
                  </DialogFooter>
                </form>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        {/* Filters */}
        <Card className="shadow-card bg-gradient-card">
          <CardContent className="p-4">
            <div className="flex flex-col sm:flex-row gap-4">
              <div className="flex-1">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
                  <Input
                    placeholder="Buscar por placa ou modelo..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Filter className="w-4 h-4 text-muted-foreground" />
                <select
                  value={filterType}
                  onChange={(e) => setFilterType(e.target.value)}
                  className="px-3 py-2 border border-input rounded-md bg-background text-sm"
                >
                  <option value="all">Todas as categorias</option>
                  {availableCategories.map(category => (
                    <option key={category.id} value={category.name}>{category.name}</option>
                  ))}
                </select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Vehicles Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredVehicles.map((vehicle) => (
            <VehicleCard
              key={vehicle.id}
              vehicle={vehicle}
              onEdit={handleEdit}
              onDelete={handleDelete}
            />
          ))}
        </div>

        {filteredVehicles.length === 0 && (
          <Card className="shadow-card bg-gradient-card">
            <CardContent className="py-12 text-center">
              {debouncedSearchTerm || filterType !== 'all' ? (
                <>
                  <Search className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-foreground mb-2">
                    Nenhum veículo encontrado
                  </h3>
                  <p className="text-muted-foreground mb-4">
                    Tente ajustar os filtros de busca
                  </p>
                  <Button 
                    variant="outline"
                    onClick={() => {
                      setSearchTerm('');
                      setFilterType('all');
                    }}
                  >
                    Limpar filtros
                  </Button>
                </>
              ) : (
                <>
                  <Car className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-foreground mb-2">
                    Nenhum veículo cadastrado
                  </h3>
                  <p className="text-muted-foreground mb-4">
                    Comece adicionando o primeiro veículo da frota
                  </p>
                  <Button 
                    onClick={() => setIsDialogOpen(true)}
                    className="bg-gradient-primary hover:opacity-90"
                  >
                    Adicionar Primeiro Veículo
                  </Button>
                </>
              )}
            </CardContent>
          </Card>
        )}
      </div>
    </AdminLayout>
  );
});

VehicleManagement.displayName = 'VehicleManagement';

export default VehicleManagement;
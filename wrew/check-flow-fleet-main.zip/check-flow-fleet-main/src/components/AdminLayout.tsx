import { ReactNode, memo, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useApp } from '@/contexts/AppContext';
import { Link, useLocation } from 'react-router-dom';
import { ThemeToggle } from '@/components/ThemeToggle';
import { 
  Truck, 
  LogOut, 
  Home,
  Car,
  Users,
  ClipboardList,
  FileText,
  AlertTriangle,
  Settings,
  Bell,
  Activity,
  BarChart3,
  Menu,
  X,
  ChevronLeft,
  ChevronRight
} from 'lucide-react';

interface AdminLayoutProps {
  children: ReactNode;
  currentPage?: string;
}

const AdminLayout = memo(({ children, currentPage = 'dashboard' }: AdminLayoutProps) => {
  const { dispatch, state, pendingOccurrences } = useApp();
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const location = useLocation();
  const currentPath = location.pathname;

  const handleLogout = () => {
    dispatch({ type: 'SET_USER', payload: null });
  };

  const navigation = [
    { name: 'Dashboard', href: '/', icon: Home, badge: null, description: 'Visão geral do sistema' },
    { name: 'Veículos', href: '/vehicles', icon: Car, badge: state.vehicles.length, description: 'Gerenciar frota' },
    { name: 'Operadores', href: '/operators', icon: Users, badge: state.operators.length, description: 'Gerenciar equipe' },
    { name: 'Check-lists', href: '/checklists', icon: ClipboardList, badge: state.checklists.length, description: 'Gerenciar listas de verificação' },
    { name: 'Guia de Marcha', href: '/travel-guides', icon: Truck, badge: null, description: 'Controle de operações' },
    { name: 'Relatórios', href: '/reports', icon: BarChart3, badge: state.checklistResults.length, description: 'Análises e exportações' },
    { name: 'Ocorrências', href: '/occurrences', icon: AlertTriangle, badge: pendingOccurrences > 0 ? pendingOccurrences : null, urgent: pendingOccurrences > 0, description: 'Monitorar problemas' },
    { name: 'Configurações', href: '/header', icon: Settings, badge: null, description: 'Configurar sistema' },
  ];

  const isActive = (path: string) => currentPath === path;
  const totalAlerts = pendingOccurrences;

  return (
    <div className="min-h-screen flex w-full bg-gradient-to-br from-primary/5 via-background to-accent/5">
      {/* Enhanced Sidebar */}
      <aside className={`
        ${sidebarCollapsed ? 'w-16' : 'w-72'} 
        bg-card border-r shadow-lg transition-all duration-300 ease-in-out relative
        flex flex-col
      `}>
        {/* Sidebar Header */}
        <div className="p-4 border-b bg-gradient-to-r from-primary/5 to-primary/10">
          <div className="flex items-center justify-between">
            {!sidebarCollapsed && (
              <div className="flex items-center gap-3">
                <div className="p-2 bg-gradient-to-r from-primary to-primary/80 rounded-xl shadow-lg">
                  <Truck className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h2 className="font-bold text-foreground">Admin Panel</h2>
                  <p className="text-xs text-muted-foreground">Sistema de Gestão</p>
                </div>
              </div>
            )}
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setSidebarCollapsed(!sidebarCollapsed)}
              className="hover:bg-accent"
            >
              {sidebarCollapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
            </Button>
          </div>
        </div>

        {/* Navigation */}
        <nav className="flex-1 p-4 space-y-2">
          {navigation.map((item) => (
            <Link
              key={item.name}
              to={item.href}
              className={`
                group flex items-center gap-3 px-3 py-3 rounded-xl transition-all duration-200
                ${isActive(item.href) 
                  ? 'bg-primary text-primary-foreground shadow-md transform scale-[1.02]' 
                  : 'hover:bg-accent hover:text-accent-foreground hover:shadow-sm hover:scale-[1.01]'
                }
                ${item.urgent ? 'animate-pulse ring-2 ring-destructive/30' : ''}
              `}
              title={sidebarCollapsed ? item.name : item.description}
            >
              <div className="relative">
                <item.icon className="h-5 w-5 flex-shrink-0" />
                {item.urgent && (
                  <div className="absolute -top-1 -right-1 w-2 h-2 bg-destructive rounded-full animate-ping" />
                )}
              </div>
              
              {!sidebarCollapsed && (
                <div className="flex items-center justify-between w-full min-w-0">
                  <div className="flex flex-col min-w-0">
                    <span className="font-medium truncate">{item.name}</span>
                    <span className="text-xs opacity-75 truncate">{item.description}</span>
                  </div>
                  {item.badge && (
                    <Badge 
                      variant={item.urgent ? "destructive" : "secondary"} 
                      className="ml-2 flex-shrink-0 text-xs px-2 py-1"
                    >
                      {item.badge}
                    </Badge>
                  )}
                </div>
              )}
            </Link>
          ))}
        </nav>

        {/* Sidebar Footer */}
        <div className="p-4 border-t bg-muted/30">
          {!sidebarCollapsed ? (
            <div className="space-y-2">
              <div className="text-xs text-muted-foreground">Status do Sistema</div>
              <div className="flex items-center gap-2 text-sm">
                <div className="w-2 h-2 bg-success rounded-full animate-pulse" />
                <span className="text-success">Online</span>
              </div>
            </div>
          ) : (
            <div className="flex justify-center">
              <div className="w-2 h-2 bg-success rounded-full animate-pulse" />
            </div>
          )}
        </div>
      </aside>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Enhanced Header */}
        <header className="bg-card/95 backdrop-blur-sm border-b shadow-sm sticky top-0 z-40">
          <div className="flex items-center justify-between px-6 py-4">
            <div className="flex items-center gap-4 min-w-0">
              <Link to="/" className="flex items-center gap-3 hover:opacity-80 transition-opacity min-w-0">
                <div className="p-2 bg-gradient-to-r from-primary to-primary/80 rounded-xl shadow-lg flex-shrink-0">
                  <Truck className="w-6 h-6 text-white" />
                </div>
                <div className="min-w-0">
                  <h1 className="text-xl font-bold text-foreground truncate">CheckList Veicular</h1>
                  <p className="text-xs text-muted-foreground">Sistema Administrativo</p>
                </div>
              </Link>
            </div>

            <div className="flex items-center gap-3 flex-shrink-0">
              {/* Real-time Notifications */}
              <div className="relative">
                <Button variant="ghost" size="sm" className="relative hover:bg-accent">
                  <Bell className="w-5 h-5" />
                  {totalAlerts > 0 && (
                    <Badge 
                      variant="destructive" 
                      className="absolute -top-2 -right-2 h-5 w-5 p-0 text-xs flex items-center justify-center animate-pulse"
                    >
                      {totalAlerts}
                    </Badge>
                  )}
                </Button>
              </div>

              {/* System Status Indicator */}
              <div className="flex items-center gap-2 px-3 py-1 bg-success/10 text-success rounded-full text-sm">
                <div className="w-2 h-2 bg-success rounded-full animate-pulse" />
                <span className="hidden sm:inline font-medium">Online</span>
              </div>

              {/* User Actions */}
              <div className="flex items-center gap-2">
                <ThemeToggle />
                
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={handleLogout}
                  className="hover:bg-destructive/10 hover:text-destructive hover:border-destructive transition-colors"
                >
                  <LogOut className="w-4 h-4 mr-2" />
                  <span className="hidden sm:inline">Sair</span>
                </Button>
              </div>
            </div>
          </div>

          {/* Dynamic Stats Bar */}
          <div className="border-t bg-gradient-to-r from-muted/30 to-muted/20 px-6 py-3">
            <div className="flex items-center justify-between text-sm">
              <div className="flex items-center gap-6">
                <div className="flex items-center gap-2">
                  <Activity className="w-4 h-4 text-primary" />
                  <span className="text-muted-foreground">Última atualização:</span>
                  <span className="font-medium text-foreground">{new Date().toLocaleTimeString()}</span>
                </div>
              </div>
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-2">
                  <Car className="w-4 h-4 text-primary" />
                  <span className="text-muted-foreground">Veículos:</span>
                  <Badge variant="outline" className="font-medium">{state.vehicles.length}</Badge>
                </div>
                <div className="flex items-center gap-2">
                  <Users className="w-4 h-4 text-primary" />
                  <span className="text-muted-foreground">Operadores:</span>
                  <Badge variant="outline" className="font-medium">{state.operators.length}</Badge>
                </div>
                <div className="flex items-center gap-2">
                  <BarChart3 className="w-4 h-4 text-primary" />
                  <span className="text-muted-foreground">Inspeções:</span>
                  <Badge variant="outline" className="font-medium">{state.checklistResults.length}</Badge>
                </div>
                {pendingOccurrences > 0 && (
                  <div className="flex items-center gap-2 animate-pulse">
                    <AlertTriangle className="w-4 h-4 text-destructive" />
                    <span className="text-muted-foreground">Ocorrências:</span>
                    <Badge variant="destructive" className="font-medium animate-bounce">{pendingOccurrences}</Badge>
                  </div>
                )}
              </div>
            </div>
          </div>
        </header>

        {/* Main Content */}
        <main className="flex-1 p-6 overflow-auto" role="main">
          <div className="max-w-7xl mx-auto">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
});

AdminLayout.displayName = 'AdminLayout';

export default AdminLayout;
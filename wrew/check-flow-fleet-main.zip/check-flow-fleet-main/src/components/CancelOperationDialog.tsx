import { AlertTriangle, X, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

interface CancelOperationDialogProps {
  isOpen: boolean;
  onConfirm: () => void;
  onCancel: () => void;
  operatorName?: string;
  vehiclePlate?: string;
}

export const CancelOperationDialog = ({ 
  isOpen, 
  onConfirm, 
  onCancel, 
  operatorName,
  vehiclePlate
}: CancelOperationDialogProps) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-md mx-auto animate-scale-in">
        <CardHeader className="text-center">
          <div className="flex items-center justify-center w-16 h-16 bg-destructive/20 rounded-full mx-auto mb-4">
            <AlertTriangle className="w-8 h-8 text-destructive" />
          </div>
          <CardTitle className="text-lg">Cancelar Operação</CardTitle>
        </CardHeader>
        
        <CardContent className="space-y-4">
          <div className="text-center space-y-2">
            <p className="text-sm text-muted-foreground">
              Tem certeza que deseja cancelar a operação em andamento?
            </p>
            
            {operatorName && vehiclePlate && (
              <div className="p-3 bg-muted/50 rounded-lg space-y-2">
                <p className="text-xs font-medium">Operação atual:</p>
                <div className="flex items-center justify-center gap-2 text-xs">
                  <Badge variant="outline">{operatorName}</Badge>
                  <span>×</span>
                  <Badge variant="outline">{vehiclePlate}</Badge>
                </div>
              </div>
            )}
            
            <div className="p-3 bg-destructive/10 rounded-lg border border-destructive/20">
              <p className="text-xs text-destructive font-medium flex items-center gap-2">
                <AlertTriangle className="w-4 h-4" />
                Atenção: Nenhum registro será salvo!
              </p>
              <p className="text-xs text-muted-foreground mt-1">
                Todos os dados da operação serão perdidos e você retornará para a página inicial.
              </p>
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-3">
            <Button 
              onClick={onCancel}
              variant="outline"
              className="flex items-center gap-2"
            >
              <X className="w-4 h-4" />
              Voltar
            </Button>
            
            <Button 
              onClick={onConfirm}
              variant="destructive"
              className="flex items-center gap-2"
            >
              <Check className="w-4 h-4" />
              Cancelar e Voltar ao Início
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default CancelOperationDialog;
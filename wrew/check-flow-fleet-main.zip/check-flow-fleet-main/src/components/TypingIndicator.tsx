import { Bot } from 'lucide-react';

interface TypingIndicatorProps {
  message?: string;
}

export const TypingIndicator = ({ message = "Digitando..." }: TypingIndicatorProps) => {
  return (
    <div className="flex justify-start mb-4 animate-fade-in">
      <div className="flex items-start gap-3 max-w-[85%]">
        {/* Avatar */}
        <div className="flex items-center justify-center w-8 h-8 rounded-full bg-primary animate-pulse">
          <Bot className="w-4 h-4 text-primary-foreground" />
        </div>

        {/* Typing Content */}
        <div className="flex flex-col items-start">
          <div className="px-4 py-3 rounded-2xl bg-card text-card-foreground border border-border shadow-sm">
            <div className="flex items-center gap-2">
              <span className="text-sm text-muted-foreground">{message}</span>
              
              {/* Animated dots */}
              <div className="flex gap-1">
                <div className="w-1.5 h-1.5 bg-primary rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                <div className="w-1.5 h-1.5 bg-primary rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                <div className="w-1.5 h-1.5 bg-primary rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
              </div>
            </div>
          </div>
          
          {/* Timestamp */}
          <div className="flex items-center gap-2 mt-2 text-xs text-muted-foreground">
            <span className="opacity-70">
              {new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TypingIndicator;
import { Check, Circle, Clock, User, Car, Camera, FileText, Flag } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

interface ChatProgressIndicatorProps {
  currentStep: string;
  operatorName?: string;
  vehiclePlate?: string;
  completedSteps?: string[];
}

export const ChatProgressIndicator = ({ 
  currentStep, 
  operatorName, 
  vehiclePlate, 
  completedSteps = []
}: ChatProgressIndicatorProps) => {
  const steps = [
    { 
      id: 'operator_selection', 
      label: 'Operador', 
      icon: User,
      description: operatorName || 'Selecionar operador'
    },
    { 
      id: 'selfie', 
      label: 'Identificação', 
      icon: Camera,
      description: 'Selfie de identificação'
    },
    { 
      id: 'vehicle_selection', 
      label: 'Veículo', 
      icon: Car,
      description: vehiclePlate || 'Selecionar veículo'
    },
    { 
      id: 'checklist', 
      label: 'Checklist', 
      icon: FileText,
      description: 'Inspeção do veículo'
    },
    { 
      id: 'travel_guide_active', 
      label: 'Operação', 
      icon: Flag,
      description: 'Guia de viagem ativa'
    }
  ];

  const getStepStatus = (stepId: string) => {
    if (completedSteps.includes(stepId)) return 'completed';
    if (stepId === currentStep) return 'current';
    return 'pending';
  };

  const getStepIcon = (step: any, status: string) => {
    const IconComponent = step.icon;
    
    if (status === 'completed') {
      return <Check className="w-4 h-4 text-success" />;
    }
    if (status === 'current') {
      return <Clock className="w-4 h-4 text-primary animate-pulse" />;
    }
    return <Circle className="w-4 h-4 text-muted-foreground" />;
  };

  const getStepStyle = (status: string) => {
    switch (status) {
      case 'completed':
        return 'bg-success/10 border-success/20 text-success';
      case 'current':
        return 'bg-primary/10 border-primary/20 text-primary animate-pulse';
      default:
        return 'bg-muted/50 border-muted text-muted-foreground';
    }
  };

  return (
    <div className="bg-card/50 backdrop-blur-sm border border-border/50 rounded-lg p-4 mb-4 animate-fade-in">
      <div className="flex items-center justify-between mb-3">
        <h3 className="text-sm font-semibold text-foreground">Progresso da Operação</h3>
        <Badge variant="secondary" className="text-xs">
          {completedSteps.length}/{steps.length}
        </Badge>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
        {steps.map((step, index) => {
          const status = getStepStatus(step.id);
          
          return (
            <div 
              key={step.id}
              className={`
                relative flex flex-col items-center p-3 rounded-lg border transition-all duration-300
                ${getStepStyle(status)}
                ${status === 'current' ? 'scale-105 shadow-lg' : ''}
              `}
            >
              {/* Step Icon */}
              <div className="flex items-center justify-center w-8 h-8 mb-2">
                {getStepIcon(step, status)}
              </div>

              {/* Step Info */}
              <div className="text-center">
                <p className="text-xs font-medium mb-1">{step.label}</p>
                <p className="text-xs opacity-75 truncate w-full">
                  {step.description}
                </p>
              </div>

              {/* Progress Line */}
              {index < steps.length - 1 && (
                <div className="hidden sm:block absolute top-1/2 left-full w-4 h-0.5 -translate-y-1/2 z-10">
                  <div 
                    className={`
                      w-full h-full transition-all duration-500
                      ${status === 'completed' ? 'bg-success' : 'bg-border'}
                    `}
                  />
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Current Step Details */}
      {currentStep && (
        <div className="mt-4 p-3 bg-muted/30 rounded-lg animate-fade-in-up">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 bg-primary rounded-full animate-pulse" />
            <span className="text-xs text-muted-foreground">
              Etapa atual: {steps.find(s => s.id === currentStep)?.label}
            </span>
          </div>
        </div>
      )}
    </div>
  );
};

export default ChatProgressIndicator;
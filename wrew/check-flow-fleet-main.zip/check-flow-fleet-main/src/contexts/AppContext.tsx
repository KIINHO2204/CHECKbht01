import React, { createContext, useContext, useReducer, ReactNode, useMemo, useCallback } from 'react';
import { useLocalStorage } from '@/hooks/useLocalStorage';

// Tipos
export interface Vehicle {
  id: string;
  plate: string;
  category: string;
  checklistId: string;
  model: string;
  photo: string;
  currentKm: number;
  createdAt: string;
}

export interface Operator {
  id: string;
  name: string;
  cpf: string;
  cnh: string;
  role: string;
  photo: string;
  inspectionsCount: number;
  createdAt: string;
}

export interface ChecklistItem {
  id: string;
  question: string;
  requiresPhoto: boolean;
  order: number;
}

export interface Checklist {
  id: string;
  name: string;
  items: ChecklistItem[];
  createdAt: string;
}

export interface Occurrence {
  id: string;
  checklistId: string;
  vehicleId: string;
  operatorId: string;
  itemId: string;
  description: string;
  photo?: string;
  status: 'pending' | 'resolved';
  createdAt: string;
  resolvedAt?: string;
}

export interface ChecklistResult {
  id: string;
  checklistId: string;
  vehicleId: string;
  operatorId: string;
  operatorSelfie: string;
  responses: {
    itemId: string;
    answer: 'CONFORME' | 'NÃO CONFORME';
    photo?: string;
  }[];
  createdAt: string;
}

export interface HeaderSettings {
  companyName: string;
  cnpj: string;
  address: string;
  validity: string;
  description: string;
  logo: string | null;
}

export interface TravelGuide {
  id: string;
  operatorId: string;
  vehicleId: string;
  operatorSelfieStart: string;
  operatorSelfieEnd?: string;
  frontPhotoStart: string;
  rearPhotoStart: string;
  frontPhotoEnd?: string;
  rearPhotoEnd?: string;
  kmStart: number;
  kmEnd?: number;
  startTime: string;
  endTime?: string;
  status: 'active' | 'completed' | 'cancelled' | 'forgotten_end';
  createdAt: string;
  completedAt?: string;
}

interface AppState {
  user: { id: string; type: 'admin' | 'operator' } | null;
  vehicles: Vehicle[];
  operators: Operator[];
  checklists: Checklist[];
  occurrences: Occurrence[];
  checklistResults: ChecklistResult[];
  travelGuides: TravelGuide[];
  headerSettings: HeaderSettings | null;
  isLoading: boolean;
}

type AppAction = 
  | { type: 'SET_USER'; payload: { id: string; type: 'admin' | 'operator' } | null }
  | { type: 'SET_LOADING'; payload: boolean }
  | { type: 'ADD_VEHICLE'; payload: Vehicle }
  | { type: 'UPDATE_VEHICLE'; payload: Vehicle }
  | { type: 'DELETE_VEHICLE'; payload: string }
  | { type: 'UPDATE_VEHICLE_KM'; payload: { vehicleId: string; km: number } }
  | { type: 'ADD_OPERATOR'; payload: Operator }
  | { type: 'UPDATE_OPERATOR'; payload: Operator }
  | { type: 'DELETE_OPERATOR'; payload: string }
  | { type: 'ADD_CHECKLIST'; payload: Checklist }
  | { type: 'UPDATE_CHECKLIST'; payload: Checklist }
  | { type: 'DELETE_CHECKLIST'; payload: string }
  | { type: 'ADD_OCCURRENCE'; payload: Occurrence }
  | { type: 'RESOLVE_OCCURRENCE'; payload: string }
  | { type: 'ADD_CHECKLIST_RESULT'; payload: ChecklistResult }
  | { type: 'INCREMENT_OPERATOR_INSPECTIONS'; payload: string }
  | { type: 'UPDATE_HEADER_SETTINGS'; payload: HeaderSettings }
  | { type: 'ADD_TRAVEL_GUIDE'; payload: TravelGuide }
  | { type: 'UPDATE_TRAVEL_GUIDE'; payload: TravelGuide }
  | { type: 'LOAD_DATA'; payload: Partial<AppState> };

const initialState: AppState = {
  user: null,
  vehicles: [
    {
      id: '1',
      plate: 'ABC-1234',
      category: 'Inspeção Diária Veicular',
      checklistId: '1',
      model: 'Volvo FH 540',
      photo: '/placeholder.svg',
      currentKm: 12350,
      createdAt: new Date().toISOString(),
    },
    {
      id: '2',
      plate: 'XYZ-5678',
      category: 'Inspeção Diária Veicular',
      checklistId: '1',
      model: 'Mercedes Sprinter',
      photo: '/placeholder.svg',
      currentKm: 8500,
      createdAt: new Date().toISOString(),
    },
  ],
  operators: [
    {
      id: '1',
      name: 'João Silva',
      cpf: '123.456.789-00',
      cnh: '12345678901',
      role: 'Motorista',
      photo: '/placeholder.svg',
      inspectionsCount: 15,
      createdAt: new Date().toISOString(),
    },
    {
      id: '2',
      name: 'Maria Santos',
      cpf: '987.654.321-00',
      cnh: '10987654321',
      role: 'Operadora',
      photo: '/placeholder.svg',
      inspectionsCount: 8,
      createdAt: new Date().toISOString(),
    },
  ],
  checklists: [
    {
      id: '1',
      name: 'Inspeção Diária Veicular',
      items: [
        { id: '1', question: 'Verificar nível de óleo do motor', requiresPhoto: true, order: 1 },
        { id: '2', question: 'Verificar pressão dos pneus', requiresPhoto: true, order: 2 },
        { id: '3', question: 'Verificar funcionamento dos freios', requiresPhoto: false, order: 3 },
        { id: '4', question: 'Verificar estado dos faróis', requiresPhoto: true, order: 4 },
        { id: '5', question: 'Verificar sistema de sinalização', requiresPhoto: false, order: 5 },
        { id: '6', question: 'Verificar limpadores de para-brisa', requiresPhoto: false, order: 6 },
      ],
      createdAt: new Date().toISOString(),
    },
  ],
  occurrences: [
    {
      id: '1',
      checklistId: '1',
      vehicleId: '1',
      operatorId: '1',
      itemId: '2',
      description: 'Pressão dos pneus abaixo do recomendado',
      status: 'pending',
      createdAt: new Date().toISOString(),
    },
  ],
  checklistResults: [
    {
      id: '1',
      checklistId: '1',
      vehicleId: '1',
      operatorId: '1',
      operatorSelfie: '/placeholder.svg',
      responses: [
        { itemId: '1', answer: 'CONFORME', photo: '/placeholder.svg' },
        { itemId: '2', answer: 'NÃO CONFORME', photo: '/placeholder.svg' },
        { itemId: '3', answer: 'CONFORME' },
        { itemId: '4', answer: 'CONFORME', photo: '/placeholder.svg' },
        { itemId: '5', answer: 'CONFORME' },
        { itemId: '6', answer: 'NÃO CONFORME' },
      ],
      createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
    },
    {
      id: '2',
      checklistId: '1',
      vehicleId: '2',
      operatorId: '2',
      operatorSelfie: '/placeholder.svg',
      responses: [
        { itemId: '1', answer: 'CONFORME', photo: '/placeholder.svg' },
        { itemId: '2', answer: 'CONFORME', photo: '/placeholder.svg' },
        { itemId: '3', answer: 'CONFORME' },
        { itemId: '4', answer: 'CONFORME', photo: '/placeholder.svg' },
        { itemId: '5', answer: 'CONFORME' },
        { itemId: '6', answer: 'CONFORME' },
      ],
      createdAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(),
    },
    {
      id: '3',
      checklistId: '1',
      vehicleId: '1',
      operatorId: '1',
      operatorSelfie: '/placeholder.svg',
      responses: [
        { itemId: '1', answer: 'CONFORME', photo: '/placeholder.svg' },
        { itemId: '2', answer: 'CONFORME', photo: '/placeholder.svg' },
        { itemId: '3', answer: 'NÃO CONFORME' },
        { itemId: '4', answer: 'CONFORME', photo: '/placeholder.svg' },
        { itemId: '5', answer: 'NÃO CONFORME' },
        { itemId: '6', answer: 'CONFORME' },
      ],
      createdAt: new Date().toISOString(),
    },
  ],
  travelGuides: [
    {
      id: '1',
      operatorId: '1',
      vehicleId: '1',
      operatorSelfieStart: '/placeholder.svg',
      operatorSelfieEnd: '/placeholder.svg',
      frontPhotoStart: '/placeholder.svg',
      rearPhotoStart: '/placeholder.svg',
      frontPhotoEnd: '/placeholder.svg',
      rearPhotoEnd: '/placeholder.svg',
      kmStart: 12000,
      kmEnd: 12350,
      startTime: new Date(Date.now() - 8 * 60 * 60 * 1000).toISOString(),
      endTime: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
      status: 'completed',
      createdAt: new Date(Date.now() - 8 * 60 * 60 * 1000).toISOString(),
      completedAt: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
    },
    {
      id: '2',
      operatorId: '2',
      vehicleId: '2',
      operatorSelfieStart: '/placeholder.svg',
      frontPhotoStart: '/placeholder.svg',
      rearPhotoStart: '/placeholder.svg',
      kmStart: 8500,
      startTime: new Date(Date.now() - 4 * 60 * 60 * 1000).toISOString(),
      status: 'active',
      createdAt: new Date(Date.now() - 4 * 60 * 60 * 1000).toISOString(),
    },
  ],
  headerSettings: null,
  isLoading: false,
};

function appReducer(state: AppState, action: AppAction): AppState {
  switch (action.type) {
    case 'SET_USER':
      return { ...state, user: action.payload };
    case 'SET_LOADING':
      return { ...state, isLoading: action.payload };
    case 'ADD_VEHICLE':
      return { ...state, vehicles: [...state.vehicles, action.payload] };
    case 'UPDATE_VEHICLE':
      return {
        ...state,
        vehicles: state.vehicles.map(v => v.id === action.payload.id ? action.payload : v),
      };
    case 'DELETE_VEHICLE':
      return {
        ...state,
        vehicles: state.vehicles.filter(v => v.id !== action.payload),
      };
    case 'UPDATE_VEHICLE_KM':
      return {
        ...state,
        vehicles: state.vehicles.map(v => 
          v.id === action.payload.vehicleId 
            ? { ...v, currentKm: action.payload.km }
            : v
        ),
      };
    case 'ADD_OPERATOR':
      return { ...state, operators: [...state.operators, action.payload] };
    case 'UPDATE_OPERATOR':
      return {
        ...state,
        operators: state.operators.map(o => o.id === action.payload.id ? action.payload : o),
      };
    case 'DELETE_OPERATOR':
      return {
        ...state,
        operators: state.operators.filter(o => o.id !== action.payload),
      };
    case 'ADD_CHECKLIST':
      return { ...state, checklists: [...state.checklists, action.payload] };
    case 'UPDATE_CHECKLIST':
      return {
        ...state,
        checklists: state.checklists.map(c => c.id === action.payload.id ? action.payload : c),
      };
    case 'DELETE_CHECKLIST':
      return {
        ...state,
        checklists: state.checklists.filter(c => c.id !== action.payload),
      };
    case 'ADD_OCCURRENCE':
      return { ...state, occurrences: [...state.occurrences, action.payload] };
    case 'RESOLVE_OCCURRENCE':
      return {
        ...state,
        occurrences: state.occurrences.map(o => 
          o.id === action.payload 
            ? { ...o, status: 'resolved' as const, resolvedAt: new Date().toISOString() }
            : o
        ),
      };
    case 'ADD_CHECKLIST_RESULT':
      return { ...state, checklistResults: [...state.checklistResults, action.payload] };
    case 'INCREMENT_OPERATOR_INSPECTIONS':
      return {
        ...state,
        operators: state.operators.map(o => 
          o.id === action.payload 
            ? { ...o, inspectionsCount: o.inspectionsCount + 1 }
            : o
        ),
      };
    case 'UPDATE_HEADER_SETTINGS':
      return { ...state, headerSettings: action.payload };
    case 'ADD_TRAVEL_GUIDE':
      return { ...state, travelGuides: [...state.travelGuides, action.payload] };
    case 'UPDATE_TRAVEL_GUIDE':
      const updatedGuide = action.payload;
      // Se o guia foi completado e tem kmEnd, atualizar o KM do veículo
      if (updatedGuide.status === 'completed' && updatedGuide.kmEnd) {
        const newState = {
          ...state,
          travelGuides: state.travelGuides.map(tg => 
            tg.id === updatedGuide.id ? updatedGuide : tg
          ),
        };
        // Atualizar o KM do veículo
        return {
          ...newState,
          vehicles: newState.vehicles.map(v => 
            v.id === updatedGuide.vehicleId 
              ? { ...v, currentKm: updatedGuide.kmEnd! }
              : v
          ),
        };
      }
      return {
        ...state,
        travelGuides: state.travelGuides.map(tg => 
          tg.id === updatedGuide.id ? updatedGuide : tg
        ),
      };
    case 'LOAD_DATA':
      return { ...state, ...action.payload };
    default:
      return state;
  }
}

interface AppContextType {
  state: AppState;
  dispatch: React.Dispatch<AppAction>;
  // Computed values
  pendingOccurrences: number;
  resolvedOccurrences: number;
  topOperator: Operator | null;
  bottomOperator: Operator | null;
  // Actions
  addVehicle: (vehicle: Omit<Vehicle, 'id' | 'createdAt'>) => void;
  updateVehicle: (vehicle: Vehicle) => void;
  deleteVehicle: (id: string) => void;
  addOperator: (operator: Omit<Operator, 'id' | 'createdAt' | 'inspectionsCount'>) => void;
  updateOperator: (operator: Operator) => void;
  deleteOperator: (id: string) => void;
  addOccurrence: (occurrence: Omit<Occurrence, 'id' | 'createdAt'>) => void;
  resolveOccurrence: (id: string) => void;
  addChecklistResult: (result: Omit<ChecklistResult, 'id' | 'createdAt'>) => void;
  addTravelGuide: (guide: Omit<TravelGuide, 'id' | 'createdAt'>) => void;
  updateTravelGuide: (guide: TravelGuide) => void;
}

const AppContext = createContext<AppContextType | null>(null);

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [state, dispatch] = useReducer(appReducer, initialState);

  // Computed values com useMemo para otimização
  const pendingOccurrences = useMemo(() => 
    state.occurrences.filter(o => o.status === 'pending').length,
    [state.occurrences]
  );

  const resolvedOccurrences = useMemo(() => 
    state.occurrences.filter(o => o.status === 'resolved').length,
    [state.occurrences]
  );

  const topOperator = useMemo(() => {
    if (state.operators.length === 0) return null;
    return [...state.operators].sort((a, b) => b.inspectionsCount - a.inspectionsCount)[0];
  }, [state.operators]);

  const bottomOperator = useMemo(() => {
    if (state.operators.length === 0) return null;
    return [...state.operators].sort((a, b) => a.inspectionsCount - b.inspectionsCount)[0];
  }, [state.operators]);

  // Actions com useCallback para otimização
  const addVehicle = useCallback((vehicle: Omit<Vehicle, 'id' | 'createdAt'>) => {
    dispatch({
      type: 'ADD_VEHICLE',
      payload: {
        ...vehicle,
        id: Date.now().toString(),
        createdAt: new Date().toISOString(),
      }
    });
  }, []);

  const updateVehicle = useCallback((vehicle: Vehicle) => {
    dispatch({ type: 'UPDATE_VEHICLE', payload: vehicle });
  }, []);

  const deleteVehicle = useCallback((id: string) => {
    dispatch({ type: 'DELETE_VEHICLE', payload: id });
  }, []);

  const addOperator = useCallback((operator: Omit<Operator, 'id' | 'createdAt' | 'inspectionsCount'>) => {
    dispatch({
      type: 'ADD_OPERATOR',
      payload: {
        ...operator,
        id: Date.now().toString(),
        inspectionsCount: 0,
        createdAt: new Date().toISOString(),
      }
    });
  }, []);

  const updateOperator = useCallback((operator: Operator) => {
    dispatch({ type: 'UPDATE_OPERATOR', payload: operator });
  }, []);

  const deleteOperator = useCallback((id: string) => {
    dispatch({ type: 'DELETE_OPERATOR', payload: id });
  }, []);

  const addOccurrence = useCallback((occurrence: Omit<Occurrence, 'id' | 'createdAt'>) => {
    dispatch({
      type: 'ADD_OCCURRENCE',
      payload: {
        ...occurrence,
        id: Date.now().toString(),
        createdAt: new Date().toISOString(),
      }
    });
  }, []);

  const resolveOccurrence = useCallback((id: string) => {
    dispatch({ type: 'RESOLVE_OCCURRENCE', payload: id });
  }, []);

  const addChecklistResult = useCallback((result: Omit<ChecklistResult, 'id' | 'createdAt'>) => {
    dispatch({
      type: 'ADD_CHECKLIST_RESULT',
      payload: {
        ...result,
        id: Date.now().toString(),
        createdAt: new Date().toISOString(),
      }
    });
    // Incrementar contagem de inspeções do operador
    dispatch({ type: 'INCREMENT_OPERATOR_INSPECTIONS', payload: result.operatorId });
  }, []);

  const addTravelGuide = useCallback((guide: Omit<TravelGuide, 'id' | 'createdAt'>) => {
    dispatch({
      type: 'ADD_TRAVEL_GUIDE',
      payload: {
        ...guide,
        id: Date.now().toString(),
        createdAt: new Date().toISOString(),
      }
    });
  }, []);

  const updateTravelGuide = useCallback((guide: TravelGuide) => {
    dispatch({ type: 'UPDATE_TRAVEL_GUIDE', payload: guide });
  }, []);

  const contextValue = useMemo(() => ({
    state,
    dispatch,
    pendingOccurrences,
    resolvedOccurrences,
    topOperator,
    bottomOperator,
    addVehicle,
    updateVehicle,
    deleteVehicle,
    addOperator,
    updateOperator,
    deleteOperator,
    addOccurrence,
    resolveOccurrence,
    addChecklistResult,
    addTravelGuide,
    updateTravelGuide,
  }), [
    state,
    pendingOccurrences,
    resolvedOccurrences,
    topOperator,
    bottomOperator,
    addVehicle,
    updateVehicle,
    deleteVehicle,
    addOperator,
    updateOperator,
    deleteOperator,
    addOccurrence,
    resolveOccurrence,
    addChecklistResult,
    addTravelGuide,
    updateTravelGuide,
  ]);

  return (
    <AppContext.Provider value={contextValue}>
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
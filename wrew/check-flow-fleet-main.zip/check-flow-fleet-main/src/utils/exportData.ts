import { ChecklistResult, Vehicle, Operator, Occurrence, HeaderSettings } from '@/contexts/AppContext';
import jsPDF from 'jspdf';

export const exportToCSV = (data: any[], filename: string) => {
  if (data.length === 0) return;
  
  const headers = Object.keys(data[0]);
  const csvContent = [
    headers.join(','),
    ...data.map(row => 
      headers.map(header => {
        const value = row[header];
        if (typeof value === 'string' && value.includes(',')) {
          return `"${value}"`;
        }
        return value;
      }).join(',')
    )
  ].join('\n');
  
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  
  if (link.download !== undefined) {
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `${filename}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }
};

export const exportData = (data: any[], filename: string) => {
  if (data.length === 0) return;
  
  const headers = Object.keys(data[0]);
  const csvContent = [
    headers.join(','),
    ...data.map(row => 
      headers.map(header => {
        const value = row[header];
        if (typeof value === 'string' && value.includes(',')) {
          return `"${value}"`;
        }
        return value;
      }).join(',')
    )
  ].join('\n');
  
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  
  if (link.download !== undefined) {
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `${filename}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }
};

export const exportChecklistResultToPDF = async (
  result: ChecklistResult,
  vehicle: Vehicle,
  operator: Operator,
  checklist: any,
  headerSettings?: HeaderSettings | null,
  includeAIAnalysis: boolean = false
) => {
  const doc = new jsPDF();
  const pageWidth = doc.internal.pageSize.width;
  const pageHeight = doc.internal.pageSize.height;
  const margin = 20;
  const contentWidth = pageWidth - (margin * 2);
  let yPosition = margin;

  // Configurações de fonte padrão
  doc.setFont("helvetica", "normal");
  doc.setTextColor(0, 0, 0);
  doc.setDrawColor(0, 0, 0);
  doc.setLineWidth(0.5);

  // Função para verificar necessidade de quebra de página
  const checkPageBreak = (requiredSpace: number) => {
    if (yPosition + requiredSpace > pageHeight - 40) {
      doc.addPage();
      yPosition = margin;
      return true;
    }
    return false;
  };

  // Função para desenhar caixa com fundo opcional
  const drawBox = (x: number, y: number, width: number, height: number, backgroundColor?: string) => {
    if (backgroundColor) {
      const rgb = hexToRgb(backgroundColor);
      if (rgb) {
        doc.setFillColor(rgb.r, rgb.g, rgb.b);
        doc.rect(x, y, width, height, "F");
      }
    }
    doc.setDrawColor(200, 200, 200);
    doc.setLineWidth(0.5);
    doc.rect(x, y, width, height);
    doc.setDrawColor(0, 0, 0);
  };

  // Função auxiliar para converter hex para RGB
  const hexToRgb = (hex: string) => {
    const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    return result ? {
      r: parseInt(result[1], 16),
      g: parseInt(result[2], 16),
      b: parseInt(result[3], 16)
    } : null;
  };

  // Função para adicionar texto quebrado automaticamente
  const addWrappedText = (text: string, x: number, y: number, maxWidth: number, fontSize: number = 11) => {
    doc.setFontSize(fontSize);
    const lines = doc.splitTextToSize(text, maxWidth);
    doc.text(lines, x, y);
    return lines.length * (fontSize * 0.35) + 2; // Retorna altura usada
  };

  // ============= INÍCIO DO DOCUMENTO =============

  // CABEÇALHO DA EMPRESA
  if (headerSettings) {
    // Caixa do cabeçalho
    drawBox(margin, yPosition, contentWidth, 50, "#f8f9fa");
    
    let headerContentY = yPosition + 10;
    
    // Logo da empresa (se disponível)
    if (headerSettings.logo) {
      try {
        doc.addImage(headerSettings.logo, "JPEG", margin + 5, headerContentY, 30, 30);
      } catch (error) {
        console.warn("Erro ao carregar logo:", error);
      }
    }
    
    // Informações da empresa
    const textStartX = margin + 40;
    doc.setFontSize(16);
    doc.setFont("helvetica", "bold");
    doc.text(headerSettings.companyName, textStartX, headerContentY + 8);
    
    doc.setFontSize(10);
    doc.setFont("helvetica", "normal");
    doc.text(`CNPJ: ${headerSettings.cnpj}`, textStartX, headerContentY + 16);
    doc.text(headerSettings.address, textStartX, headerContentY + 22);
    
    if (headerSettings.validity) {
      doc.text(`Validade: ${headerSettings.validity}`, textStartX, headerContentY + 28);
    }
    
    yPosition += 60;
  }

  // TÍTULO DO RELATÓRIO
  checkPageBreak(30);
  drawBox(margin, yPosition, contentWidth, 25, "#2980b9");
  
  doc.setFontSize(18);
  doc.setFont("helvetica", "bold");
  doc.setTextColor(255, 255, 255);
  doc.text("RELATÓRIO DE INSPEÇÃO VEICULAR", pageWidth / 2, yPosition + 16, { align: "center" });
  doc.setTextColor(0, 0, 0);
  
  yPosition += 35;

  // DATA E HORA DA INSPEÇÃO
  checkPageBreak(20);
  const inspectionDate = new Date(result.createdAt);
  const formattedDate = inspectionDate.toLocaleDateString("pt-BR");
  const formattedTime = inspectionDate.toLocaleTimeString("pt-BR", { 
    hour: "2-digit", 
    minute: "2-digit" 
  });
  
  doc.setFontSize(12);
  doc.setFont("helvetica", "normal");
  doc.text(`Data da Inspeção: ${formattedDate}`, margin, yPosition);
  doc.text(`Horário: ${formattedTime}`, pageWidth - margin - 60, yPosition);
  
  yPosition += 20;

  // DADOS DO VEÍCULO
  checkPageBreak(40);
  doc.setFontSize(14);
  doc.setFont("helvetica", "bold");
  doc.text("DADOS DO VEÍCULO", margin, yPosition);
  yPosition += 8;
  
  drawBox(margin, yPosition, contentWidth, 30, "#ecf0f1");
  
  doc.setFontSize(12);
  doc.setFont("helvetica", "normal");
  doc.text(`Placa: ${vehicle.plate}`, margin + 8, yPosition + 12);
  doc.text(`Modelo: ${vehicle.model}`, margin + 8, yPosition + 22);
  doc.text(`Categoria: ${vehicle.category}`, pageWidth / 2 + 10, yPosition + 12);
  
  yPosition += 40;

  // DADOS DO OPERADOR
  checkPageBreak(40);
  doc.setFontSize(14);
  doc.setFont("helvetica", "bold");
  doc.text("DADOS DO OPERADOR", margin, yPosition);
  yPosition += 8;
  
  drawBox(margin, yPosition, contentWidth, 30, "#ecf0f1");
  
  doc.setFontSize(12);
  doc.setFont("helvetica", "normal");
  doc.text(`Nome: ${operator.name}`, margin + 8, yPosition + 12);
  doc.text(`CPF: ${operator.cpf}`, margin + 8, yPosition + 22);
  doc.text(`CNH: ${operator.cnh}`, pageWidth / 2 + 10, yPosition + 12);
  doc.text(`Função: ${operator.role}`, pageWidth / 2 + 10, yPosition + 22);
  
  yPosition += 40;

  // SELFIE DO OPERADOR (se disponível)
  if (result.operatorSelfie) {
    checkPageBreak(50);
    doc.setFontSize(12);
    doc.setFont("helvetica", "bold");
    doc.text("Selfie do Operador:", margin, yPosition);
    yPosition += 10;
    
    try {
      drawBox(margin, yPosition, 40, 35, "#ffffff");
      doc.addImage(result.operatorSelfie, "JPEG", margin + 2, yPosition + 2, 36, 31);
      yPosition += 45;
    } catch (error) {
      console.warn("Erro ao carregar selfie:", error);
      doc.setFontSize(10);
      doc.setTextColor(128, 128, 128);
      doc.text("(Erro ao carregar selfie do operador)", margin, yPosition + 10);
      doc.setTextColor(0, 0, 0);
      yPosition += 20;
    }
  }

  // NOME DO CHECKLIST
  checkPageBreak(30);
  doc.setFontSize(14);
  doc.setFont("helvetica", "bold");
  doc.text(`CHECKLIST APLICADO: ${checklist.name}`, margin, yPosition);
  yPosition += 20;

  // TÍTULO DA SEÇÃO DE ITENS
  doc.setFontSize(14);
  doc.setFont("helvetica", "bold");
  doc.text("ITENS VERIFICADOS", margin, yPosition);
  yPosition += 15;

  // PROCESSAMENTO DOS ITENS DO CHECKLIST
  for (let i = 0; i < result.responses.length; i++) {
    const response = result.responses[i];
    const question = checklist.items.find((item: any) => item.id === response.itemId);
    
    if (!question) continue;

    // Calcular espaço necessário para este item
    const questionHeight = Math.ceil(question.question.length / 80) * 6; // Estimativa de linhas
    const photoHeight = response.photo ? 45 : 0;
    const totalNeededSpace = questionHeight + 25 + photoHeight;
    
    checkPageBreak(totalNeededSpace);
    
    // Caixa para a pergunta
    const questionBoxHeight = Math.max(20, questionHeight + 8);
    drawBox(margin, yPosition, contentWidth, questionBoxHeight, "#f7f7f7");
    
    // Número e texto da pergunta
    doc.setFontSize(11);
    doc.setFont("helvetica", "bold");
    const questionText = `${i + 1}. ${question.question}`;
    const wrappedHeight = addWrappedText(questionText, margin + 5, yPosition + 8, contentWidth - 10, 11);
    
    yPosition += Math.max(questionBoxHeight, wrappedHeight + 10);
    
    // Resposta
    doc.setFontSize(11);
    doc.setFont("helvetica", "normal");
    doc.text("Resultado:", margin + 5, yPosition);
    
    // Status com cores e símbolos
    doc.setFont("helvetica", "bold");
    if (response.answer === "CONFORME") {
      doc.setTextColor(27, 94, 32); // Verde escuro
      doc.text("✓ CONFORME", margin + 45, yPosition);
    } else {
      doc.setTextColor(183, 28, 28); // Vermelho escuro
      doc.text("✗ NÃO CONFORME", margin + 45, yPosition);
    }
    doc.setTextColor(0, 0, 0); // Reset cor
    
    yPosition += 15;
    
    // Foto evidência (se houver)
    if (response.photo) {
      checkPageBreak(50);
      doc.setFontSize(10);
      doc.setFont("helvetica", "normal");
      doc.text("Evidência fotográfica:", margin + 5, yPosition);
      yPosition += 8;
      
      try {
        drawBox(margin + 5, yPosition, 55, 40, "#ffffff");
        doc.addImage(response.photo, "JPEG", margin + 7, yPosition + 2, 51, 36);
        yPosition += 45;
      } catch (error) {
        console.warn("Erro ao carregar foto:", error);
        doc.setFontSize(9);
        doc.setTextColor(128, 128, 128);
        doc.text("(Erro ao carregar evidência fotográfica)", margin + 5, yPosition + 10);
        doc.setTextColor(0, 0, 0);
        yPosition += 20;
      }
    }
    
    // Linha separadora entre itens
    if (i < result.responses.length - 1) {
      doc.setDrawColor(220, 220, 220);
      doc.setLineWidth(0.5);
      doc.line(margin, yPosition + 8, pageWidth - margin, yPosition + 8);
      doc.setDrawColor(0, 0, 0);
      yPosition += 18;
    }
  }

  // RESUMO FINAL
  checkPageBreak(70);
  yPosition += 25;
  
  const conformeCount = result.responses.filter(r => r.answer === "CONFORME").length;
  const naoConformeCount = result.responses.filter(r => r.answer === "NÃO CONFORME").length;
  const totalItems = result.responses.length;
  const conformityPercentage = Math.round((conformeCount / totalItems) * 100);
  
  // Título do resumo
  doc.setFontSize(16);
  doc.setFont("helvetica", "bold");
  doc.text("RESUMO FINAL DA INSPEÇÃO", margin, yPosition);
  yPosition += 12;
  
  // Caixa do resumo
  drawBox(margin, yPosition, contentWidth, 45, "#f5f5f5");
  
  // Estatísticas
  doc.setFontSize(12);
  doc.setFont("helvetica", "normal");
  doc.text(`Total de itens verificados: ${totalItems}`, margin + 10, yPosition + 12);
  
  doc.setFontSize(11);
  doc.setTextColor(27, 94, 32);
  doc.text(`✓ Itens conformes: ${conformeCount}`, margin + 10, yPosition + 22);
  
  doc.setTextColor(183, 28, 28);
  doc.text(`✗ Itens não conformes: ${naoConformeCount}`, margin + 10, yPosition + 30);
  
  // Status final
  doc.setTextColor(0, 0, 0);
  doc.setFontSize(13);
  doc.setFont("helvetica", "bold");
  const finalStatus = naoConformeCount === 0 ? "APROVADO" : "REPROVADO";
  const statusText = `Status Final: ${finalStatus} (${conformityPercentage}% de conformidade)`;
  
  if (naoConformeCount === 0) {
    doc.setTextColor(27, 94, 32);
  } else {
    doc.setTextColor(183, 28, 28);
  }
  
  doc.text(statusText, pageWidth / 2, yPosition + 38, { align: "center" });
  doc.setTextColor(0, 0, 0);

  // RODAPÉ EM TODAS AS PÁGINAS
  const totalPages = doc.getNumberOfPages();
  
  for (let pageNum = 1; pageNum <= totalPages; pageNum++) {
    doc.setPage(pageNum);
    
    // Linha decorativa do rodapé
    doc.setDrawColor(41, 128, 185);
    doc.setLineWidth(1);
    doc.line(margin, pageHeight - 25, pageWidth - margin, pageHeight - 25);
    
    // Texto do rodapé
    doc.setFontSize(8);
    doc.setFont("helvetica", "normal");
    doc.setTextColor(100, 100, 100);
    
    const now = new Date();
    const footerLeft = `Gerado em: ${now.toLocaleDateString("pt-BR")} às ${now.toLocaleTimeString("pt-BR")}`;
    const footerCenter = "Sistema de Checklist Veicular";
    const footerRight = `Página ${pageNum} de ${totalPages}`;
    
    doc.text(footerLeft, margin, pageHeight - 15);
    doc.text(footerCenter, pageWidth / 2, pageHeight - 15, { align: "center" });
    doc.text(footerRight, pageWidth - margin, pageHeight - 15, { align: "right" });
    
    // Reset configurações
    doc.setTextColor(0, 0, 0);
    doc.setDrawColor(0, 0, 0);
  }

  // SALVAR O ARQUIVO
  const cleanPlate = vehicle.plate.replace(/[^a-zA-Z0-9]/g, "");
  const cleanDate = formattedDate.replace(/\//g, "-");
  const filename = `Relatorio_Inspecao_${cleanPlate}_${cleanDate}.pdf`;
  
  doc.save(filename);
};
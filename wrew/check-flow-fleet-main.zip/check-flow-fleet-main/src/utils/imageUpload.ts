export interface ImageUploadResult {
  url: string;
  file: File;
}

/**
 * Redimensiona uma imagem mantendo a proporção
 */
export const resizeImage = (file: File, maxWidth: number = 800, maxHeight: number = 600, quality: number = 0.8): Promise<string> => {
  return new Promise((resolve, reject) => {
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    const img = new Image();

    img.onload = () => {
      // Calcular novas dimensões mantendo proporção
      let { width, height } = img;
      
      if (width > height) {
        if (width > maxWidth) {
          height = Math.round((height * maxWidth) / width);
          width = maxWidth;
        }
      } else {
        if (height > maxHeight) {
          width = Math.round((width * maxHeight) / height);
          height = maxHeight;
        }
      }

      canvas.width = width;
      canvas.height = height;

      // Desenhar imagem redimensionada
      ctx?.drawImage(img, 0, 0, width, height);

      // Converter para base64
      const resizedDataUrl = canvas.toDataURL('image/jpeg', quality);
      resolve(resizedDataUrl);
    };

    img.onerror = () => reject(new Error('Erro ao carregar imagem'));
    img.src = URL.createObjectURL(file);
  });
};

/**
 * Abre seletor de arquivo para upload de imagem
 */
export const selectImage = (): Promise<ImageUploadResult> => {
  return new Promise((resolve, reject) => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*';
    input.multiple = false;

    input.onchange = async (event) => {
      const file = (event.target as HTMLInputElement).files?.[0];
      
      if (!file) {
        reject(new Error('Nenhum arquivo selecionado'));
        return;
      }

      // Validar tipo de arquivo
      if (!file.type.startsWith('image/')) {
        reject(new Error('Por favor, selecione apenas arquivos de imagem'));
        return;
      }

      // Validar tamanho do arquivo (máximo 5MB)
      if (file.size > 5 * 1024 * 1024) {
        reject(new Error('O arquivo deve ter no máximo 5MB'));
        return;
      }

      try {
        // Redimensionar imagem
        const resizedUrl = await resizeImage(file);
        
        resolve({
          url: resizedUrl,
          file
        });
      } catch (error) {
        reject(error);
      }
    };

    input.click();
  });
};

/**
 * Captura foto usando câmera do dispositivo
 */
export const capturePhoto = (): Promise<ImageUploadResult> => {
  return new Promise((resolve, reject) => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*';
    input.multiple = false;
    
    // Configuração para mobile
    input.setAttribute('capture', 'environment');
    input.style.display = 'none';
    
    // Timeout para detectar se o usuário cancelou
    let timeoutId: NodeJS.Timeout;
    
    const cleanup = () => {
      if (timeoutId) clearTimeout(timeoutId);
      if (input.parentNode) {
        input.parentNode.removeChild(input);
      }
    };

    input.onchange = async (event) => {
      console.log('📸 Input change event triggered');
      cleanup();
      
      const file = (event.target as HTMLInputElement).files?.[0];
      
      if (!file) {
        console.log('❌ Nenhum arquivo selecionado');
        reject(new Error('Nenhuma foto capturada'));
        return;
      }

      console.log('📷 Arquivo selecionado:', file.name, file.type, file.size);

      try {
        console.log('🔄 Redimensionando imagem...');
        const resizedUrl = await resizeImage(file);
        console.log('✅ Imagem redimensionada com sucesso');
        
        resolve({
          url: resizedUrl,
          file
        });
      } catch (error) {
        console.error('❌ Erro ao redimensionar imagem:', error);
        reject(error);
      }
    };

    input.onerror = (error) => {
      console.error('❌ Erro no input:', error);
      cleanup();
      reject(new Error('Erro ao acessar câmera'));
    };

    // Adicionar ao DOM temporariamente
    document.body.appendChild(input);
    
    // Timeout para detectar cancelamento
    timeoutId = setTimeout(() => {
      console.log('🚫 Timeout - assumindo que usuário cancelou');
      cleanup();
      reject(new Error('Tempo esgotado para captura da foto'));
    }, 60000); // 1 minuto
    
    console.log('🎯 Clicando no input para abrir câmera...');
    
    // Forçar o clique em mobile
    if (navigator.userAgent.match(/iPhone|iPad|iPod|Android/i)) {
      // Para dispositivos móveis, usar um evento de toque
      input.click();
      
      // Fallback para dispositivos que não respondem ao click
      setTimeout(() => {
        const event = new MouseEvent('click', {
          view: window,
          bubbles: true,
          cancelable: true
        });
        input.dispatchEvent(event);
      }, 100);
    } else {
      input.click();
    }
  });
};

/**
 * Converte arquivo de imagem para base64
 */
export const fileToBase64 = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = error => reject(error);
  });
};

/**
 * Comprime imagem para reduzir tamanho do arquivo
 */
export const compressImage = (file: File, quality: number = 0.7): Promise<string> => {
  return resizeImage(file, 1200, 900, quality);
};
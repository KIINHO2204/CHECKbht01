import { useState, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Upload, Save, Image } from 'lucide-react';
import { useApp } from '@/contexts/AppContext';
import { useToast } from '@/hooks/use-toast';
import AdminLayout from '@/components/AdminLayout';

const FileHeader = () => {
  const { state, dispatch } = useApp();
  const { toast } = useToast();
  
  const [formData, setFormData] = useState({
    companyName: state.headerSettings?.companyName || '',
    cnpj: state.headerSettings?.cnpj || '',
    address: state.headerSettings?.address || '',
    validity: state.headerSettings?.validity || '',
    description: state.headerSettings?.description || '',
    logo: state.headerSettings?.logo || null,
  });

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleLogoUpload = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        const result = e.target?.result as string;
        setFormData(prev => ({ ...prev, logo: result }));
      };
      reader.readAsDataURL(file);
    }
  }, []);

  const handleSave = () => {
    dispatch({
      type: 'UPDATE_HEADER_SETTINGS',
      payload: formData,
    });
    
    toast({
      title: 'Configurações salvas',
      description: 'As configurações do cabeçalho foram atualizadas com sucesso.',
    });
  };

  return (
    <AdminLayout currentPage="header">
      <div className="space-y-6">
        <div>
          <h2 className="text-3xl font-bold tracking-tight text-foreground">
            Configurações do Cabeçalho
          </h2>
          <p className="text-muted-foreground">
            Configure as informações que aparecerão no cabeçalho dos relatórios gerados
          </p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Image className="w-5 h-5" />
              Informações da Empresa
            </CardTitle>
            <CardDescription>
              Defina as informações da sua empresa que aparecerão nos relatórios
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Upload de Logo */}
            <div className="space-y-2">
              <Label htmlFor="logo">Logo da Empresa</Label>
              <div className="flex items-center gap-4">
                {formData.logo && (
                  <div className="w-20 h-20 border-2 border-dashed border-muted rounded-lg flex items-center justify-center bg-muted/50">
                    <img 
                      src={formData.logo} 
                      alt="Logo da empresa" 
                      className="w-full h-full object-contain rounded-lg"
                    />
                  </div>
                )}
                <div className="flex-1">
                  <Input
                    id="logo"
                    type="file"
                    accept="image/*"
                    onChange={handleLogoUpload}
                    className="hidden"
                  />
                  <Button
                    variant="outline"
                    onClick={() => document.getElementById('logo')?.click()}
                    className="w-full"
                  >
                    <Upload className="w-4 h-4 mr-2" />
                    {formData.logo ? 'Alterar Logo' : 'Selecionar Logo'}
                  </Button>
                </div>
              </div>
            </div>

            {/* Nome da Empresa */}
            <div className="space-y-2">
              <Label htmlFor="companyName">Nome da Empresa</Label>
              <Input
                id="companyName"
                placeholder="Digite o nome da empresa"
                value={formData.companyName}
                onChange={(e) => handleInputChange('companyName', e.target.value)}
              />
            </div>

            {/* CNPJ */}
            <div className="space-y-2">
              <Label htmlFor="cnpj">CNPJ</Label>
              <Input
                id="cnpj"
                placeholder="00.000.000/0001-00"
                value={formData.cnpj}
                onChange={(e) => handleInputChange('cnpj', e.target.value)}
              />
            </div>

            {/* Endereço */}
            <div className="space-y-2">
              <Label htmlFor="address">Endereço</Label>
              <Textarea
                id="address"
                placeholder="Digite o endereço completo da empresa"
                value={formData.address}
                onChange={(e) => handleInputChange('address', e.target.value)}
                rows={3}
              />
            </div>

            {/* Vigência */}
            <div className="space-y-2">
              <Label htmlFor="validity">Vigência</Label>
              <Input
                id="validity"
                placeholder="Ex: Janeiro 2024 - Dezembro 2024"
                value={formData.validity}
                onChange={(e) => handleInputChange('validity', e.target.value)}
              />
            </div>

            {/* Texto Descritivo */}
            <div className="space-y-2">
              <Label htmlFor="description">Texto Descritivo</Label>
              <Textarea
                id="description"
                placeholder="Digite um texto descritivo que aparecerá no cabeçalho"
                value={formData.description}
                onChange={(e) => handleInputChange('description', e.target.value)}
                rows={4}
              />
            </div>

            <Button onClick={handleSave} className="w-full">
              <Save className="w-4 h-4 mr-2" />
              Salvar Configurações
            </Button>
          </CardContent>
        </Card>
      </div>
    </AdminLayout>
  );
};

export default FileHeader;
import { useState, useEffect, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { useApp } from '@/contexts/AppContext';
import { ThemeToggle } from '@/components/ThemeToggle';
import { 
  LogOut, 
  Camera, 
  Check, 
  X, 
  ArrowLeft, 
  MessageCircle,
  Clock,
  User,
  Car,
  Loader2,
  Sparkles,
  Activity,
  Settings,
  LightbulbIcon
} from 'lucide-react';
import { toast } from '@/hooks/use-toast';
import { capturePhoto } from '@/utils/imageUpload';
import ChatMessage from '@/components/ChatMessage';
import TypingIndicator from '@/components/TypingIndicator';
import CancelOperationDialog from '@/components/CancelOperationDialog';

interface Message {
  id: string;
  type: 'bot' | 'user' | 'system';
  content: string;
  timestamp: Date;
  options?: string[];
  requiresPhoto?: boolean;
  isLoading?: boolean;
}

type ChatStep = 
  | 'greeting' 
  | 'operator_selection' 
  | 'selfie' 
  | 'vehicle_selection' 
  | 'ready_check' 
  | 'checklist' 
  | 'checklist_finished'
  | 'travel_guide_start'
  | 'travel_guide_confirm'
  | 'travel_guide_km_start'
  | 'travel_guide_front_photo'
  | 'travel_guide_rear_photo'
  | 'travel_guide_start_selfie'
  | 'travel_guide_active'
  | 'travel_guide_forgotten'
  | 'travel_guide_km_end'
  | 'travel_guide_end_front_photo'
  | 'travel_guide_end_rear_photo'
  | 'travel_guide_end_selfie'
  | 'finished';

const OperatorChat = () => {
  const { state, dispatch, addTravelGuide, updateTravelGuide } = useApp();
  const [messages, setMessages] = useState<Message[]>([]);
  const [currentStep, setCurrentStep] = useState<ChatStep>('greeting');
  const [selectedOperator, setSelectedOperator] = useState<string>('');
  const [selectedVehicle, setSelectedVehicle] = useState<string>('');
  const [currentChecklistItem, setCurrentChecklistItem] = useState(0);
  const [checklistResponses, setChecklistResponses] = useState<any[]>([]);
  const [operatorSelfie, setOperatorSelfie] = useState<string>('');
  const [capturedPhotos, setCapturedPhotos] = useState<{ [itemId: string]: string }>({});
  const [vehicleSearch, setVehicleSearch] = useState<string>('');
  const [currentTravelGuide, setCurrentTravelGuide] = useState<string | null>(null);
  const [kmStart, setKmStart] = useState<string>('');
  const [kmEnd, setKmEnd] = useState<string>('');
  const [operatorEndSelfie, setOperatorEndSelfie] = useState<string>('');
  const [operatorStartSelfie, setOperatorStartSelfie] = useState<string>('');
  const [forgottenEndTime, setForgottenEndTime] = useState<string>('');
  const [startTime, setStartTime] = useState<Date | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isTyping, setIsTyping] = useState(false);
  const [showCancelDialog, setShowCancelDialog] = useState(false);
  const [frontPhotoStart, setFrontPhotoStart] = useState<string>('');
  const [rearPhotoStart, setRearPhotoStart] = useState<string>('');
  const [frontPhotoEnd, setFrontPhotoEnd] = useState<string>('');
  const [rearPhotoEnd, setRearPhotoEnd] = useState<string>('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const handleTakePhoto = async (itemId: string) => {
    try {
      const result = await capturePhoto();
      setCapturedPhotos(prev => ({ ...prev, [itemId]: result.url }));
      addMessage('user', 'Foto tirada ✓');
      toast({
        title: "Foto capturada",
        description: "Foto do item registrada com sucesso.",
      });
    } catch (error) {
      toast({
        title: "Erro ao capturar foto",
        description: error instanceof Error ? error.message : "Erro desconhecido",
        variant: "destructive"
      });
    }
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  useEffect(() => {
    // Initialization code if needed
  }, []);

  useEffect(() => {
    const hour = new Date().getHours();
    let greeting = 'Bom dia';
    if (hour >= 12 && hour < 18) greeting = 'Boa tarde';
    if (hour >= 18) greeting = 'Boa noite';

    const welcomeMessage = {
      id: `welcome-${Date.now()}`,
      type: 'bot' as const,
      content: `${greeting}! 👋\n\nSou seu assistente para inspeção veicular. Vou te guiar através do processo de check-list de forma rápida e segura.\n\n✅ Identificação do operador\n✅ Seleção do veículo  \n✅ Check-list completo\n✅ Guia de marcha\n\nVamos começar?`,
      timestamp: new Date()
    };

    setMessages([welcomeMessage]);
    
    setTimeout(() => {
      setCurrentStep('operator_selection');
      const operatorMessage = {
        id: `operator-select-${Date.now()}`,
        type: 'bot' as const,
        content: '👤 **IDENTIFICAÇÃO DO OPERADOR**\n\nPara iniciar o processo, preciso que você se identifique. Selecione seu nome na lista abaixo:',
        timestamp: new Date(),
        options: state.operators?.map(op => op.name) || []
      };
      setMessages(prev => [...prev, operatorMessage]);
    }, 1500);
  }, [state.operators]);

  const addMessage = (type: 'bot' | 'user' | 'system', content: string, options?: string[], requiresPhoto?: boolean, isLoading?: boolean) => {
    const newMessage: Message = {
      id: `${type}-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      type,
      content,
      timestamp: new Date(),
      options,
      requiresPhoto,
      isLoading
    };
    setMessages(prev => [...prev, newMessage]);
  };

  const addTypingIndicator = () => {
    setIsTyping(true);
    const typingMessage: Message = {
      id: `typing-${Date.now()}`,
      type: 'bot',
      content: '',
      timestamp: new Date(),
      isLoading: true
    };
    setMessages(prev => [...prev, typingMessage]);
  };

  const removeTypingIndicator = () => {
    setIsTyping(false);
    setMessages(prev => prev.filter(msg => !msg.isLoading));
  };

  const addBotMessageWithDelay = (content: string, options?: string[], requiresPhoto?: boolean, delay: number = 1000) => {
    if (isTyping) return; // Prevent multiple typing indicators
    
    addTypingIndicator();
    setTimeout(() => {
      removeTypingIndicator();
      addMessage('bot', content, options, requiresPhoto);
    }, delay);
  };

  const handleOperatorSelection = (operatorName: string) => {
    const operator = state.operators.find(op => op.name === operatorName);
    if (operator) {
      setSelectedOperator(operator.id);
      addMessage('user', `✅ ${operatorName}`);
      setCurrentStep('selfie');
      setVehicleSearch(''); 
      addBotMessageWithDelay('🎯 **CONFIRMAÇÃO DE IDENTIDADE**\n\nPerfeito! Agora preciso confirmar sua identidade por motivos de segurança.\n\n📸 Tire uma selfie clara para prosseguir com a inspeção.', [], false, 1000);
    }
  };

  const handleSelfie = async () => {
    console.log('🔄 Iniciando handleSelfie (autenticação)');
    setIsLoading(true);
    
    try {
      console.log('📸 Capturando foto de identificação...');
      const result = await capturePhoto();
      console.log('✅ Foto de identificação capturada:', result);
      
      setOperatorSelfie(result.url);
      addMessage('user', '📸 Selfie capturada ✓');
      
      toast({
        title: "✅ Identidade confirmada",
        description: "Foto registrada com sucesso. Prosseguindo...",
      });
      
      console.log('🚀 Prosseguindo para seleção de veículo');
      setCurrentStep('vehicle_selection');
      addBotMessageWithDelay('🚗 **SELEÇÃO DO VEÍCULO**\n\nIdentidade confirmada com sucesso! Agora vamos selecionar o veículo que será inspecionado.\n\n🔍 Escolha o veículo pela placa e modelo:', 
        state.vehicles.map(v => `${v.plate} - ${v.model}`), false, 1000);
        
    } catch (error) {
      console.error('❌ Erro ao capturar selfie de identificação:', error);
      const errorMessage = error instanceof Error ? error.message : "Erro desconhecido";
      
      toast({
        title: "Erro ao capturar selfie",
        description: errorMessage,
        variant: "destructive"
      });
      
      // Não adicionar mensagem de erro no chat para não poluir
      console.log('❌ Erro capturado, usuário pode tentar novamente');
    } finally {
      setIsLoading(false);
    }
  };


  const handleVehicleSelection = (vehicleInfo: string) => {
    const plate = vehicleInfo.split(' - ')[0];
    const vehicle = state.vehicles.find(v => v.plate === plate);
    if (vehicle) {
      setSelectedVehicle(vehicle.id);
      addMessage('user', `🚗 ${vehicleInfo}`);
      
      
      // Verificar se já existe checklist do dia para este veículo
      const today = new Date().toDateString();
      const existingChecklist = state.checklistResults.find(
        result => result.vehicleId === vehicle.id && 
        new Date(result.createdAt).toDateString() === today
      );
      
      if (existingChecklist) {
        setTimeout(() => {
          addMessage('bot', '⚠️ **VEÍCULO JÁ INSPECIONADO**\n\nEste veículo já teve seu check-list realizado hoje. Vou prosseguir diretamente para o controle da Guia de Marcha.\n\n📋 Preparando dados da operação...');
          setTimeout(() => {
            startTravelGuide();
          }, 1000);
        }, 500);
      } else {
        setTimeout(() => {
          setCurrentStep('ready_check');
          addMessage('bot', '🔍 **PREPARAÇÃO PARA INSPEÇÃO**\n\nVeículo selecionado com sucesso! Vamos iniciar a inspeção de segurança.\n\n⚠️ **IMPORTANTE:** Certifique-se de que:\n• O veículo está estacionado em local seguro\n• Você tem acesso a todas as partes do veículo\n• Está com equipamentos de segurança\n\nEstá pronto para iniciar?', ['✅ SIM, ESTOU PRONTO', '⬅️ VOLTAR']);
        }, 800);
      }
    }
  };

  const handleReadyCheck = (response: string) => {
    if (response === '✅ SIM, ESTOU PRONTO') {
      addMessage('user', '✅ Sim, estou pronto!');
      setTimeout(() => {
        setCurrentStep('checklist');
        startChecklist();
      }, 500);
    } else {
      addMessage('user', '⬅️ Voltar');
      setTimeout(() => {
        setCurrentStep('vehicle_selection');
        setVehicleSearch('');
        addMessage('bot', '🚗 **SELEÇÃO DO VEÍCULO**\n\nSem problemas! Vamos selecionar o veículo novamente.\n\n🔍 Escolha o veículo pela placa e modelo:', 
          state.vehicles.map(v => `${v.plate} - ${v.model}`));
      }, 500);
    }
  };

  const startChecklist = () => {
    const checklist = state.checklists[0];
    if (checklist && checklist.items.length > 0) {
      const firstItem = checklist.items[0];
      const options = ['✅ CONFORME', '❌ NÃO CONFORME', '⬅️ VOLTAR'];
      addMessage('bot', `🔍 **INSPEÇÃO DE SEGURANÇA** - Item 1/${checklist.items.length}\n\n**${firstItem.question}**\n\n${firstItem.requiresPhoto ? '📸 *Este item requer foto como evidência*' : ''}`, options, firstItem.requiresPhoto);
    }
  };

  const handleChecklistResponse = (response: string) => {
    const checklist = state.checklists[0];
    const currentItem = checklist.items[currentChecklistItem];
    
    if (response === '⬅️ VOLTAR') {
      if (currentChecklistItem > 0) {
        setCurrentChecklistItem(currentChecklistItem - 1);
        const prevItem = checklist.items[currentChecklistItem - 1];
        addMessage('user', '⬅️ Voltar');
        setTimeout(() => {
          addMessage('bot', `🔍 **INSPEÇÃO DE SEGURANÇA** - Item ${currentChecklistItem}/${checklist.items.length}\n\n**${prevItem.question}**\n\n${prevItem.requiresPhoto ? '📸 *Este item requer foto como evidência*' : ''}`, ['✅ CONFORME', '❌ NÃO CONFORME', '⬅️ VOLTAR'], prevItem.requiresPhoto);
        }, 500);
      }
      return;
    }

    // Salvar resposta
    const answerText = response === '✅ CONFORME' ? 'CONFORME' : 'NÃO CONFORME';
    const newResponse = {
      itemId: currentItem.id,
      answer: answerText,
      photo: currentItem.requiresPhoto ? capturedPhotos[currentItem.id] : undefined
    };
    
    setChecklistResponses(prev => [...prev, newResponse]);
    addMessage('user', response);

    // Gerar ocorrência se não conforme
    if (answerText === 'NÃO CONFORME') {
      const occurrence = {
        id: Date.now().toString(),
        checklistId: checklist.id,
        vehicleId: selectedVehicle,
        operatorId: selectedOperator,
        itemId: currentItem.id,
        description: `❌ Item não conforme: ${currentItem.question}`,
        photo: currentItem.requiresPhoto ? capturedPhotos[currentItem.id] : undefined,
        status: 'pending' as const,
        createdAt: new Date().toISOString()
      };
      dispatch({ type: 'ADD_OCCURRENCE', payload: occurrence });
    }

    // Próxima pergunta ou finalizar
    if (currentChecklistItem + 1 < checklist.items.length) {
      setCurrentChecklistItem(currentChecklistItem + 1);
      const nextItem = checklist.items[currentChecklistItem + 1];
      setTimeout(() => {
        addMessage('bot', `🔍 **INSPEÇÃO DE SEGURANÇA** - Item ${currentChecklistItem + 2}/${checklist.items.length}\n\n**${nextItem.question}**\n\n${nextItem.requiresPhoto ? '📸 *Este item requer foto como evidência*' : ''}`, ['✅ CONFORME', '❌ NÃO CONFORME', '⬅️ VOLTAR'], nextItem.requiresPhoto);
      }, 800);
    } else {
      finishChecklist();
    }
  };

  const finishChecklist = () => {
    setCurrentStep('checklist_finished');
    
    // Salvar resultado do checklist
    const result = {
      id: Date.now().toString(),
      checklistId: state.checklists[0].id,
      vehicleId: selectedVehicle,
      operatorId: selectedOperator,
      operatorSelfie,
      responses: checklistResponses,
      createdAt: new Date().toISOString()
    };
    
    dispatch({ type: 'ADD_CHECKLIST_RESULT', payload: result });
    dispatch({ type: 'INCREMENT_OPERATOR_INSPECTIONS', payload: selectedOperator });
    
    const conformeCount = checklistResponses.filter(r => r.answer === 'CONFORME').length;
    const naoConformeCount = checklistResponses.filter(r => r.answer === 'NÃO CONFORME').length;
    
    setTimeout(() => {
      addMessage('bot', `🎉 **INSPEÇÃO CONCLUÍDA**\n\n✅ Check-list finalizado com sucesso!\n📊 **Resultado:**\n• Itens conformes: ${conformeCount}\n• Itens não conformes: ${naoConformeCount}\n\n📋 Relatório gerado automaticamente`);
      addMessage('system', '📤 Dados enviados para a central administrativa');
      setTimeout(() => {
        startTravelGuide();
      }, 1500);
    }, 800);
  };

  const startTravelGuide = () => {
    setCurrentStep('travel_guide_start');
    const operator = state.operators.find(o => o.id === selectedOperator);
    const vehicle = state.vehicles.find(v => v.id === selectedVehicle);
    
    setTimeout(() => {
      addMessage('bot', `🚛 **CONTROLE DE GUIA DE MARCHA**\n\nInspeção finalizada! Agora vamos iniciar o controle operacional.\n\n👤 **Operador:** ${operator?.name}\n🚗 **Veículo:** ${vehicle?.plate} - ${vehicle?.model}`);
      setTimeout(() => {
        addMessage('bot', `🔐 **CONFIRMAÇÃO DOS DADOS**\n\nDados verificados e confirmados para iniciar a operação.\n\n⚠️ **IMPORTANTE:** Uma vez iniciada a operação, ela deve ser finalizada adequadamente.`, ['🚀 INICIAR OPERAÇÃO', '❌ ENCERRAR CHAT']);
        setCurrentStep('travel_guide_confirm');
      }, 1200);
    }, 800);
  };

  const handleTravelGuideStart = () => {
    // Verificar se já existe operação ativa
    const activeGuide = state.travelGuides.find(
      guide => guide.operatorId === selectedOperator && guide.status === 'active'
    );
    
    if (activeGuide) {
      setCurrentTravelGuide(activeGuide.id);
      setCurrentStep('travel_guide_forgotten');
      addMessage('bot', 'Detectamos que você tem uma operação em andamento que não foi finalizada.');
      addMessage('bot', 'Para iniciar uma nova operação, você precisa finalizar a anterior.');
      addMessage('bot', 'Deseja finalizar a operação anterior?', ['ESQUECI DE FINALIZAR ANTERIOR', 'CANCELAR INÍCIO']);
    } else {
      setCurrentStep('travel_guide_km_start');
      addMessage('bot', 'Para iniciar a operação, informe a quilometragem atual do veículo:');
    }
  };

  const handleKmStart = (km: string) => {
    const kmValue = parseFloat(km);
    if (isNaN(kmValue) || kmValue < 0) {
      addMessage('bot', 'Por favor, informe uma quilometragem válida.');
      return;
    }

    const vehicle = state.vehicles.find(v => v.id === selectedVehicle);
    if (vehicle && kmValue < vehicle.currentKm) {
      addMessage('bot', `A quilometragem informada (${kmValue} km) é menor que a quilometragem atual do veículo (${vehicle.currentKm} km). Por favor, informe uma quilometragem válida.`);
      return;
    }

    setKmStart(km);
    addMessage('user', `${km} km`);
    
    setTimeout(() => {
      setCurrentStep('travel_guide_front_photo');
      addMessage('bot', 'Agora tire uma foto da frente do veículo:', [], true);
    }, 500);
  };

  const handleFrontPhotoStart = async () => {
    try {
      const result = await capturePhoto();
      setFrontPhotoStart(result.url);
      addMessage('user', 'Foto da frente tirada ✓');
      
      setTimeout(() => {
        setCurrentStep('travel_guide_rear_photo');
        addMessage('bot', 'Agora tire uma foto da traseira do veículo:', [], true);
      }, 500);
      
      toast({
        title: "Foto capturada",
        description: "Foto da frente do veículo registrada com sucesso.",
      });
    } catch (error) {
      toast({
        title: "Erro ao capturar foto",
        description: error instanceof Error ? error.message : "Erro desconhecido",
        variant: "destructive"
      });
    }
  };

  const handleRearPhotoStart = async () => {
    try {
      const result = await capturePhoto();
      setRearPhotoStart(result.url);
      addMessage('user', 'Foto da traseira tirada ✓');
      
      setTimeout(() => {
        setCurrentStep('travel_guide_start_selfie');
        addMessage('bot', 'Agora tire uma selfie obrigatória para iniciar a operação:', [], true);
      }, 500);
      
      toast({
        title: "Foto capturada",
        description: "Foto da traseira do veículo registrada com sucesso.",
      });
    } catch (error) {
      toast({
        title: "Erro ao capturar foto",
        description: error instanceof Error ? error.message : "Erro desconhecido",
        variant: "destructive"
      });
    }
  };

  const handleStartSelfie = async () => {
    console.log('🔄 Iniciando handleStartSelfie');
    try {
      console.log('📸 Capturando foto...');
      const result = await capturePhoto();
      console.log('✅ Foto capturada:', result);
      
      setOperatorStartSelfie(result.url);
      addMessage('user', 'Selfie de início tirada ✓');
      
      setStartTime(new Date());
      
      // Criar registro da guia de marcha
      const newGuide = {
        operatorId: selectedOperator,
        vehicleId: selectedVehicle,
        operatorSelfieStart: result.url,
        frontPhotoStart: frontPhotoStart,
        rearPhotoStart: rearPhotoStart,
        kmStart: parseFloat(kmStart),
        startTime: new Date().toISOString(),
        status: 'active' as const
      };

      console.log('💾 Salvando guia de marcha:', newGuide);
      addTravelGuide(newGuide);
      setCurrentTravelGuide(Date.now().toString());
      
      toast({
        title: "Selfie capturada",
        description: "Operação iniciada com sucesso.",
      });
      
      console.log('⏰ Aguardando 500ms para mudar para travel_guide_active...');
      setTimeout(() => {
        console.log('🚀 Mudando para travel_guide_active');
        setCurrentStep('travel_guide_active');
        addMessage('bot', 'Operação iniciada com sucesso! 🚀');
        console.log('✅ Fluxo concluído');
      }, 500);
    } catch (error) {
      console.error('❌ Erro em handleStartSelfie:', error);
      toast({
        title: "Erro ao capturar selfie",
        description: error instanceof Error ? error.message : "Erro desconhecido",
        variant: "destructive"
      });
    }
  };

  const checkForActiveGuide = () => {
    const activeGuide = state.travelGuides.find(
      guide => guide.operatorId === selectedOperator && guide.status === 'active'
    );
    
    if (activeGuide) {
      setCurrentTravelGuide(activeGuide.id);
      setCurrentStep('travel_guide_forgotten');
      addMessage('bot', 'Detectamos que você tem uma operação em andamento que não foi finalizada.');
      addMessage('bot', 'Para iniciar uma nova operação, você precisa finalizar a anterior.');
      addMessage('bot', 'Preencha os dados da operação anterior:', ['FINALIZAR OPERAÇÃO ANTERIOR', 'VOLTAR']);
    } else {
      handleTravelGuideStart();
    }
  };

  const handleForgottenEnd = () => {
    const activeGuide = state.travelGuides.find(g => g.id === currentTravelGuide);
    if (activeGuide) {
      setKmStart(activeGuide.kmStart.toString());
    }
    setCurrentStep('travel_guide_km_end');
    addMessage('bot', 'Informe a quilometragem final da operação anterior:');
  };

  const handleCancelOperation = () => {
    setShowCancelDialog(false);
    
    // Limpar todos os dados da operação atual sem salvar NENHUM registro
    // Resetar completamente o chat para a página inicial
    setCurrentStep('greeting');
    setIsLoading(false);
    setIsTyping(false);
    
    // Limpar TODOS os dados da operação
    setSelectedOperator('');
    setSelectedVehicle('');
    setOperatorSelfie('');
    setKmStart('');
    setKmEnd('');
    setOperatorStartSelfie('');
    setOperatorEndSelfie('');
    setFrontPhotoStart('');
    setRearPhotoStart('');
    setFrontPhotoEnd('');
    setRearPhotoEnd('');
    setForgottenEndTime('');
    setCurrentTravelGuide(null);
    setStartTime(null);
    setCapturedPhotos({});
    setChecklistResponses([]);
    setCurrentChecklistItem(0);
    setVehicleSearch('');
    
    // Limpar mensagens e reiniciar o chat
    setMessages([]);
    
    // Reiniciar o chat do zero
    setTimeout(() => {
      const hour = new Date().getHours();
      let greeting = 'Bom dia';
      if (hour >= 12 && hour < 18) greeting = 'Boa tarde';
      if (hour >= 18) greeting = 'Boa noite';

      const welcomeMessage = {
        id: `welcome-${Date.now()}`,
        type: 'bot' as const,
        content: `${greeting}! Bem-vindo ao sistema de check-list veicular. Vamos começar?`,
        timestamp: new Date()
      };

      setMessages([welcomeMessage]);
      
      setTimeout(() => {
        setCurrentStep('operator_selection');
        const operatorMessage = {
          id: `operator-select-${Date.now()}`,
          type: 'bot' as const,
          content: 'Por favor, selecione seu nome da lista abaixo:',
          timestamp: new Date(),
          options: state.operators?.map(op => op.name) || []
        };
        setMessages(prev => [...prev, operatorMessage]);
      }, 1000);
    }, 500);
  };

  const handleShowCancelDialog = () => {
    setShowCancelDialog(true);
  };

  const handleKmEnd = (km: string, isForgotten: boolean = false) => {
    const kmValue = parseFloat(km);
    if (isNaN(kmValue) || kmValue < 0) {
      addMessage('bot', 'Por favor, informe uma quilometragem válida.');
      return;
    }

    const startKmValue = parseFloat(kmStart) || 0;
    const activeGuide = state.travelGuides.find(g => g.id === currentTravelGuide);
    const guideStartKm = activeGuide?.kmStart || startKmValue;

    if (kmValue < guideStartKm) {
      addMessage('bot', `A quilometragem final (${kmValue} km) deve ser maior ou igual à quilometragem inicial (${guideStartKm} km). Por favor, informe uma quilometragem válida.`);
      return;
    }

    setKmEnd(km);
    addMessage('user', `${km} km`);
    
    if (isForgotten) {
      addMessage('bot', 'Agora informe o horário estimado de encerramento da operação anterior (HH:MM):');
    } else {
      addMessage('bot', 'Agora tire uma foto da frente do veículo para finalizar:', [], true);
      setCurrentStep('travel_guide_end_front_photo');
    }
  };

  const handleFrontPhotoEnd = async () => {
    try {
      const result = await capturePhoto();
      setFrontPhotoEnd(result.url);
      addMessage('user', 'Foto da frente tirada ✓');
      
      setTimeout(() => {
        setCurrentStep('travel_guide_end_rear_photo');
        addMessage('bot', 'Agora tire uma foto da traseira do veículo:', [], true);
      }, 500);
      
      toast({
        title: "Foto capturada",
        description: "Foto da frente do veículo registrada com sucesso.",
      });
    } catch (error) {
      toast({
        title: "Erro ao capturar foto",
        description: error instanceof Error ? error.message : "Erro desconhecido",
        variant: "destructive"
      });
    }
  };

  const handleRearPhotoEnd = async () => {
    try {
      const result = await capturePhoto();
      setRearPhotoEnd(result.url);
      addMessage('user', 'Foto da traseira tirada ✓');
      
      setTimeout(() => {
        setCurrentStep('travel_guide_end_selfie');
        addMessage('bot', 'Agora tire uma selfie obrigatória para finalizar a operação:', [], true);
      }, 500);
      
      toast({
        title: "Foto capturada",
        description: "Foto da traseira do veículo registrada com sucesso.",
      });
    } catch (error) {
      toast({
        title: "Erro ao capturar foto",
        description: error instanceof Error ? error.message : "Erro desconhecido",
        variant: "destructive"
      });
    }
  };

  const handleEndSelfie = async () => {
    console.log('🔄 Iniciando handleEndSelfie (finalização)');
    try {
      console.log('📸 Capturando foto de encerramento...');
      const result = await capturePhoto();
      console.log('✅ Foto de encerramento capturada:', result);
      
      setOperatorEndSelfie(result.url);
      addMessage('user', 'Selfie de encerramento tirada ✓');
      
      // Finalizar a guia de marcha
      finalizeTravelGuide();
      
      toast({
        title: "Selfie capturada",
        description: "Selfie de encerramento registrada com sucesso.",
      });
    } catch (error) {
      console.error('❌ Erro ao capturar selfie de encerramento:', error);
      const errorMessage = error instanceof Error ? error.message : "Erro desconhecido";
      
      toast({
        title: "Erro ao capturar selfie",
        description: errorMessage,
        variant: "destructive"
      });
      
      // Adicionar mensagem no chat para orientar o usuário
      addMessage('bot', `Erro ao capturar selfie: ${errorMessage}. Tente novamente.`);
    }
  };

  const finalizeTravelGuide = () => {
    if (!currentTravelGuide) return;
    
    const guide = state.travelGuides.find(g => g.id === currentTravelGuide);
    if (!guide) return;

    const updatedGuide = {
      ...guide,
      kmEnd: parseFloat(kmEnd),
      endTime: new Date().toISOString(),
      operatorSelfieEnd: operatorEndSelfie,
      status: 'completed' as const,
      completedAt: new Date().toISOString()
    };

    updateTravelGuide(updatedGuide);
    
    setCurrentStep('finished');
    setTimeout(() => {
      addMessage('bot', 'Operação finalizada com sucesso! 🎉');
      addMessage('system', 'Guia de marcha enviada para a central do ADM');
      setTimeout(() => {
        const operator = state.operators.find(o => o.id === selectedOperator);
        addMessage('bot', `Obrigado, ${operator?.name}! Tenha um excelente trabalho! ✨`);
      }, 1000);
    }, 500);
  };

  const handleForgottenTime = (time: string) => {
    setForgottenEndTime(time);
    addMessage('user', time);
    
    setTimeout(() => {
      addMessage('bot', 'Agora tire uma selfie obrigatória para confirmar o encerramento:', [], true);
      setCurrentStep('travel_guide_end_selfie');
    }, 500);
  };

  const finalizeForgottenGuide = () => {
    if (!currentTravelGuide) return;
    
    const guide = state.travelGuides.find(g => g.id === currentTravelGuide);
    if (!guide) return;

    const [hours, minutes] = forgottenEndTime.split(':');
    const endDate = new Date();
    endDate.setHours(parseInt(hours), parseInt(minutes), 0, 0);

    const updatedGuide = {
      ...guide,
      kmEnd: parseFloat(kmEnd),
      endTime: endDate.toISOString(),
      operatorSelfieEnd: operatorEndSelfie,
      status: 'forgotten_end' as const,
      completedAt: new Date().toISOString()
    };

    updateTravelGuide(updatedGuide);
    
    setTimeout(() => {
      addMessage('bot', 'Operação anterior finalizada! Agora você pode iniciar uma nova operação.');
      setTimeout(() => {
        handleTravelGuideStart();
      }, 1000);
    }, 500);
  };

  const handleLogout = () => {
    dispatch({ type: 'SET_USER', payload: null });
  };

  const getFilteredVehicles = () => {
    if (!state?.vehicles) return [];
    if (!vehicleSearch) return state.vehicles;
    
    return state.vehicles.filter(vehicle => 
      vehicle.plate.toLowerCase().includes(vehicleSearch.toLowerCase()) ||
      vehicle.model.toLowerCase().includes(vehicleSearch.toLowerCase())
    );
  };

  const renderOptions = (options: string[], requiresPhoto?: boolean) => {
    const checklist = state.checklists[0];
    const currentItem = checklist?.items[currentChecklistItem];
    const photoTaken = currentItem && capturedPhotos[currentItem.id];
    
    return (
      <div className="space-y-3 sm:space-y-4 mt-3 sm:mt-4">
        {/* Mobile-optimized Vehicle Search Filter */}
        {currentStep === 'vehicle_selection' && (
          <div className="space-y-2 p-3 bg-card rounded-lg border">
            <Input
              placeholder="Buscar por placa ou modelo..."
              value={vehicleSearch}
              onChange={(e) => setVehicleSearch(e.target.value)}
              className="w-full h-12 sm:h-auto text-base sm:text-sm"
              inputMode="text"
              autoComplete="off"
            />
            <p className="text-xs text-muted-foreground">
              {getFilteredVehicles().length} veículo(s) encontrado(s)
            </p>
          </div>
        )}
        
        {/* Mobile-optimized Photo Capture Section */}
        {requiresPhoto && currentItem && (
          <div className="p-3 sm:p-4 bg-card/50 rounded-lg border border-dashed border-primary/30">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Camera className="w-5 h-5 text-primary" />
                <span className="text-sm font-medium">Foto obrigatória</span>
              </div>
              {photoTaken && (
                <div className="flex items-center gap-2 text-xs text-success">
                  <Check className="w-4 h-4" />
                  <span className="hidden sm:inline">Foto capturada</span>
                </div>
              )}
            </div>
            
            <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3">
              <Button
                variant={photoTaken ? "secondary" : "default"}
                size="sm"
                onClick={() => handleTakePhoto(currentItem.id)}
                className="flex items-center gap-2 w-full sm:w-auto h-12 sm:h-auto"
              >
                <Camera className="w-4 h-4" />
                {photoTaken ? 'Tirar nova foto' : 'Tirar Foto'}
              </Button>
              
              {photoTaken && (
                <div className="flex items-center gap-3 w-full sm:w-auto">
                  <img 
                    src={photoTaken} 
                    alt="Foto capturada" 
                    className="w-16 h-16 sm:w-12 sm:h-12 object-cover rounded border-2 border-success"
                  />
                  <div className="text-xs text-muted-foreground">
                    <p className="font-medium">Foto capturada</p>
                    <p>{new Date().toLocaleTimeString()}</p>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
        
        {/* Mobile-optimized Options Buttons */}
        <div className="space-y-2 sm:space-y-3">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:flex lg:flex-wrap gap-2 sm:gap-3">
            {(currentStep === 'vehicle_selection' ? 
              getFilteredVehicles().map(v => `${v.plate} - ${v.model}`) : 
              options
            ).map((option, index) => (
              <Button
                key={`${currentStep}-${option}-${index}`}
                variant={
                  option.includes('❌') || option.includes('NÃO CONFORME') ? 'destructive' : 
                  option.includes('✅') || option.includes('CONFORME') || option.includes('SIM') ? 'default' : 
                  option.includes('⬅️') || option.includes('VOLTAR') ? 'outline' : 
                  option.includes('🚀') ? 'default' : 'secondary'
                }
                size="sm"
                className="chat-button-hover focus-glow animate-bounce-in transition-all active:scale-95 hover:scale-105 min-h-12 sm:min-h-auto min-w-[100px] text-sm sm:text-xs lg:text-sm"
                style={{ animationDelay: `${index * 150}ms` }}
                onClick={() => {
                  if (currentStep === 'operator_selection') {
                    handleOperatorSelection(option);
                  } else if (currentStep === 'vehicle_selection') {
                    handleVehicleSelection(option);
                  } else if (currentStep === 'ready_check') {
                    handleReadyCheck(option);
                  } else if (currentStep === 'checklist') {
                    // Verificar se foto é obrigatória antes de permitir resposta
                    if (requiresPhoto && !photoTaken && option !== 'VOLTAR') {
                      toast({
                        title: "Foto obrigatória",
                        description: "Você deve tirar uma foto antes de responder este item.",
                        variant: "destructive"
                      });
                      return;
                    }
                    handleChecklistResponse(option);
                  } else if (currentStep === 'travel_guide_confirm') {
                    if (option === 'INICIAR OPERAÇÃO') {
                      addMessage('user', 'Iniciar Operação');
                      handleTravelGuideStart();
                    } else if (option === 'ENCERRAR CHAT') {
                      addMessage('user', 'Encerrar Chat');
                      setTimeout(() => {
                        setCurrentStep('finished');
                        const operator = state.operators.find(o => o.id === selectedOperator);
                        addMessage('bot', `Obrigado, ${operator?.name}! Até a próxima! 👋`);
                      }, 500);
                    }
                  } else if (currentStep === 'travel_guide_forgotten') {
                    if (option === 'ESQUECI DE FINALIZAR ANTERIOR') {
                      addMessage('user', 'Esqueci de Finalizar Anterior');
                      handleForgottenEnd();
                     } else if (option === 'CANCELAR INÍCIO') {
                       addMessage('user', 'Cancelar Início');
                       handleShowCancelDialog();
                     }
                  }
                }}
                disabled={requiresPhoto && !photoTaken && option !== 'VOLTAR'}
              >
                {option === 'CONFORME' && <Check className="w-4 h-4 mr-1" />}
                {option === 'NÃO CONFORME' && <X className="w-4 h-4 mr-1" />}
                {option === 'VOLTAR' && <ArrowLeft className="w-4 h-4 mr-1" />}
                <span className="truncate">{option}</span>
              </Button>
            ))}
          </div>
          
          {/* Photo requirement indicator */}
          {requiresPhoto && !photoTaken && (
            <div className="p-2 bg-amber-50 dark:bg-amber-900/20 rounded-lg border border-amber-200 dark:border-amber-800">
              <p className="text-xs text-amber-700 dark:text-amber-400 flex items-center gap-1">
                <Camera className="w-3 h-3" />
                Tire uma foto antes de responder
              </p>
            </div>
          )}
        </div>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-info/20 via-background to-success/20 overflow-x-hidden">
      {/* Mobile-optimized Header */}
      <header className="bg-card border-b shadow-sm sticky top-0 z-50 safe-area-inset-top">
        <div className="px-3 sm:px-4 py-2 sm:py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 sm:gap-3">
              <div className="p-2 bg-gradient-primary rounded-lg">
                <MessageCircle className="w-5 h-5 sm:w-6 sm:h-6 text-white" />
              </div>
              <div>
                <h1 className="text-lg sm:text-xl md:text-2xl font-bold text-foreground">Check-list Interativo</h1>
                <p className="text-xs sm:text-sm text-muted-foreground">Sistema do Operador</p>
              </div>
            </div>
            
            {/* Progress Indicator */}
            {currentStep === 'checklist' && (
              <div className="hidden sm:flex items-center gap-2 text-sm text-muted-foreground">
                <div className="flex items-center gap-1">
                  <div className="w-2 h-2 bg-primary rounded-full"></div>
                  <span>Item {currentChecklistItem + 1} de {state.checklists[0]?.items.length || 0}</span>
                </div>
              </div>
            )}

            <div className="flex items-center gap-2">
              <ThemeToggle />
              
              <Button 
                variant="outline" 
                onClick={handleLogout}
                className="flex items-center gap-2 h-10 min-w-10 sm:h-auto sm:min-w-auto"
                size="sm"
              >
                <LogOut className="w-4 h-4" />
                <span className="hidden sm:inline">Sair</span>
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="flex flex-col h-[calc(100vh-68px)] sm:h-[calc(100vh-80px)]">
        {/* Mobile-optimized Status Bar */}
         <div className="bg-gradient-to-r from-card/80 to-card/60 border-b px-3 sm:px-4 py-2 sm:py-3 backdrop-blur-sm">
           <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 sm:gap-0 text-xs sm:text-sm">
             
             {/* Status Progress Indicator */}
             <div className="flex items-center gap-2 animate-step-progress">
               <div className="flex items-center gap-1">
                 {currentStep === 'greeting' && (
                   <div className="flex items-center gap-2 text-info">
                     <Activity className="w-4 h-4 animate-status-indicator" />
                     <span className="font-medium">Iniciando sistema...</span>
                   </div>
                 )}
                 {currentStep === 'operator_selection' && (
                   <div className="flex items-center gap-2 text-primary">
                     <User className="w-4 h-4 progress-pulse" />
                     <span className="font-medium">Identificação do operador</span>
                   </div>
                 )}
                 {currentStep === 'selfie' && (
                   <div className="flex items-center gap-2 text-warning">
                     <Camera className="w-4 h-4 animate-bounce-in" />
                     <span className="font-medium">Confirmação de identidade</span>
                   </div>
                 )}
                 {currentStep === 'vehicle_selection' && (
                   <div className="flex items-center gap-2 text-primary">
                     <Car className="w-4 h-4 progress-pulse" />
                     <span className="font-medium">Seleção do veículo</span>
                   </div>
                 )}
                 {currentStep === 'ready_check' && (
                   <div className="flex items-center gap-2 text-success">
                     <Check className="w-4 h-4 animate-bounce-in" />
                     <span className="font-medium">Preparação para inspeção</span>
                   </div>
                 )}
                 {currentStep === 'checklist' && (
                   <div className="flex items-center gap-2 text-primary">
                     <Activity className="w-4 h-4 animate-glow" />
                     <span className="font-medium">Inspeção em andamento</span>
                     <div className="ml-2 px-2 py-1 bg-primary/10 rounded-full">
                       <span className="text-xs font-bold">
                         {currentChecklistItem + 1}/{state.checklists[0]?.items.length || 0}
                       </span>
                     </div>
                   </div>
                 )}
                 {(currentStep === 'travel_guide_start' || currentStep === 'travel_guide_confirm') && (
                   <div className="flex items-center gap-2 text-info">
                     <MessageCircle className="w-4 h-4 animate-status-indicator" />
                     <span className="font-medium">Controle de guia de marcha</span>
                   </div>
                 )}
                 {currentStep === 'finished' && (
                   <div className="flex items-center gap-2 text-success">
                     <Check className="w-4 h-4 animate-bounce-in" />
                     <span className="font-medium">Processo concluído</span>
                   </div>
                 )}
               </div>
             </div>

             {/* User and Vehicle Info */}
             <div className="flex items-center gap-3 sm:gap-4">
               {selectedOperator && (
                 <div className="flex items-center gap-2 animate-fade-in-up">
                   <div className="w-2 h-2 bg-success rounded-full animate-status-indicator"></div>
                   <User className="w-4 h-4 text-primary" />
                   <span className="text-muted-foreground truncate max-w-[120px] sm:max-w-none">
                     {state.operators.find(op => op.id === selectedOperator)?.name}
                   </span>
                 </div>
               )}
               {selectedVehicle && (
                 <div className="flex items-center gap-2 animate-fade-in-up">
                   <div className="w-2 h-2 bg-success rounded-full animate-status-indicator"></div>
                   <Car className="w-4 h-4 text-primary" />
                   <span className="text-muted-foreground">
                     {state.vehicles.find(v => v.id === selectedVehicle)?.plate}
                   </span>
                 </div>
               )}
             </div>
           </div>
         </div>

        {/* Mobile-optimized Chat Container */}
        <div className="flex-1 overflow-hidden">
          <div className="h-full px-2 sm:px-4 py-2 sm:py-6">
            <Card className="shadow-elevated bg-gradient-card h-full flex flex-col">
              <CardContent className="p-3 sm:p-6 flex-1 flex flex-col">
                {/* Messages with mobile-optimized scrolling */}
                <div className="flex-1 space-y-3 sm:space-y-4 mb-4 sm:mb-6 overflow-y-auto pr-1 sm:pr-2 scroll-smooth touch-pan-y"
                     style={{ scrollbarWidth: 'thin' }}>
                  
                    {/* AI Suggestions removed */}
                    
                    {/* Typing Indicator */}
                   {isTyping && <TypingIndicator />}
                   
                    {messages.filter(m => !m.isLoading).map((message, index) => (
                      <div
                        key={message.id}
                        className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'} group`}
                        style={{ 
                          animation: `${message.type === 'user' 
                            ? 'message-slide-in-right' 
                            : 'message-slide-in-left'} 0.5s cubic-bezier(0.175, 0.885, 0.32, 1.275)`,
                          animationDelay: `${index * 100}ms`,
                          animationFillMode: 'both'
                        }}
                      >
                       <div className={`flex items-start gap-3 max-w-[85%] ${message.type === 'user' ? 'flex-row-reverse' : ''}`}>
                         {/* Avatar */}
                         <div className={`
                           flex items-center justify-center w-8 h-8 rounded-full flex-shrink-0 transition-all duration-300
                           ${message.type === 'bot' ? 'bg-primary' : 'bg-secondary'}
                           ${message.type === 'user' ? 'animate-pulse' : ''}
                         `}>
                           {message.type === 'bot' ? (
                             <div className="flex items-center justify-center">
                               <Sparkles className="w-4 h-4 text-primary-foreground" />
                             </div>
                           ) : (
                             <User className="w-4 h-4 text-secondary-foreground" />
                           )}
                         </div>

                         {/* Message Content */}
                         <div className={`flex flex-col ${message.type === 'user' ? 'items-end' : 'items-start'}`}>
                            <div
                              className={`
                                px-4 py-3 rounded-2xl shadow-sm transition-all duration-300 hover:shadow-lg chat-message-hover
                                ${message.type === 'user'
                                  ? 'bg-gradient-primary text-white shadow-lg animate-glow'
                                  : message.type === 'system'
                                  ? 'bg-gradient-to-br from-info/10 to-info/20 text-info-foreground border-2 border-info/30 animate-status-indicator'
                                  : 'bg-gradient-to-br from-card to-card/80 text-card-foreground border border-border/50 hover:border-primary/30'
                                }
                                max-w-full word-wrap break-words
                              `}
                            >
                              <div className="text-sm leading-relaxed whitespace-pre-line space-y-1">
                                {message.content.split('\n\n').map((paragraph, idx) => (
                                  <div key={idx} className={`
                                    ${paragraph.includes('**') && paragraph.includes('**') 
                                      ? 'font-bold text-primary' 
                                      : ''
                                    }
                                    ${paragraph.startsWith('• ') || paragraph.startsWith('✅ ') || paragraph.startsWith('❌ ') || paragraph.startsWith('📸 ') || paragraph.startsWith('📊 ') || paragraph.startsWith('⚠️ ')
                                      ? 'pl-2' 
                                      : ''
                                    }
                                  `}>
                                    {paragraph.replace(/\*\*(.*?)\*\*/g, '$1')}
                                  </div>
                                ))}
                              </div>
                            </div>

                           {/* Options */}
                           {message.options && renderOptions(message.options, message.requiresPhoto)}

                           {/* Timestamp */}
                           <div className={`
                             flex items-center gap-2 mt-2 text-xs text-muted-foreground
                             ${message.type === 'user' ? 'flex-row-reverse' : ''}
                           `}>
                             <Clock className="w-3 h-3" />
                             <span className="opacity-70">
                               {message.timestamp.toLocaleTimeString('pt-BR', { 
                                 hour: '2-digit', 
                                 minute: '2-digit' 
                               })}
                             </span>
                           </div>
                         </div>
                       </div>
                     </div>
                   ))}
                   <div ref={messagesEndRef} />
                </div>

                {/* Mobile-optimized Fixed Action Area */}
                <div className="border-t pt-3 sm:pt-4 bg-gradient-to-r from-card/80 to-card/60 backdrop-blur-sm">
                  {/* Special Actions */}
                  {currentStep === 'selfie' && (
                    <div className="text-center animate-bounce-in">
                      <Button
                        onClick={handleSelfie}
                        size="lg"
                        disabled={isLoading}
                        className="bg-gradient-primary hover:opacity-90 flex items-center gap-2 h-12 sm:h-auto w-full sm:w-auto chat-button-hover focus-glow animate-glow transition-all duration-300"
                      >
                        {isLoading ? (
                          <>
                            <Loader2 className="w-5 h-5 animate-spin" />
                            <span className="animate-fade-in-up">Processando...</span>
                          </>
                        ) : (
                          <>
                            <Camera className="w-5 h-5 animate-bounce-in" />
                            <span className="font-medium">📸 Tirar Selfie</span>
                          </>
                        )}
                      </Button>
                      
                      <p className="text-xs text-muted-foreground text-center mt-3 animate-fade-in-up" style={{ animationDelay: '0.3s' }}>
                        🔐 Tire uma selfie em tempo real para confirmar sua identidade
                      </p>
                    </div>
                  )}

                   {currentStep === 'travel_guide_km_start' && (
                     <div className="space-y-4">
                       <div className="flex flex-col sm:flex-row items-center gap-2">
                         <Input
                           type="number"
                           placeholder="Ex: 12500"
                           value={kmStart}
                           onChange={(e) => setKmStart(e.target.value)}
                           className="flex-1 h-12 sm:h-auto text-base sm:text-sm"
                           inputMode="numeric"
                           autoComplete="off"
                         />
                         <Button 
                           onClick={() => handleKmStart(kmStart)}
                           disabled={!kmStart}
                           className="bg-gradient-primary hover:opacity-90 w-full sm:w-auto h-12 sm:h-auto"
                         >
                           Confirmar
                         </Button>
                       </div>
                       <Button
                         onClick={() => {
                           setCurrentStep('travel_guide_confirm');
                           addMessage('bot', 'Voltando para confirmação...', ['INICIAR OPERAÇÃO', 'ENCERRAR CHAT']);
                         }}
                         variant="outline"
                         size="sm"
                         className="w-full flex items-center gap-2 h-12 sm:h-auto"
                       >
                         <ArrowLeft className="w-4 h-4" />
                         Voltar
                       </Button>
                       <p className="text-xs text-muted-foreground text-center">
                         Informe a quilometragem atual do veículo
                       </p>
                     </div>
                    )}

                    {currentStep === 'travel_guide_front_photo' && (
                      <div className="space-y-4">
                        <div className="text-center">
                          <Button
                            onClick={handleFrontPhotoStart}
                            size="lg"
                            className="bg-gradient-primary hover:opacity-90 flex items-center gap-2 w-full sm:w-auto h-12 sm:h-auto"
                          >
                            <Camera className="w-5 h-5" />
                            Tirar Foto da Frente
                          </Button>
                        </div>
                        <p className="text-xs text-muted-foreground text-center">
                          Foto da frente do veículo obrigatória
                        </p>
                      </div>
                    )}

                    {currentStep === 'travel_guide_rear_photo' && (
                      <div className="space-y-4">
                        <div className="text-center">
                          <Button
                            onClick={handleRearPhotoStart}
                            size="lg"
                            className="bg-gradient-primary hover:opacity-90 flex items-center gap-2 w-full sm:w-auto h-12 sm:h-auto"
                          >
                            <Camera className="w-5 h-5" />
                            Tirar Foto da Traseira
                          </Button>
                        </div>
                        <p className="text-xs text-muted-foreground text-center">
                          Foto da traseira do veículo obrigatória
                        </p>
                      </div>
                    )}

                    {currentStep === 'travel_guide_start_selfie' && (
                     <div className="space-y-4">
                       <div className="text-center">
                         <Button
                           onClick={handleStartSelfie}
                           size="lg"
                           className="bg-gradient-primary hover:opacity-90 flex items-center gap-2 w-full sm:w-auto h-12 sm:h-auto"
                         >
                           <Camera className="w-5 h-5" />
                           Tirar Selfie de Início
                         </Button>
                       </div>
                       <Button
                         onClick={() => {
                           setCurrentStep('travel_guide_km_start');
                           addMessage('bot', 'Voltando para informar quilometragem...');
                         }}
                         variant="outline"
                         size="sm"
                         className="w-full flex items-center gap-2 h-12 sm:h-auto"
                       >
                         <ArrowLeft className="w-4 h-4" />
                         Voltar e Corrigir KM
                       </Button>
                       <p className="text-xs text-muted-foreground text-center">
                         Selfie obrigatória para iniciar a operação
                       </p>
                     </div>
                   )}

                  {currentStep === 'travel_guide_active' && (
                    <div className="text-center space-y-4">
                      <div className="p-4 sm:p-6 bg-gradient-to-r from-green-500/20 to-blue-500/20 rounded-lg border-2 border-green-500/30">
                        <div className="flex items-center justify-center mb-4">
                          <div className="w-12 h-12 sm:w-16 sm:h-16 bg-gradient-to-r from-green-500 to-blue-500 rounded-full flex items-center justify-center">
                            <Clock className="w-6 h-6 sm:w-8 sm:h-8 text-white" />
                          </div>
                        </div>
                        <div className="space-y-2">
                          <p className="text-base sm:text-lg font-bold text-green-600">
                            OPERAÇÃO EM ANDAMENTO
                          </p>
                          <p className="text-xs sm:text-sm text-muted-foreground">
                            {state.operators.find(o => o.id === selectedOperator)?.name} está operando o veículo {state.vehicles.find(v => v.id === selectedVehicle)?.plate}
                          </p>
                          <p className="text-xs text-muted-foreground">
                            Iniciado às {startTime?.toLocaleTimeString()}
                          </p>
                        </div>
                      </div>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <Button
                          onClick={() => {
                            setCurrentStep('travel_guide_km_end');
                            addMessage('bot', 'Informe a quilometragem final do veículo:');
                          }}
                          size="lg"
                          className="bg-gradient-primary hover:opacity-90 h-12 sm:h-auto"
                        >
                          ✅ Finalizar Operação
                        </Button>
                         <Button
                           onClick={handleShowCancelDialog}
                           size="lg"
                           variant="outline"
                           className="h-12 sm:h-auto"
                         >
                           ❌ Cancelar e Voltar ao Início
                         </Button>
                      </div>
                    </div>
                  )}

                   {currentStep === 'travel_guide_km_end' && (
                     <div className="space-y-4">
                       <div className="flex flex-col sm:flex-row items-center gap-2">
                         <Input
                           type="number"
                           placeholder="Ex: 12850"
                           value={kmEnd}
                           onChange={(e) => setKmEnd(e.target.value)}
                           className="flex-1 h-12 sm:h-auto text-base sm:text-sm"
                           inputMode="numeric"
                           autoComplete="off"
                         />
                         <Button 
                           onClick={() => handleKmEnd(kmEnd)}
                           disabled={!kmEnd}
                           className="bg-gradient-primary hover:opacity-90 w-full sm:w-auto h-12 sm:h-auto"
                         >
                           Confirmar
                         </Button>
                       </div>
                       <Button
                         onClick={() => {
                           setCurrentStep('travel_guide_active');
                           addMessage('bot', 'Voltando para operação ativa...');
                         }}
                         variant="outline"
                         size="sm"
                         className="w-full flex items-center gap-2 h-12 sm:h-auto"
                       >
                         <ArrowLeft className="w-4 h-4" />
                         Voltar
                       </Button>
                       <p className="text-xs text-muted-foreground text-center">
                         Informe a quilometragem final do veículo
                       </p>
                     </div>
                    )}

                    {currentStep === 'travel_guide_end_front_photo' && (
                      <div className="space-y-4">
                        <div className="text-center">
                          <Button
                            onClick={handleFrontPhotoEnd}
                            size="lg"
                            className="bg-gradient-primary hover:opacity-90 flex items-center gap-2 w-full sm:w-auto h-12 sm:h-auto"
                          >
                            <Camera className="w-5 h-5" />
                            Tirar Foto da Frente
                          </Button>
                        </div>
                        <p className="text-xs text-muted-foreground text-center">
                          Foto da frente do veículo para finalizar
                        </p>
                      </div>
                    )}

                    {currentStep === 'travel_guide_end_rear_photo' && (
                      <div className="space-y-4">
                        <div className="text-center">
                          <Button
                            onClick={handleRearPhotoEnd}
                            size="lg"
                            className="bg-gradient-primary hover:opacity-90 flex items-center gap-2 w-full sm:w-auto h-12 sm:h-auto"
                          >
                            <Camera className="w-5 h-5" />
                            Tirar Foto da Traseira
                          </Button>
                        </div>
                        <p className="text-xs text-muted-foreground text-center">
                          Foto da traseira do veículo para finalizar
                        </p>
                      </div>
                    )}

                    {currentStep === 'travel_guide_end_selfie' && (
                     <div className="space-y-4">
                       <div className="text-center">
                         <Button
                           onClick={handleEndSelfie}
                           size="lg"
                           className="bg-gradient-primary hover:opacity-90 flex items-center gap-2 w-full sm:w-auto h-12 sm:h-auto"
                         >
                           <Camera className="w-5 h-5" />
                           Tirar Selfie de Encerramento
                         </Button>
                       </div>
                       <Button
                         onClick={() => {
                           setCurrentStep('travel_guide_km_end');
                           addMessage('bot', 'Voltando para informar quilometragem...');
                         }}
                         variant="outline"
                         size="sm"
                         className="w-full flex items-center gap-2 h-12 sm:h-auto"
                       >
                         <ArrowLeft className="w-4 h-4" />
                         Voltar e Corrigir KM
                       </Button>
                       <p className="text-xs text-muted-foreground text-center">
                         Selfie obrigatória para finalizar a operação
                       </p>
                     </div>
                   )}

                  {currentStep === 'finished' && (
                    <div className="text-center space-y-4">
                      <div className="p-4 sm:p-6 bg-success/10 rounded-lg">
                        <Check className="w-12 h-12 text-success mx-auto mb-3" />
                        <p className="text-success font-medium text-base sm:text-lg">
                          {currentTravelGuide ? 'Operação finalizada com sucesso!' : 'Check-list finalizado com sucesso!'}
                        </p>
                        <p className="text-xs sm:text-sm text-muted-foreground mt-2">
                          {currentTravelGuide ? 'Guia de marcha enviada para análise' : 'Relatório enviado para análise da administração'}
                        </p>
                      </div>
                      <Button
                        onClick={() => window.location.reload()}
                        size="lg"
                        className="bg-gradient-primary hover:opacity-90 w-full sm:w-auto h-12 sm:h-auto"
                      >
                        Nova Operação
                      </Button>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
      
      {/* AI Config Dialog removed */}
      
      {/* Cancel Operation Dialog */}
      <CancelOperationDialog
        isOpen={showCancelDialog}
        onConfirm={handleCancelOperation}
        onCancel={() => setShowCancelDialog(false)}
        operatorName={selectedOperator ? state.operators.find(o => o.id === selectedOperator)?.name : undefined}
        vehiclePlate={selectedVehicle ? state.vehicles.find(v => v.id === selectedVehicle)?.plate : undefined}
      />
    </div>
  );
};

export default OperatorChat;
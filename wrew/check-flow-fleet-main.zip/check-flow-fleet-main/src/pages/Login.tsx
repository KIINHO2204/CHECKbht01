import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useApp } from '@/contexts/AppContext';
import { Truck, UserCheck, Shield } from 'lucide-react';
import heroTruck from '@/assets/hero-truck.jpg';

const Login = () => {
  const { dispatch } = useApp();
  const [adminCredentials, setAdminCredentials] = useState({ email: '', password: '' });

  const handleAdminLogin = (e: React.FormEvent) => {
    e.preventDefault();
    // Acesso livre para administrador
    dispatch({ type: 'SET_USER', payload: { id: 'admin', type: 'admin' } });
  };

  const handleOperatorLogin = (e: React.FormEvent) => {
    e.preventDefault();
    // Direct operator access
    dispatch({ type: 'SET_USER', payload: { id: 'operator', type: 'operator' } });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/20 via-background to-info/20">
      {/* Hero Section */}
      <div className="relative h-64 mb-8 overflow-hidden">
        <img 
          src={heroTruck} 
          alt="Hero truck" 
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-primary/80 to-primary/40" />
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="text-center text-white">
            <div className="flex items-center justify-center mb-4">
              <div className="p-3 bg-white/20 rounded-full backdrop-blur-sm">
                <Truck className="w-8 h-8 text-white" />
              </div>
            </div>
            <h1 className="text-4xl font-bold mb-2">CheckList Veicular</h1>
            <p className="text-xl opacity-90">Sistema Profissional de Inspeção de Frotas</p>
          </div>
        </div>
      </div>

      <div className="flex items-center justify-center p-4">
        <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <h2 className="text-2xl font-bold text-foreground mb-2">
            Acesse sua conta
          </h2>
          <p className="text-muted-foreground">
            Selecione seu tipo de usuário para continuar
          </p>
        </div>

        <Tabs defaultValue="admin" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="admin" className="flex items-center gap-2">
              <Shield className="w-4 h-4" />
              Administrador
            </TabsTrigger>
            <TabsTrigger value="operator" className="flex items-center gap-2">
              <UserCheck className="w-4 h-4" />
              Operador
            </TabsTrigger>
          </TabsList>

          <TabsContent value="admin">
            <Card className="shadow-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Shield className="w-5 h-5 text-primary" />
                  Acesso Administrativo
                </CardTitle>
                <CardDescription>
                  Entre com suas credenciais de administrador
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <form onSubmit={handleAdminLogin} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      placeholder="admin@empresa.com"
                      value={adminCredentials.email}
                      onChange={(e) => setAdminCredentials(prev => ({ ...prev, email: e.target.value }))}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="password">Senha</Label>
                    <Input
                      id="password"
                      type="password"
                      placeholder="••••••••"
                      value={adminCredentials.password}
                      onChange={(e) => setAdminCredentials(prev => ({ ...prev, password: e.target.value }))}
                      required
                    />
                  </div>
                  <Button type="submit" className="w-full bg-gradient-primary hover:opacity-90">
                    Entrar como Administrador
                  </Button>
                </form>
                <div className="text-sm text-muted-foreground text-center">
                  <p>Credenciais de demonstração:</p>
                  <p><strong>Email:</strong> admin@empresa.com</p>
                  <p><strong>Senha:</strong> admin123</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="operator">
            <Card className="shadow-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <UserCheck className="w-5 h-5 text-primary" />
                  Acesso do Operador
                </CardTitle>
                <CardDescription>
                  Clique para acessar o sistema
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <form onSubmit={handleOperatorLogin} className="space-y-4">
                  <Button type="submit" className="w-full bg-gradient-primary hover:opacity-90">
                    Entrar
                  </Button>
                </form>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
        </div>
      </div>
    </div>
  );
};

export default Login;
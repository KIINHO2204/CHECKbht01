import { useApp } from '@/contexts/AppContext';
import Login from './Login';
import Dashboard from './Dashboard';

const Index = () => {
  const { state } = useApp();

  if (!state.user) {
    return <Login />;
  }

  return <Dashboard />;
};

export default Index;

import { memo, useState, useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { useApp } from '@/contexts/AppContext';
import { exportData } from '@/utils/exportData';
import AdminLayout from '@/components/AdminLayout';
import { TravelGuide } from '@/contexts/AppContext';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { 
  Calendar as CalendarIcon,
  Download,
  MapPin,
  User,
  Truck,
  Clock,
  Activity,
  FileText,
  Search,
  Route,
  Timer,
  CheckCircle,
  XCircle,
  AlertCircle,
  Camera
} from 'lucide-react';
import { cn } from '@/lib/utils';

const TravelGuideManagement = memo(() => {
  const { state } = useApp();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedOperator, setSelectedOperator] = useState<string>('all');
  const [selectedVehicle, setSelectedVehicle] = useState<string>('all');
  const [selectedStatus, setSelectedStatus] = useState<string>('all');
  const [dateRange, setDateRange] = useState<{ from?: Date; to?: Date }>({});

  const filteredGuides = useMemo(() => {
    let filtered = state.travelGuides;

    // Filtro por termo de busca
    if (searchTerm) {
      filtered = filtered.filter(guide => {
        const operator = state.operators.find(o => o.id === guide.operatorId);
        const vehicle = state.vehicles.find(v => v.id === guide.vehicleId);
        return (
          operator?.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
          vehicle?.plate.toLowerCase().includes(searchTerm.toLowerCase()) ||
          guide.id.toLowerCase().includes(searchTerm.toLowerCase())
        );
      });
    }

    // Filtro por operador
    if (selectedOperator !== 'all') {
      filtered = filtered.filter(guide => guide.operatorId === selectedOperator);
    }

    // Filtro por veículo
    if (selectedVehicle !== 'all') {
      filtered = filtered.filter(guide => guide.vehicleId === selectedVehicle);
    }

    // Filtro por status
    if (selectedStatus !== 'all') {
      filtered = filtered.filter(guide => guide.status === selectedStatus);
    }

    // Filtro por data
    if (dateRange.from) {
      filtered = filtered.filter(guide => {
        const guideDate = new Date(guide.createdAt);
        const fromDate = new Date(dateRange.from!);
        const toDate = dateRange.to ? new Date(dateRange.to) : new Date();
        return guideDate >= fromDate && guideDate <= toDate;
      });
    }

    return filtered.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }, [state.travelGuides, state.operators, state.vehicles, searchTerm, selectedOperator, selectedVehicle, selectedStatus, dateRange]);

  const handleExport = () => {
    const dataForExport = filteredGuides.map(guide => {
      const operator = state.operators.find(o => o.id === guide.operatorId);
      const vehicle = state.vehicles.find(v => v.id === guide.vehicleId);
      
      return {
        'ID': guide.id,
        'Operador': operator?.name || 'N/A',
        'Veículo': vehicle?.plate || 'N/A',
        'KM Inicial': guide.kmStart,
        'KM Final': guide.kmEnd || 'N/A',
        'Distância': guide.kmEnd ? guide.kmEnd - guide.kmStart : 'N/A',
        'Data/Hora Início': new Date(guide.startTime).toLocaleString(),
        'Data/Hora Fim': guide.endTime ? new Date(guide.endTime).toLocaleString() : 'N/A',
        'Status': guide.status === 'active' ? 'Ativo' : 
                  guide.status === 'completed' ? 'Concluído' : 
                  guide.status === 'cancelled' ? 'Cancelado' : 'Finalizado via Esqueci',
        'Tempo Total': guide.endTime ? 
          formatDuration(new Date(guide.endTime).getTime() - new Date(guide.startTime).getTime()) : 
          'N/A',
        'Criado em': new Date(guide.createdAt).toLocaleString(),
      };
    });

    exportData(dataForExport, 'guias-de-marcha');
  };

  const formatDuration = (ms: number) => {
    const hours = Math.floor(ms / (1000 * 60 * 60));
    const minutes = Math.floor((ms % (1000 * 60 * 60)) / (1000 * 60));
    return `${hours}h ${minutes}m`;
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'active':
        return <Activity className="w-4 h-4" />;
      case 'completed':
        return <CheckCircle className="w-4 h-4" />;
      case 'cancelled':
        return <XCircle className="w-4 h-4" />;
      case 'forgotten_end':
        return <AlertCircle className="w-4 h-4" />;
      default:
        return <Clock className="w-4 h-4" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active':
        return 'bg-info text-info-foreground';
      case 'completed':
        return 'bg-success text-success-foreground';
      case 'cancelled':
        return 'bg-destructive text-destructive-foreground';
      case 'forgotten_end':
        return 'bg-warning text-warning-foreground';
      default:
        return 'bg-muted text-muted-foreground';
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'active':
        return 'Ativo';
      case 'completed':
        return 'Concluído';
      case 'cancelled':
        return 'Cancelado';
      case 'forgotten_end':
        return 'Finalizado via Esqueci';
      default:
        return 'Desconhecido';
    }
  };

  // Estatísticas
  const totalGuides = filteredGuides.length;
  const activeGuides = filteredGuides.filter(g => g.status === 'active').length;
  const completedGuides = filteredGuides.filter(g => g.status === 'completed').length;
  const totalDistance = filteredGuides.reduce((acc, guide) => {
    if (guide.kmEnd) {
      return acc + (guide.kmEnd - guide.kmStart);
    }
    return acc;
  }, 0);

  return (
    <AdminLayout currentPage="travel-guides">
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Guia de Marcha</h1>
            <p className="text-muted-foreground">
              Controle de operações diárias dos veículos
            </p>
          </div>
          <Button onClick={handleExport} className="flex items-center gap-2">
            <Download className="w-4 h-4" />
            Exportar Excel
          </Button>
        </div>

        {/* Estatísticas */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card className="shadow-card bg-gradient-card">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total de Guias</CardTitle>
              <FileText className="h-4 w-4 text-primary" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-primary">{totalGuides}</div>
              <p className="text-xs text-muted-foreground">Registros encontrados</p>
            </CardContent>
          </Card>
          
          <Card className="shadow-card bg-gradient-card">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Operações Ativas</CardTitle>
              <Activity className="h-4 w-4 text-info" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-info">{activeGuides}</div>
              <p className="text-xs text-muted-foreground">Em andamento</p>
            </CardContent>
          </Card>
          
          <Card className="shadow-card bg-gradient-card">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Concluídas</CardTitle>
              <CheckCircle className="h-4 w-4 text-success" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-success">{completedGuides}</div>
              <p className="text-xs text-muted-foreground">Finalizadas</p>
            </CardContent>
          </Card>
          
          <Card className="shadow-card bg-gradient-card">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Distância Total</CardTitle>
              <Route className="h-4 w-4 text-warning" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-warning">{totalDistance} km</div>
              <p className="text-xs text-muted-foreground">Quilometragem percorrida</p>
            </CardContent>
          </Card>
        </div>

        {/* Filtros */}
        <Card className="shadow-card bg-gradient-card">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Search className="w-5 h-5" />
              Filtros
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
              <div className="space-y-2">
                <Label htmlFor="search">Buscar</Label>
                <Input
                  id="search"
                  placeholder="Operador, veículo ou ID..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="operator">Operador</Label>
                <Select value={selectedOperator} onValueChange={setSelectedOperator}>
                  <SelectTrigger id="operator">
                    <SelectValue placeholder="Todos" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos</SelectItem>
                    {state.operators.map(operator => (
                      <SelectItem key={operator.id} value={operator.id}>
                        {operator.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="vehicle">Veículo</Label>
                <Select value={selectedVehicle} onValueChange={setSelectedVehicle}>
                  <SelectTrigger id="vehicle">
                    <SelectValue placeholder="Todos" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos</SelectItem>
                    {state.vehicles.map(vehicle => (
                      <SelectItem key={vehicle.id} value={vehicle.id}>
                        {vehicle.plate}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="status">Status</Label>
                <Select value={selectedStatus} onValueChange={setSelectedStatus}>
                  <SelectTrigger id="status">
                    <SelectValue placeholder="Todos" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos</SelectItem>
                    <SelectItem value="active">Ativo</SelectItem>
                    <SelectItem value="completed">Concluído</SelectItem>
                    <SelectItem value="cancelled">Cancelado</SelectItem>
                    <SelectItem value="forgotten_end">Finalizado via Esqueci</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label>Data Inicial</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className={cn(
                        "w-full justify-start text-left font-normal",
                        !dateRange.from && "text-muted-foreground"
                      )}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {dateRange.from ? format(dateRange.from, "PPP", { locale: ptBR }) : "Selecionar"}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={dateRange.from}
                      onSelect={(date) => setDateRange({ ...dateRange, from: date })}
                      initialFocus
                      className="pointer-events-auto"
                    />
                  </PopoverContent>
                </Popover>
              </div>
              
              <div className="space-y-2">
                <Label>Data Final</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className={cn(
                        "w-full justify-start text-left font-normal",
                        !dateRange.to && "text-muted-foreground"
                      )}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {dateRange.to ? format(dateRange.to, "PPP", { locale: ptBR }) : "Selecionar"}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={dateRange.to}
                      onSelect={(date) => setDateRange({ ...dateRange, to: date })}
                      initialFocus
                      className="pointer-events-auto"
                    />
                  </PopoverContent>
                </Popover>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Lista de Guias */}
        <Card className="shadow-card bg-gradient-card">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <MapPin className="w-5 h-5" />
              Registros de Operação
            </CardTitle>
          </CardHeader>
          <CardContent>
            {filteredGuides.length === 0 ? (
              <div className="text-center py-12">
                <FileText className="w-12 h-12 text-muted-foreground mx-auto mb-4 opacity-50" />
                <p className="text-muted-foreground">Nenhuma guia de marcha encontrada</p>
                <p className="text-sm text-muted-foreground">
                  Ajuste os filtros ou verifique se há operações registradas
                </p>
              </div>
            ) : (
              <div className="space-y-4">
                {filteredGuides.map((guide) => {
                  const operator = state.operators.find(o => o.id === guide.operatorId);
                  const vehicle = state.vehicles.find(v => v.id === guide.vehicleId);
                  
                  return (
                    <div key={guide.id} className="p-4 border rounded-lg bg-background hover:shadow-sm transition-shadow">
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex items-center gap-3">
                          <Badge className={getStatusColor(guide.status)}>
                            {getStatusIcon(guide.status)}
                            <span className="ml-1">{getStatusLabel(guide.status)}</span>
                          </Badge>
                          <div className="text-sm text-muted-foreground">
                            ID: {guide.id}
                          </div>
                        </div>
                        <div className="text-sm text-muted-foreground">
                          {format(new Date(guide.createdAt), "PPP 'às' HH:mm", { locale: ptBR })}
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 text-sm">
                        <div className="flex items-center gap-2">
                          <User className="w-4 h-4 text-muted-foreground" />
                          <div>
                            <div className="font-medium">{operator?.name || 'N/A'}</div>
                            <div className="text-muted-foreground">Operador</div>
                          </div>
                        </div>
                        
                        <div className="flex items-center gap-2">
                          <Truck className="w-4 h-4 text-muted-foreground" />
                          <div>
                            <div className="font-medium">{vehicle?.plate || 'N/A'}</div>
                            <div className="text-muted-foreground">Veículo</div>
                          </div>
                        </div>
                        
                        <div className="flex items-center gap-2">
                          <MapPin className="w-4 h-4 text-muted-foreground" />
                          <div>
                            <div className="font-medium">
                              {guide.kmStart} km → {guide.kmEnd ? `${guide.kmEnd} km` : 'Em andamento'}
                            </div>
                            <div className="text-muted-foreground">
                              {guide.kmEnd ? `${guide.kmEnd - guide.kmStart} km percorridos` : 'Quilometragem'}
                            </div>
                          </div>
                        </div>
                        
                        <div className="flex items-center gap-2">
                          <Clock className="w-4 h-4 text-muted-foreground" />
                          <div>
                            <div className="font-medium">
                              {format(new Date(guide.startTime), "HH:mm")}
                              {guide.endTime && ` - ${format(new Date(guide.endTime), "HH:mm")}`}
                            </div>
                            <div className="text-muted-foreground">
                              {guide.endTime ? 
                                formatDuration(new Date(guide.endTime).getTime() - new Date(guide.startTime).getTime()) :
                                'Em andamento'
                              }
                            </div>
                          </div>
                        </div>
                      </div>
                      
                      {/* Fotos do Veículo - Apenas para operações concluídas */}
                      {guide.status !== 'active' && (guide.frontPhotoStart || guide.rearPhotoStart || guide.frontPhotoEnd || guide.rearPhotoEnd) && (
                        <div className="mt-4 pt-4 border-t">
                          <div className="flex items-center gap-2 mb-3">
                            <Camera className="w-4 h-4 text-muted-foreground" />
                            <span className="text-sm font-medium">Fotos do Veículo</span>
                          </div>
                          <div className="space-y-3">
                            {/* Fotos do início */}
                            {(guide.frontPhotoStart || guide.rearPhotoStart) && (
                              <div>
                                <div className="text-xs text-muted-foreground mb-2">Início da Operação:</div>
                                <div className="flex items-center gap-4">
                                  {guide.frontPhotoStart && (
                                    <div className="flex items-center gap-2">
                                      <div className="text-xs text-muted-foreground">Frente:</div>
                                      <div className="relative">
                                        <img 
                                          src={guide.frontPhotoStart} 
                                          alt="Foto frente - início" 
                                          className="w-16 h-16 object-cover rounded-lg border"
                                        />
                                        <div className="absolute bottom-0 left-0 bg-black/70 text-white px-1 py-0.5 rounded-br text-xs">
                                          {format(new Date(guide.startTime), "HH:mm", { locale: ptBR })}
                                        </div>
                                      </div>
                                    </div>
                                  )}
                                  {guide.rearPhotoStart && (
                                    <div className="flex items-center gap-2">
                                      <div className="text-xs text-muted-foreground">Traseira:</div>
                                      <div className="relative">
                                        <img 
                                          src={guide.rearPhotoStart} 
                                          alt="Foto traseira - início" 
                                          className="w-16 h-16 object-cover rounded-lg border"
                                        />
                                        <div className="absolute bottom-0 left-0 bg-black/70 text-white px-1 py-0.5 rounded-br text-xs">
                                          {format(new Date(guide.startTime), "HH:mm", { locale: ptBR })}
                                        </div>
                                      </div>
                                    </div>
                                  )}
                                </div>
                              </div>
                            )}
                            {/* Fotos do final */}
                            {(guide.frontPhotoEnd || guide.rearPhotoEnd) && (
                              <div>
                                <div className="text-xs text-muted-foreground mb-2">Final da Operação:</div>
                                <div className="flex items-center gap-4">
                                  {guide.frontPhotoEnd && (
                                    <div className="flex items-center gap-2">
                                      <div className="text-xs text-muted-foreground">Frente:</div>
                                      <div className="relative">
                                        <img 
                                          src={guide.frontPhotoEnd} 
                                          alt="Foto frente - final" 
                                          className="w-16 h-16 object-cover rounded-lg border"
                                        />
                                        <div className="absolute bottom-0 left-0 bg-black/70 text-white px-1 py-0.5 rounded-br text-xs">
                                          {guide.endTime && format(new Date(guide.endTime), "HH:mm", { locale: ptBR })}
                                        </div>
                                      </div>
                                    </div>
                                  )}
                                  {guide.rearPhotoEnd && (
                                    <div className="flex items-center gap-2">
                                      <div className="text-xs text-muted-foreground">Traseira:</div>
                                      <div className="relative">
                                        <img 
                                          src={guide.rearPhotoEnd} 
                                          alt="Foto traseira - final" 
                                          className="w-16 h-16 object-cover rounded-lg border"
                                        />
                                        <div className="absolute bottom-0 left-0 bg-black/70 text-white px-1 py-0.5 rounded-br text-xs">
                                          {guide.endTime && format(new Date(guide.endTime), "HH:mm", { locale: ptBR })}
                                        </div>
                                      </div>
                                    </div>
                                  )}
                                </div>
                              </div>
                            )}
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </AdminLayout>
  );
});

TravelGuideManagement.displayName = 'TravelGuideManagement';

export default TravelGuideManagement;
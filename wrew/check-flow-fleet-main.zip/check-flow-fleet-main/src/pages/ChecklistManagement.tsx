import { useState, useCallback, memo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger,
  DialogFooter,
  DialogDescription
} from '@/components/ui/dialog';
import { useApp } from '@/contexts/AppContext';
import AdminLayout from '@/components/AdminLayout';
import { 
  ClipboardList, 
  Plus, 
  Edit, 
  Trash2, 
  Camera,
  Calendar,
  Move,
  AlertCircle,
  CheckCircle,
  Search
} from 'lucide-react';
import { toast } from '@/hooks/use-toast';

interface ChecklistItemForm {
  question: string;
  requiresPhoto: boolean;
  order: number;
}

const ChecklistCard = memo(({ checklist, onEdit, onDelete }: {
  checklist: any;
  onEdit: (checklist: any) => void;
  onDelete: (id: string) => void;
}) => (
  <Card className="shadow-card bg-gradient-card hover:shadow-elevated transition-all duration-200 hover:scale-105">
    <CardHeader className="pb-3">
      <div className="flex items-center justify-between">
        <Badge variant="outline" className="bg-primary/10 text-primary">
          {checklist.items.length} itens
        </Badge>
        <div className="flex items-center gap-2">
          <Button 
            variant="ghost" 
            size="sm"
            onClick={() => onEdit(checklist)}
            className="hover:bg-primary/10 hover:scale-110 transition-all"
            aria-label={`Editar checklist ${checklist.name}`}
          >
            <Edit className="w-4 h-4" />
          </Button>
          <Button 
            variant="ghost" 
            size="sm"
            onClick={() => onDelete(checklist.id)}
            className="hover:bg-destructive/10 hover:text-destructive hover:scale-110 transition-all"
            aria-label={`Excluir checklist ${checklist.name}`}
          >
            <Trash2 className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </CardHeader>
    <CardContent>
      <div className="space-y-4">
        <div>
          <h3 className="font-semibold text-lg text-foreground mb-2">{checklist.name}</h3>
          <div className="space-y-2">
            {checklist.items.slice(0, 3).map((item: any, index: number) => (
              <div key={item.id} className="flex items-center gap-2 text-sm">
                <span className="w-6 h-6 bg-primary/10 text-primary rounded-full flex items-center justify-center text-xs font-medium">
                  {index + 1}
                </span>
                <span className="flex-1 text-muted-foreground">{item.question}</span>
                {item.requiresPhoto && <Camera className="w-4 h-4 text-primary" />}
              </div>
            ))}
            {checklist.items.length > 3 && (
              <div className="text-sm text-muted-foreground text-center py-2">
                +{checklist.items.length - 3} itens adicionais
              </div>
            )}
          </div>
        </div>
        
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <Calendar className="w-4 h-4" />
          <span>Criado em {new Date(checklist.createdAt).toLocaleDateString()}</span>
        </div>
      </div>
    </CardContent>
  </Card>
));

ChecklistCard.displayName = 'ChecklistCard';

const ChecklistManagement = memo(() => {
  const { state, dispatch } = useApp();
  const [editingChecklist, setEditingChecklist] = useState<any>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [formData, setFormData] = useState({
    name: '',
    items: [] as ChecklistItemForm[]
  });
  const [currentItem, setCurrentItem] = useState<ChecklistItemForm>({
    question: '',
    requiresPhoto: false,
    order: 1
  });
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = useCallback(async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name.trim()) {
      toast({
        title: "Erro",
        description: "Nome do checklist é obrigatório",
        variant: "destructive"
      });
      return;
    }

    if (formData.items.length === 0) {
      toast({
        title: "Erro", 
        description: "Adicione pelo menos um item ao checklist",
        variant: "destructive"
      });
      return;
    }
    
    setIsLoading(true);
    
    try {
      const checklistData = {
        ...formData,
        items: formData.items.map((item, index) => ({
          ...item,
          id: Date.now().toString() + index,
          order: index + 1
        }))
      };
      
      if (editingChecklist) {
        dispatch({
          type: 'UPDATE_CHECKLIST',
          payload: { ...editingChecklist, ...checklistData }
        });
        toast({
          title: "Checklist atualizado",
          description: "O checklist foi atualizado com sucesso.",
        });
      } else {
        dispatch({
          type: 'ADD_CHECKLIST',
          payload: {
            id: Date.now().toString(),
            ...checklistData,
            createdAt: new Date().toISOString()
          }
        });
        toast({
          title: "Checklist criado",
          description: "O checklist foi criado com sucesso.",
        });
      }
      
      resetForm();
      setIsDialogOpen(false);
    } catch (error) {
      toast({
        title: "Erro",
        description: "Ocorreu um erro ao salvar o checklist. Tente novamente.",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  }, [formData, editingChecklist, dispatch]);

  const handleEdit = useCallback((checklist: any) => {
    setEditingChecklist(checklist);
    setFormData({
      name: checklist.name,
      items: checklist.items.map((item: any) => ({
        question: item.question,
        requiresPhoto: item.requiresPhoto,
        order: item.order
      }))
    });
    setIsDialogOpen(true);
  }, []);

  const handleDelete = useCallback((checklistId: string) => {
    const checklist = state.checklists.find(c => c.id === checklistId);
    if (window.confirm(`Tem certeza que deseja excluir o checklist "${checklist?.name}"?`)) {
      dispatch({ type: 'DELETE_CHECKLIST', payload: checklistId });
      toast({
        title: "Checklist removido",
        description: "O checklist foi removido com sucesso.",
      });
    }
  }, [state.checklists, dispatch]);

  const resetForm = useCallback(() => {
    setEditingChecklist(null);
    setFormData({ name: '', items: [] });
    setCurrentItem({ question: '', requiresPhoto: false, order: 1 });
  }, []);

  const addItem = useCallback(() => {
    if (!currentItem.question.trim()) {
      toast({
        title: "Erro",
        description: "Pergunta é obrigatória",
        variant: "destructive"
      });
      return;
    }

    setFormData(prev => ({
      ...prev,
      items: [...prev.items, { ...currentItem, order: prev.items.length + 1 }]
    }));
    setCurrentItem({ question: '', requiresPhoto: false, order: 1 });
    toast({
      title: "Item adicionado",
      description: "Item adicionado ao checklist",
    });
  }, [currentItem]);

  const removeItem = useCallback((index: number) => {
    setFormData(prev => ({
      ...prev,
      items: prev.items.filter((_, i) => i !== index)
    }));
  }, []);

  const moveItem = useCallback((index: number, direction: 'up' | 'down') => {
    const newItems = [...formData.items];
    const targetIndex = direction === 'up' ? index - 1 : index + 1;
    
    if (targetIndex >= 0 && targetIndex < newItems.length) {
      [newItems[index], newItems[targetIndex]] = [newItems[targetIndex], newItems[index]];
      setFormData(prev => ({ ...prev, items: newItems }));
    }
  }, [formData.items]);

  const filteredChecklists = state.checklists.filter(checklist =>
    checklist.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <AdminLayout currentPage="checklists">
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-gradient-primary rounded-lg">
              <ClipboardList className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2 className="text-2xl font-bold text-foreground">Gestão de Check-lists</h2>
              <p className="text-sm text-muted-foreground">
                Crie e gerencie os check-lists de inspeção ({state.checklists.length} check-lists)
              </p>
            </div>
          </div>
          
          <Dialog 
            open={isDialogOpen} 
            onOpenChange={(open) => {
              setIsDialogOpen(open);
              if (!open) resetForm();
            }}
          >
            <DialogTrigger asChild>
              <Button className="bg-gradient-primary hover:opacity-90 flex items-center gap-2">
                <Plus className="w-4 h-4" />
                Novo Check-list
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[600px] max-h-[80vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2">
                  <ClipboardList className="w-5 h-5 text-primary" />
                  {editingChecklist ? 'Editar Check-list' : 'Novo Check-list'}
                </DialogTitle>
                <DialogDescription>
                  {editingChecklist ? 'Atualize o check-list selecionado e seus itens.' : 'Crie um novo check-list com os itens de inspeção necessários.'}
                </DialogDescription>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="name">Nome do Check-list *</Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                    placeholder="Ex: Inspeção Diária Veicular"
                    disabled={isLoading}
                  />
                </div>

                {/* Adicionar Item */}
                <div className="border rounded-lg p-4 space-y-4">
                  <h4 className="font-medium">Adicionar Item</h4>
                  <div className="space-y-3">
                    <div>
                      <Label htmlFor="question">Pergunta *</Label>
                      <Input
                        id="question"
                        value={currentItem.question}
                        onChange={(e) => setCurrentItem(prev => ({ ...prev, question: e.target.value }))}
                        placeholder="Ex: Verificar nível de óleo do motor"
                      />
                    </div>
                    <div className="flex items-center space-x-2">
                      <Switch
                        id="photo"
                        checked={currentItem.requiresPhoto}
                        onCheckedChange={(checked) => setCurrentItem(prev => ({ ...prev, requiresPhoto: checked }))}
                      />
                      <Label htmlFor="photo" className="flex items-center gap-2">
                        <Camera className="w-4 h-4" />
                        Foto obrigatória
                      </Label>
                    </div>
                    <Button
                      type="button"
                      onClick={addItem}
                      variant="outline"
                      className="w-full"
                    >
                      <Plus className="w-4 h-4 mr-2" />
                      Adicionar Item
                    </Button>
                  </div>
                </div>

                {/* Lista de Itens */}
                {formData.items.length > 0 && (
                  <div className="space-y-2">
                    <h4 className="font-medium">Itens do Check-list ({formData.items.length})</h4>
                    <div className="space-y-2 max-h-60 overflow-y-auto">
                      {formData.items.map((item, index) => (
                        <div key={index} className="flex items-center gap-2 p-3 border rounded-lg bg-muted/50">
                          <span className="w-8 h-8 bg-primary text-primary-foreground rounded-full flex items-center justify-center text-sm font-medium">
                            {index + 1}
                          </span>
                          <div className="flex-1">
                            <p className="text-sm font-medium">{item.question}</p>
                            {item.requiresPhoto && (
                              <div className="flex items-center gap-1 text-xs text-muted-foreground">
                                <Camera className="w-3 h-3" />
                                Foto obrigatória
                              </div>
                            )}
                          </div>
                          <div className="flex items-center gap-1">
                            <Button
                              type="button"
                              variant="ghost"
                              size="sm"
                              onClick={() => moveItem(index, 'up')}
                              disabled={index === 0}
                            >
                              <Move className="w-4 h-4 rotate-180" />
                            </Button>
                            <Button
                              type="button"
                              variant="ghost"
                              size="sm"
                              onClick={() => moveItem(index, 'down')}
                              disabled={index === formData.items.length - 1}
                            >
                              <Move className="w-4 h-4" />
                            </Button>
                            <Button
                              type="button"
                              variant="ghost"
                              size="sm"
                              onClick={() => removeItem(index)}
                              className="text-destructive hover:text-destructive"
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
                
                <DialogFooter>
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={() => setIsDialogOpen(false)}
                    disabled={isLoading}
                  >
                    Cancelar
                  </Button>
                  <Button 
                    type="submit" 
                    className="bg-gradient-primary hover:opacity-90"
                    disabled={isLoading}
                  >
                    {isLoading ? 'Salvando...' : (editingChecklist ? 'Atualizar' : 'Criar')}
                  </Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        {/* Search */}
        <Card className="shadow-card bg-gradient-card">
          <CardContent className="p-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
              <Input
                placeholder="Buscar check-lists..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
          </CardContent>
        </Card>

        {/* Checklists Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredChecklists.map((checklist) => (
            <ChecklistCard
              key={checklist.id}
              checklist={checklist}
              onEdit={handleEdit}
              onDelete={handleDelete}
            />
          ))}
        </div>

        {filteredChecklists.length === 0 && (
          <Card className="shadow-card bg-gradient-card">
            <CardContent className="py-12 text-center">
              {searchTerm ? (
                <>
                  <Search className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-foreground mb-2">
                    Nenhum check-list encontrado
                  </h3>
                  <p className="text-muted-foreground mb-4">
                    Tente ajustar o termo de busca
                  </p>
                  <Button 
                    variant="outline"
                    onClick={() => setSearchTerm('')}
                  >
                    Limpar busca
                  </Button>
                </>
              ) : (
                <>
                  <ClipboardList className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-foreground mb-2">
                    Nenhum check-list cadastrado
                  </h3>
                  <p className="text-muted-foreground mb-4">
                    Comece criando seu primeiro check-list de inspeção
                  </p>
                  <Button 
                    onClick={() => setIsDialogOpen(true)}
                    className="bg-gradient-primary hover:opacity-90"
                  >
                    Criar Primeiro Check-list
                  </Button>
                </>
              )}
            </CardContent>
          </Card>
        )}
      </div>
    </AdminLayout>
  );
});

ChecklistManagement.displayName = 'ChecklistManagement';

export default ChecklistManagement;
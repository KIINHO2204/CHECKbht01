import { useState, useMemo, memo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogDescription } from '@/components/ui/dialog';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { useApp } from '@/contexts/AppContext';
import AdminLayout from '@/components/AdminLayout';
import { exportToCSV, exportChecklistResultToPDF } from '@/utils/exportData';
import { 
  FileText, 
  Download, 
  Calendar as CalendarIcon,
  Filter,
  Search,
  Truck,
  User,
  ClipboardCheck,
  AlertTriangle,
  CheckCircle,
  TrendingUp,
  Eye,
  FileDown,
  X,
  ZoomIn,
  BrainCircuit,
  SparklesIcon
} from 'lucide-react';
import { toast } from '@/hooks/use-toast';
import { format } from 'date-fns';

const StatCard = memo(({ title, value, description, icon: Icon, color }: {
  title: string;
  value: string | number;
  description: string;
  icon: any;
  color: string;
}) => (
  <Card className="shadow-card bg-gradient-card">
    <CardContent className="p-6">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm font-medium text-muted-foreground">{title}</p>
          <p className={`text-2xl font-bold ${color}`}>{value}</p>
          <p className="text-xs text-muted-foreground">{description}</p>
        </div>
        <Icon className={`h-8 w-8 ${color}`} />
      </div>
    </CardContent>
  </Card>
));

StatCard.displayName = 'StatCard';

const Reports = () => {
  const { state } = useApp();
  const [searchTerm, setSearchTerm] = useState('');
  const [filterVehicle, setFilterVehicle] = useState('all');
  const [filterOperator, setFilterOperator] = useState('all');
  const [dateFrom, setDateFrom] = useState<Date>();
  const [dateTo, setDateTo] = useState<Date>();
  const [selectedReport, setSelectedReport] = useState<any>(null);
  const [enlargedImage, setEnlargedImage] = useState<string | null>(null);

  // Dados estatísticos
  const stats = useMemo(() => {
    const totalInspections = state.checklistResults.length;
    const totalOccurrences = state.occurrences.length;
    const pendingOccurrences = state.occurrences.filter(o => o.status === 'pending').length;
    const resolvedOccurrences = state.occurrences.filter(o => o.status === 'resolved').length;
    const averageInspections = state.operators.length > 0 
      ? Math.round(totalInspections / state.operators.length) 
      : 0;

    return {
      totalInspections,
      totalOccurrences,
      pendingOccurrences,
      resolvedOccurrences,
      averageInspections
    };
  }, [state]);

  // Filtrar resultados
  const filteredResults = useMemo(() => {
    return state.checklistResults.filter(result => {
      const vehicle = state.vehicles.find(v => v.id === result.vehicleId);
      const operator = state.operators.find(o => o.id === result.operatorId);
      const resultDate = new Date(result.createdAt);

      const matchesSearch = !searchTerm || 
        vehicle?.plate.toLowerCase().includes(searchTerm.toLowerCase()) ||
        operator?.name.toLowerCase().includes(searchTerm.toLowerCase());
      
      const matchesVehicle = filterVehicle === 'all' || result.vehicleId === filterVehicle;
      const matchesOperator = filterOperator === 'all' || result.operatorId === filterOperator;
      
      const matchesDateFrom = !dateFrom || resultDate >= dateFrom;
      const matchesDateTo = !dateTo || resultDate <= dateTo;

      return matchesSearch && matchesVehicle && matchesOperator && matchesDateFrom && matchesDateTo;
    });
  }, [state, searchTerm, filterVehicle, filterOperator, dateFrom, dateTo]);

  const handleExportCSV = () => {
    const exportData = filteredResults.map(result => {
      const vehicle = state.vehicles.find(v => v.id === result.vehicleId);
      const operator = state.operators.find(o => o.id === result.operatorId);
      const checklist = state.checklists.find(c => c.id === result.checklistId);
      
      return {
        data: new Date(result.createdAt).toLocaleDateString(),
        hora: new Date(result.createdAt).toLocaleTimeString(),
        placa: vehicle?.plate || 'N/A',
        modelo: vehicle?.model || 'N/A',
        operador: operator?.name || 'N/A',
        checklist: checklist?.name || 'N/A',
        respostas_conforme: result.responses.filter(r => r.answer === 'CONFORME').length,
        respostas_nao_conforme: result.responses.filter(r => r.answer === 'NÃO CONFORME').length,
        total_itens: result.responses.length
      };
    });

    exportToCSV(exportData, 'relatorio-inspections');
    toast({
      title: "Exportação realizada",
      description: "Relatório exportado com sucesso em CSV.",
    });
  };

  const [isExportingPDF, setIsExportingPDF] = useState(false);
  const [includeAIAnalysis, setIncludeAIAnalysis] = useState(true);

  const handleExportPDF = async (result: any) => {
    const vehicle = state.vehicles.find(v => v.id === result.vehicleId);
    const operator = state.operators.find(o => o.id === result.operatorId);
    const checklist = state.checklists.find(c => c.id === result.checklistId);

    if (vehicle && operator && checklist) {
      setIsExportingPDF(true);
      
      try {
        toast({
          title: includeAIAnalysis ? "Gerando relatório inteligente..." : "Gerando PDF...",
          description: includeAIAnalysis ? "Aguarde enquanto a IA analisa os dados da inspeção." : "Aguarde enquanto o PDF é gerado.",
        });
        
        await exportChecklistResultToPDF(
          result, 
          vehicle, 
          operator, 
          checklist, 
          state.headerSettings,
          includeAIAnalysis
        );
        
        toast({
          title: "PDF gerado com sucesso",
          description: includeAIAnalysis 
            ? "Relatório individual com análise inteligente exportado em PDF." 
            : "Relatório individual exportado em PDF.",
        });
      } catch (error) {
        console.error("Erro ao gerar PDF:", error);
        toast({
          title: "Erro ao gerar PDF",
          description: "Não foi possível gerar o relatório. Tente novamente.",
          variant: "destructive"
        });
      } finally {
        setIsExportingPDF(false);
      }
    }
  };

  const clearFilters = () => {
    setSearchTerm('');
    setFilterVehicle('all');
    setFilterOperator('all');
    setDateFrom(undefined);
    setDateTo(undefined);
  };

  const handleViewReport = (result: any) => {
    setSelectedReport(result);
  };

  return (
    <AdminLayout currentPage="reports">
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-gradient-primary rounded-lg">
              <FileText className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2 className="text-2xl font-bold text-foreground flex items-center gap-2">
                Relatórios
                <div className="flex items-center gap-1 bg-primary/10 px-2 py-1 rounded-full text-sm">
                  <BrainCircuit className="w-4 h-4 text-primary" />
                  <span className="text-primary text-xs font-normal">Análise Inteligente Ativa</span>
                </div>
              </h2>
              <p className="text-sm text-muted-foreground">
                Visualize e exporte dados das inspeções realizadas
              </p>
            </div>
          </div>
          
          <Button 
            onClick={handleExportCSV}
            className="bg-gradient-primary hover:opacity-90 flex items-center gap-2"
            disabled={filteredResults.length === 0}
          >
            <Download className="w-4 h-4" />
            Exportar CSV
          </Button>
        </div>

        {/* Estatísticas */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4">
          <StatCard
            title="Total de Inspeções"
            value={stats.totalInspections}
            description="Realizadas"
            icon={ClipboardCheck}
            color="text-primary"
          />
          <StatCard
            title="Total de Ocorrências"
            value={stats.totalOccurrences}
            description="Registradas"
            icon={AlertTriangle}
            color="text-warning"
          />
          <StatCard
            title="Ocorrências Pendentes"
            value={stats.pendingOccurrences}
            description="Aguardando resolução"
            icon={AlertTriangle}
            color="text-destructive"
          />
          <StatCard
            title="Ocorrências Resolvidas"
            value={stats.resolvedOccurrences}
            description="Finalizadas"
            icon={CheckCircle}
            color="text-success"
          />
          <StatCard
            title="Média por Operador"
            value={stats.averageInspections}
            description="Inspeções/operador"
            icon={TrendingUp}
            color="text-info"
          />
        </div>

        {/* Filtros */}
        <Card className="shadow-card bg-gradient-card">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Filter className="w-5 h-5" />
              Filtros
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
              <div className="space-y-2">
                <Label>Buscar</Label>
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
                  <Input
                    placeholder="Placa ou operador"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <Label>Veículo</Label>
                <select
                  value={filterVehicle}
                  onChange={(e) => setFilterVehicle(e.target.value)}
                  className="w-full p-2 border border-input rounded-md bg-background text-sm"
                >
                  <option value="all">Todos os veículos</option>
                  {state.vehicles.map(vehicle => (
                    <option key={vehicle.id} value={vehicle.id}>
                      {vehicle.plate} - {vehicle.model}
                    </option>
                  ))}
                </select>
              </div>
              
              <div className="space-y-2">
                <Label>Operador</Label>
                <select
                  value={filterOperator}
                  onChange={(e) => setFilterOperator(e.target.value)}
                  className="w-full p-2 border border-input rounded-md bg-background text-sm"
                >
                  <option value="all">Todos os operadores</option>
                  {state.operators.map(operator => (
                    <option key={operator.id} value={operator.id}>
                      {operator.name}
                    </option>
                  ))}
                </select>
              </div>
              
              <div className="space-y-2">
                <Label>Data de</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button variant="outline" className="w-full justify-start text-left font-normal">
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {dateFrom ? format(dateFrom, 'dd/MM/yyyy') : 'Selecionar'}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={dateFrom}
                      onSelect={setDateFrom}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
              </div>
              
              <div className="space-y-2">
                <Label>Data até</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button variant="outline" className="w-full justify-start text-left font-normal">
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {dateTo ? format(dateTo, 'dd/MM/yyyy') : 'Selecionar'}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={dateTo}
                      onSelect={setDateTo}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
              </div>
            </div>
            
            <div className="flex justify-end mt-4">
              <Button variant="outline" onClick={clearFilters}>
                Limpar Filtros
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Resultados */}
        <Card className="shadow-card bg-gradient-card">
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span>Inspeções Realizadas ({filteredResults.length})</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            {filteredResults.length === 0 ? (
              <div className="text-center py-12">
                <FileText className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-medium text-foreground mb-2">
                  Nenhuma inspeção encontrada
                </h3>
                <p className="text-muted-foreground">
                  Ajuste os filtros ou aguarde novas inspeções serem realizadas
                </p>
              </div>
            ) : (
              <div className="space-y-4">
                {filteredResults.map((result) => {
                  const vehicle = state.vehicles.find(v => v.id === result.vehicleId);
                  const operator = state.operators.find(o => o.id === result.operatorId);
                  const checklist = state.checklists.find(c => c.id === result.checklistId);
                  const conformeCount = result.responses.filter(r => r.answer === 'CONFORME').length;
                  const naoConformeCount = result.responses.filter(r => r.answer === 'NÃO CONFORME').length;
                  
                  return (
                    <div key={result.id} className="border rounded-lg p-4 hover:shadow-sm transition-shadow">
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center gap-3">
                          <div className="flex items-center gap-2">
                            <Truck className="w-4 h-4 text-muted-foreground" />
                            <span className="font-medium">{vehicle?.plate}</span>
                            <span className="text-sm text-muted-foreground">({vehicle?.model})</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <User className="w-4 h-4 text-muted-foreground" />
                            <span className="text-sm">{operator?.name}</span>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleViewReport(result)}
                            className="flex items-center gap-2"
                          >
                            <Eye className="w-4 h-4" />
                            Visualizar
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleExportPDF(result)}
                            className="flex items-center gap-2"
                          >
                            <BrainCircuit className="w-4 h-4 text-primary" />
                            PDF Inteligente
                          </Button>
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-sm">
                        <div>
                          <span className="text-muted-foreground">Check-list:</span>
                          <p className="font-medium">{checklist?.name}</p>
                        </div>
                        <div>
                          <span className="text-muted-foreground">Data/Hora:</span>
                          <p className="font-medium">
                            {new Date(result.createdAt).toLocaleString()}
                          </p>
                        </div>
                        <div>
                          <span className="text-muted-foreground">Resultados:</span>
                          <div className="flex gap-2 mt-1">
                            <Badge variant="default" className="bg-success text-success-foreground">
                              {conformeCount} Conforme
                            </Badge>
                            {naoConformeCount > 0 && (
                              <Badge variant="destructive">
                                {naoConformeCount} Não Conforme
                              </Badge>
                            )}
                          </div>
                        </div>
                        <div>
                          <span className="text-muted-foreground">Status:</span>
                          <p className={`font-medium ${naoConformeCount > 0 ? 'text-warning' : 'text-success'}`}>
                            {naoConformeCount > 0 ? 'Com Ocorrências' : 'Sem Ocorrências'}
                          </p>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Modal de Visualização */}
        <Dialog open={!!selectedReport} onOpenChange={() => setSelectedReport(null)}>
          <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <FileText className="w-5 h-5" />
                Visualizar Relatório de Inspeção
              </DialogTitle>
              <DialogDescription>
                Visualize os detalhes completos da inspeção realizada, incluindo respostas e fotos.
              </DialogDescription>
            </DialogHeader>
            
            {selectedReport && (
              <div className="space-y-6">
                {/* Cabeçalho da Empresa */}
                {state.headerSettings && (
                  <div className="border-b pb-6">
                    <div className="flex items-start gap-4">
                      {state.headerSettings.logo && (
                        <img 
                          src={state.headerSettings.logo} 
                          alt="Logo da empresa" 
                          className="w-16 h-16 object-contain cursor-pointer hover:opacity-75 transition-opacity"
                          onClick={() => setEnlargedImage(state.headerSettings.logo)}
                        />
                      )}
                      <div className="flex-1">
                        <h2 className="text-xl font-bold text-foreground mb-2">
                          {state.headerSettings.companyName}
                        </h2>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-sm text-muted-foreground">
                          <p><strong>CNPJ:</strong> {state.headerSettings.cnpj}</p>
                          <p><strong>Vigência:</strong> {state.headerSettings.validity}</p>
                          <p className="col-span-full"><strong>Endereço:</strong> {state.headerSettings.address}</p>
                        </div>
                        {state.headerSettings.description && (
                          <p className="mt-2 text-sm text-muted-foreground">
                            {state.headerSettings.description}
                          </p>
                        )}
                      </div>
                    </div>
                  </div>
                )}

                {/* Informações do Relatório */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <h3 className="font-semibold mb-3 flex items-center gap-2">
                      <Truck className="w-4 h-4" />
                      Informações do Veículo
                    </h3>
                    <div className="space-y-2 text-sm">
                      <p><strong>Placa:</strong> {state.vehicles.find(v => v.id === selectedReport.vehicleId)?.plate}</p>
                      <p><strong>Modelo:</strong> {state.vehicles.find(v => v.id === selectedReport.vehicleId)?.model}</p>
                      <p><strong>Categoria:</strong> {state.vehicles.find(v => v.id === selectedReport.vehicleId)?.category}</p>
                    </div>
                  </div>

                  <div>
                    <h3 className="font-semibold mb-3 flex items-center gap-2">
                      <User className="w-4 h-4" />
                      Informações do Operador
                    </h3>
                    <div className="space-y-2 text-sm">
                      <p><strong>Nome:</strong> {state.operators.find(o => o.id === selectedReport.operatorId)?.name}</p>
                      <p><strong>CPF:</strong> {state.operators.find(o => o.id === selectedReport.operatorId)?.cpf}</p>
                      <p><strong>CNH:</strong> {state.operators.find(o => o.id === selectedReport.operatorId)?.cnh}</p>
                      <p><strong>Função:</strong> {state.operators.find(o => o.id === selectedReport.operatorId)?.role}</p>
                      {selectedReport.operatorSelfie && (
                        <div className="mt-3">
                          <p className="text-xs text-muted-foreground mb-1">Selfie do operador:</p>
                          <img 
                            src={selectedReport.operatorSelfie} 
                            alt="Selfie do operador"
                            className="w-24 h-24 object-cover rounded border cursor-pointer hover:opacity-75 transition-opacity"
                            onClick={() => setEnlargedImage(selectedReport.operatorSelfie)}
                          />
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                {/* Informações da Inspeção */}
                <div>
                  <h3 className="font-semibold mb-3 flex items-center gap-2">
                    <ClipboardCheck className="w-4 h-4" />
                    Detalhes da Inspeção
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                    <p><strong>Check-list:</strong> {state.checklists.find(c => c.id === selectedReport.checklistId)?.name}</p>
                    <p><strong>Data:</strong> {new Date(selectedReport.createdAt).toLocaleDateString()}</p>
                    <p><strong>Horário:</strong> {new Date(selectedReport.createdAt).toLocaleTimeString()}</p>
                  </div>
                </div>

                {/* Respostas */}
                <div>
                  <h3 className="font-semibold mb-3">Respostas da Inspeção</h3>
                  <div className="space-y-3">
                    {selectedReport.responses.map((response: any, index: number) => {
                      const question = state.checklists
                        .find(c => c.id === selectedReport.checklistId)
                        ?.items.find(item => item.id === response.itemId);
                      
                      return (
                        <div key={response.itemId} className="border rounded-lg p-4">
                          <div className="flex items-start justify-between mb-2">
                            <h4 className="font-medium text-sm">
                              {index + 1}. {question?.question}
                            </h4>
                            <Badge variant={response.answer === 'CONFORME' ? 'default' : 'destructive'}>
                              {response.answer}
                            </Badge>
                          </div>
                           {response.photo && (
                            <div className="mt-2">
                              <p className="text-xs text-muted-foreground mb-1">Foto anexada:</p>
                              <img 
                                src={response.photo} 
                                alt={`Foto da pergunta ${index + 1}`}
                                className="w-32 h-32 object-cover rounded border cursor-pointer hover:opacity-75 transition-opacity"
                                onClick={() => setEnlargedImage(response.photo)}
                              />
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Opções de IA */}
                <div className="mt-6 pt-4 border-t">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-2">
                      <div className="flex items-center space-x-2">
                        <input
                          type="checkbox"
                          id="ai-analysis"
                          checked={includeAIAnalysis}
                          onChange={(e) => setIncludeAIAnalysis(e.target.checked)}
                          className="h-4 w-4 rounded border-gray-300 text-primary focus:ring-primary"
                        />
                        <label htmlFor="ai-analysis" className="text-sm font-medium text-muted-foreground cursor-pointer">
                          Incluir análise inteligente com IA no relatório PDF
                        </label>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Botões de Ação */}
                <div className="flex justify-end gap-2 pt-4 border-t">
                  <Button
                    variant="outline"
                    onClick={() => setSelectedReport(null)}
                  >
                    Fechar
                  </Button>
                  <Button
                    onClick={() => handleExportPDF(selectedReport)}
                    className="flex items-center gap-2"
                    disabled={isExportingPDF}
                  >
                    <FileDown className="w-4 h-4" />
                    {isExportingPDF ? 'Gerando...' : 'Baixar PDF'}
                  </Button>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>

        {/* Modal de Imagem Ampliada */}
        <Dialog open={!!enlargedImage} onOpenChange={() => setEnlargedImage(null)}>
          <DialogContent className="max-w-4xl max-h-[90vh] p-0">
            <DialogHeader className="p-6 pb-3">
              <DialogTitle className="flex items-center justify-between">
                <span className="flex items-center gap-2">
                  <ZoomIn className="w-5 h-5" />
                  Imagem Ampliada
                </span>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setEnlargedImage(null)}
                  className="h-8 w-8 p-0"
                >
                  <X className="w-4 h-4" />
                </Button>
              </DialogTitle>
              <DialogDescription>
                Visualização ampliada da imagem selecionada.
              </DialogDescription>
            </DialogHeader>
            
            {enlargedImage && (
              <div className="flex items-center justify-center p-6 pt-0">
                <img 
                  src={enlargedImage} 
                  alt="Imagem ampliada"
                  className="max-w-full max-h-[70vh] object-contain rounded-lg shadow-lg"
                />
              </div>
            )}
          </DialogContent>
        </Dialog>
      </div>
    </AdminLayout>
  );
};

export default Reports;
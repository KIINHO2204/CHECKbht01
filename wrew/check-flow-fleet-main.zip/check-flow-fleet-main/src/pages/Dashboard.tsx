import { memo, useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { useApp } from '@/contexts/AppContext';
import AdminLayout from '@/components/AdminLayout';
import { Link } from 'react-router-dom';
import { 
  Truck, 
  Users, 
  AlertTriangle, 
  CheckCircle, 
  TrendingUp, 
  TrendingDown,
  Car,
  UserPlus,
  ClipboardList,
  FileText,
  Settings,
  Activity,
  Calendar,
  Clock,
  Shield,
  BarChart3,
  Eye,
  Timer,
  Target,
  Zap,
  ArrowRight,
  Gauge,
  Award,
  MapPin
} from 'lucide-react';

// Enhanced Metric Card Component
const EnhancedMetricCard = memo(({ 
  title, 
  value, 
  description, 
  icon: Icon, 
  trend, 
  trendValue,
  color = "primary",
  actionHref,
  actionLabel
}: {
  title: string;
  value: string | number;
  description: string;
  icon: any;
  trend?: 'up' | 'down' | 'neutral';
  trendValue?: string;
  color?: string;
  actionHref?: string;
  actionLabel?: string;
}) => (
  <Card className="shadow-card bg-gradient-card hover:shadow-elevated transition-all duration-300 hover:scale-[1.02] group">
    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-3">
      <div className="space-y-1">
        <CardTitle className="text-sm font-medium text-muted-foreground">{title}</CardTitle>
        <div className={`text-3xl font-bold text-${color} group-hover:text-${color}/80 transition-colors`}>
          {value}
        </div>
      </div>
      <div className={`p-3 rounded-xl bg-${color}/10 group-hover:bg-${color}/20 transition-colors`}>
        <Icon className={`h-6 w-6 text-${color}`} />
      </div>
    </CardHeader>
    <CardContent className="pt-0">
      <div className="flex items-center justify-between">
        <div className="space-y-1">
          <p className="text-xs text-muted-foreground">{description}</p>
          {trend && trendValue && (
            <div className={`flex items-center gap-1 text-xs ${
              trend === 'up' ? 'text-success' : trend === 'down' ? 'text-destructive' : 'text-muted-foreground'
            }`}>
              {trend === 'up' ? <TrendingUp className="w-3 h-3" /> : 
               trend === 'down' ? <TrendingDown className="w-3 h-3" /> : 
               <Gauge className="w-3 h-3" />}
              <span>{trendValue}</span>
            </div>
          )}
        </div>
        {actionHref && (
          <Button variant="ghost" size="sm" asChild className="opacity-0 group-hover:opacity-100 transition-opacity">
            <Link to={actionHref}>
              <ArrowRight className="w-4 h-4" />
            </Link>
          </Button>
        )}
      </div>
    </CardContent>
  </Card>
));

EnhancedMetricCard.displayName = 'EnhancedMetricCard';

// Performance Analytics Component
const PerformanceAnalytics = memo(({ title, data }: { 
  title: string; 
  data: Array<{ label: string; value: string | number; color: string; percentage: number }> 
}) => (
  <Card className="shadow-card bg-gradient-card">
    <CardHeader>
      <CardTitle className="flex items-center gap-2">
        <BarChart3 className="w-5 h-5 text-primary" />
        {title}
      </CardTitle>
    </CardHeader>
    <CardContent>
      <div className="space-y-4">
        {data.map((item, index) => (
          <div key={index} className="space-y-2">
            <div className="flex items-center justify-between text-sm">
              <span className="font-medium">{item.label}</span>
              <span className={`font-bold ${item.color}`}>{item.value}</span>
            </div>
            <Progress value={item.percentage} className="h-2" />
          </div>
        ))}
      </div>
    </CardContent>
  </Card>
));

PerformanceAnalytics.displayName = 'PerformanceAnalytics';

// Quick Actions Grid Component
const QuickActionsGrid = memo(() => {
  const quickActions = [
    {
      title: "Nova Inspeção",
      description: "Iniciar check-list",
      icon: ClipboardList,
      href: "/chat",
      color: "bg-gradient-to-br from-primary to-primary/80",
      priority: "high"
    },
    {
      title: "Cadastrar Veículo",
      description: "Adicionar à frota",
      icon: Car,
      href: "/vehicles",
      color: "bg-gradient-to-br from-blue-500 to-blue-600",
      priority: "medium"
    },
    {
      title: "Novo Operador",
      description: "Adicionar membro",
      icon: UserPlus,
      href: "/operators",
      color: "bg-gradient-to-br from-green-500 to-green-600",
      priority: "medium"
    },
    {
      title: "Ver Relatórios",
      description: "Análises detalhadas",
      icon: BarChart3,
      href: "/reports",
      color: "bg-gradient-to-br from-purple-500 to-purple-600",
      priority: "low"
    }
  ];

  return (
    <Card className="shadow-card bg-gradient-card">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Zap className="w-5 h-5 text-primary" />
          Ações Rápidas
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {quickActions.map((action, index) => (
            <Button
              key={index}
              asChild
              className={`
                ${action.color} text-white border-0 h-auto p-4 
                hover:scale-105 hover:shadow-lg transition-all duration-200
                group relative overflow-hidden
              `}
            >
              <Link to={action.href}>
                <div className="flex items-center gap-3 w-full">
                  <div className="p-2 bg-white/20 rounded-lg">
                    <action.icon className="w-5 h-5" />
                  </div>
                  <div className="text-left flex-1">
                    <div className="font-semibold">{action.title}</div>
                    <div className="text-sm opacity-90">{action.description}</div>
                  </div>
                  <ArrowRight className="w-4 h-4 opacity-0 group-hover:opacity-100 transition-opacity" />
                </div>
                {action.priority === 'high' && (
                  <div className="absolute top-2 right-2">
                    <div className="w-2 h-2 bg-yellow-300 rounded-full animate-pulse" />
                  </div>
                )}
              </Link>
            </Button>
          ))}
        </div>
      </CardContent>
    </Card>
  );
});

QuickActionsGrid.displayName = 'QuickActionsGrid';

// Recent Activity Feed Component
const RecentActivityFeed = memo(() => {
  const { state, resolveOccurrence } = useApp();

  const recentActivities = useMemo(() => {
    const activities = [];
    
    // Add recent checklist results
    state.checklistResults.slice(0, 3).forEach(result => {
      const vehicle = state.vehicles.find(v => v.id === result.vehicleId);
      const operator = state.operators.find(o => o.id === result.operatorId);
      activities.push({
        id: result.id,
        type: 'inspection',
        title: 'Inspeção Concluída',
        description: `${operator?.name} completou inspeção do veículo ${vehicle?.plate}`,
        time: result.createdAt,
        icon: CheckCircle,
        color: 'text-success'
      });
    });

    // Add recent occurrences
    state.occurrences.slice(0, 2).forEach(occurrence => {
      const vehicle = state.vehicles.find(v => v.id === occurrence.vehicleId);
      const operator = state.operators.find(o => o.id === occurrence.operatorId);
      activities.push({
        id: occurrence.id,
        type: 'occurrence',
        title: occurrence.status === 'pending' ? 'Nova Ocorrência' : 'Ocorrência Resolvida',
        description: `${operator?.name} - ${vehicle?.plate}: ${occurrence.description}`,
        time: occurrence.createdAt,
        icon: occurrence.status === 'pending' ? AlertTriangle : CheckCircle,
        color: occurrence.status === 'pending' ? 'text-warning' : 'text-success',
        status: occurrence.status,
        action: occurrence.status === 'pending' ? () => resolveOccurrence(occurrence.id) : undefined
      });
    });

    return activities.sort((a, b) => new Date(b.time).getTime() - new Date(a.time).getTime()).slice(0, 5);
  }, [state, resolveOccurrence]);

  return (
    <Card className="shadow-card bg-gradient-card">
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Activity className="w-5 h-5 text-primary" />
            Atividade Recente
          </div>
          <Button variant="ghost" size="sm" asChild>
            <Link to="/reports">
              <span className="text-xs">Ver Tudo</span>
              <ArrowRight className="w-3 h-3 ml-1" />
            </Link>
          </Button>
        </CardTitle>
      </CardHeader>
      <CardContent>
        {recentActivities.length === 0 ? (
          <div className="text-center py-8">
            <Activity className="w-8 h-8 text-muted-foreground mx-auto mb-2 opacity-50" />
            <p className="text-sm text-muted-foreground">Nenhuma atividade recente</p>
          </div>
        ) : (
          <div className="space-y-4">
            {recentActivities.map((activity) => (
              <div key={activity.id} className="flex items-start gap-3 p-3 rounded-lg hover:bg-muted/50 transition-colors">
                <div className={`p-2 rounded-full bg-${activity.color.replace('text-', '')}/10`}>
                  <activity.icon className={`w-4 h-4 ${activity.color}`} />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <p className="text-sm font-medium truncate">{activity.title}</p>
                    <div className="flex items-center gap-2">
                      {activity.action && (
                        <Button size="sm" variant="outline" onClick={activity.action}>
                          Resolver
                        </Button>
                      )}
                      <span className="text-xs text-muted-foreground">
                        {new Date(activity.time).toLocaleTimeString()}
                      </span>
                    </div>
                  </div>
                  <p className="text-xs text-muted-foreground mt-1 truncate">{activity.description}</p>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
});

RecentActivityFeed.displayName = 'RecentActivityFeed';

const Dashboard = memo(() => {
  const { 
    state, 
    pendingOccurrences, 
    resolvedOccurrences, 
    topOperator, 
    bottomOperator
  } = useApp();

  const totalVehicles = state.vehicles.length;
  const totalOperators = state.operators.length;
  const totalInspections = state.checklistResults.length;

  // Calculate analytics data
  const analyticsData = useMemo(() => {
    const totalOccurrences = state.occurrences.length;
    const successRate = totalOccurrences > 0 ? ((resolvedOccurrences / totalOccurrences) * 100).toFixed(1) : '100';
    const avgInspectionsPerOperator = totalOperators > 0 ? Math.round(totalInspections / totalOperators) : 0;
    
    return {
      complianceRate: parseFloat(successRate),
      efficiencyScore: Math.min(100, avgInspectionsPerOperator * 10),
      alertsToday: state.occurrences.filter(o => {
        const today = new Date().toDateString();
        return new Date(o.createdAt).toDateString() === today;
      }).length
    };
  }, [state, resolvedOccurrences, totalInspections, totalOperators]);

  const performanceData = [
    { 
      label: 'Taxa de Conformidade', 
      value: `${analyticsData.complianceRate}%`, 
      color: 'text-success', 
      percentage: analyticsData.complianceRate 
    },
    { 
      label: 'Ocorrências Pendentes', 
      value: pendingOccurrences, 
      color: 'text-warning', 
      percentage: totalInspections > 0 ? (pendingOccurrences / totalInspections) * 100 : 0 
    },
    { 
      label: 'Inspeções por Operador', 
      value: `${Math.round(totalInspections / Math.max(totalOperators, 1))}`, 
      color: 'text-info', 
      percentage: Math.min(100, (totalInspections / Math.max(totalOperators, 1)) * 5) 
    }
  ];

  return (
    <AdminLayout currentPage="dashboard">
      <div className="space-y-6">
        {/* Enhanced Header */}
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4">
          <div className="space-y-1">
            <h1 className="text-4xl font-bold tracking-tight bg-gradient-to-r from-primary to-primary/70 bg-clip-text text-transparent">
              Dashboard Executivo
            </h1>
            <p className="text-muted-foreground text-lg">
              Visão estratégica e controle operacional completo
            </p>
          </div>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 px-3 py-2 bg-card rounded-lg border">
              <Calendar className="w-4 h-4 text-primary" />
              <span className="text-sm font-medium">{new Date().toLocaleDateString('pt-BR', { 
                weekday: 'long', 
                year: 'numeric', 
                month: 'long', 
                day: 'numeric' 
              })}</span>
            </div>
            <div className="flex items-center gap-2 px-3 py-2 bg-success/10 text-success rounded-lg">
              <div className="w-2 h-2 bg-success rounded-full animate-pulse" />
              <span className="text-sm font-medium">Sistema Online</span>
            </div>
          </div>
        </div>

        {/* Key Performance Indicators */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <EnhancedMetricCard
            title="Frota Total"
            value={totalVehicles}
            description="Veículos em operação"
            icon={Truck}
            trend="neutral"
            trendValue="Ativo"
            color="primary"
            actionHref="/vehicles"
            actionLabel="Gerenciar"
          />
          
          <EnhancedMetricCard
            title="Equipe Operacional"
            value={totalOperators}
            description="Operadores certificados"
            icon={Users}
            trend="up"
            trendValue="+2 este mês"
            color="blue-500"
            actionHref="/operators"
            actionLabel="Ver Equipe"
          />
          
          <EnhancedMetricCard
            title="Inspeções Realizadas"
            value={totalInspections}
            description="Total de verificações"
            icon={Shield}
            trend="up"
            trendValue={`${Math.round(totalInspections / Math.max(totalOperators, 1))} por operador`}
            color="green-500"
            actionHref="/reports"
            actionLabel="Relatórios"
          />
          
          <EnhancedMetricCard
            title="Alertas Ativos"
            value={pendingOccurrences}
            description="Requerem atenção imediata"
            icon={AlertTriangle}
            trend={pendingOccurrences > 0 ? "down" : "neutral"}
            trendValue={pendingOccurrences > 0 ? "Ação necessária" : "Tudo ok"}
            color={pendingOccurrences > 0 ? "destructive" : "success"}
            actionHref="/occurrences"
            actionLabel="Resolver"
          />
        </div>

        {/* Secondary Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <EnhancedMetricCard
            title="Taxa de Resolução"
            value={`${((resolvedOccurrences / Math.max(state.occurrences.length, 1)) * 100).toFixed(1)}%`}
            description="Ocorrências resolvidas"
            icon={Target}
            trend="up"
            trendValue="Excelente"
            color="success"
          />
          
          <EnhancedMetricCard
            title="Operador Destaque"
            value={topOperator?.name || 'N/A'}
            description={`${topOperator?.inspectionsCount || 0} inspeções realizadas`}
            icon={Award}
            trend="up"
            trendValue="Top performer"
            color="yellow-500"
          />
          
          <EnhancedMetricCard
            title="Próxima Manutenção"
            value="3 dias"
            description="Veículo ABC-1234"
            icon={Timer}
            trend="neutral"
            trendValue="Programada"
            color="orange-500"
          />
        </div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Performance Analytics */}
          <div className="lg:col-span-1">
            <PerformanceAnalytics title="Indicadores de Performance" data={performanceData} />
          </div>

          {/* Quick Actions */}
          <div className="lg:col-span-1">
            <QuickActionsGrid />
          </div>

          {/* Recent Activity */}
          <div className="lg:col-span-1">
            <RecentActivityFeed />
          </div>
        </div>

        {/* Critical Alerts Section */}
        {pendingOccurrences > 0 && (
          <Card className="shadow-card bg-gradient-to-r from-destructive/5 to-warning/5 border-l-4 border-l-destructive">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-destructive">
                <AlertTriangle className="w-5 h-5 animate-pulse" />
                Atenção: {pendingOccurrences} Ocorrência{pendingOccurrences > 1 ? 's' : ''} Pendente{pendingOccurrences > 1 ? 's' : ''}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <p className="text-sm text-muted-foreground">
                  Existem ocorrências que requerem ação imediata da equipe de gestão.
                </p>
                <Button asChild className="bg-destructive hover:bg-destructive/90">
                  <Link to="/occurrences">
                    <AlertTriangle className="w-4 h-4 mr-2" />
                    Revisar Agora
                  </Link>
                </Button>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </AdminLayout>
  );
});

Dashboard.displayName = 'Dashboard';

export default Dashboard;
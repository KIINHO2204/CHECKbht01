import { useState, useMemo, memo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger,
  DialogDescription 
} from '@/components/ui/dialog';
import { useApp } from '@/contexts/AppContext';
import AdminLayout from '@/components/AdminLayout';
import { exportToCSV } from '@/utils/exportData';
import { 
  AlertTriangle, 
  CheckCircle, 
  Search,
  Filter,
  Download,
  Calendar,
  Truck,
  User,
  ClipboardList,
  Eye,
  MessageSquare,
  Clock,
  X,
  ZoomIn
} from 'lucide-react';
import { toast } from '@/hooks/use-toast';

const OccurrenceCard = memo(({ occurrence, onResolve, onViewDetails, onEnlargeImage }: {
  occurrence: any;
  onResolve: (id: string, notes?: string) => void;
  onViewDetails: (occurrence: any) => void;
  onEnlargeImage: (imageUrl: string) => void;
}) => {
  const { state } = useApp();
  const vehicle = state.vehicles.find(v => v.id === occurrence.vehicleId);
  const operator = state.operators.find(o => o.id === occurrence.operatorId);
  const checklist = state.checklists.find(c => c.id === occurrence.checklistId);
  const checklistItem = checklist?.items.find(i => i.id === occurrence.itemId);

  return (
    <Card className={`shadow-card transition-all duration-200 hover:shadow-elevated ${
      occurrence.status === 'pending' 
        ? 'bg-gradient-to-r from-warning/5 to-background border-l-4 border-l-warning' 
        : 'bg-gradient-card'
    }`}>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <Badge variant={occurrence.status === 'pending' ? 'destructive' : 'default'}>
            {occurrence.status === 'pending' ? 'Pendente' : 'Resolvida'}
          </Badge>
          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onViewDetails(occurrence)}
              className="hover:bg-primary/10"
              aria-label="Ver detalhes"
            >
              <Eye className="w-4 h-4" />
            </Button>
            {occurrence.status === 'pending' && (
              <Button
                variant="outline"
                size="sm"
                onClick={() => onResolve(occurrence.id)}
                className="hover:bg-success/10 hover:border-success hover:text-success"
              >
                <CheckCircle className="w-4 h-4 mr-1" />
                Resolver
              </Button>
            )}
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Truck className="w-4 h-4 text-muted-foreground" />
              <span className="font-medium">{vehicle?.plate}</span>
            </div>
            <span className="text-xs text-muted-foreground">
              {new Date(occurrence.createdAt).toLocaleDateString()}
            </span>
          </div>
          
          <div className="bg-muted/50 p-3 rounded-lg">
            <p className="text-sm text-muted-foreground">{occurrence.description}</p>
          </div>
          
          {occurrence.photo && (
            <img 
              src={occurrence.photo} 
              alt="Foto da não conformidade"
              className="w-full h-20 object-cover rounded-lg border cursor-pointer hover:opacity-75 transition-opacity"
              onClick={() => onEnlargeImage(occurrence.photo)}
            />
          )}
        </div>
      </CardContent>
    </Card>
  );
});

OccurrenceCard.displayName = 'OccurrenceCard';

const OccurrenceDetails = memo(({ occurrence, onClose }: {
  occurrence: any;
  onClose: () => void;
}) => {
  const { state } = useApp();
  const [enlargedImage, setEnlargedImage] = useState<string | null>(null);
  const vehicle = state.vehicles.find(v => v.id === occurrence.vehicleId);
  const operator = state.operators.find(o => o.id === occurrence.operatorId);
  const checklist = state.checklists.find(c => c.id === occurrence.checklistId);
  const checklistItem = checklist?.items.find(i => i.id === occurrence.itemId);

  return (
    <Dialog open={true} onOpenChange={() => onClose()}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-warning" />
            Detalhes da Ocorrência
          </DialogTitle>
          <DialogDescription>
            Visualize informações detalhadas sobre a ocorrência selecionada.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label className="text-sm font-medium text-muted-foreground">Status</Label>
              <Badge 
                variant={occurrence.status === 'pending' ? 'destructive' : 'default'}
                className="mt-1"
              >
                {occurrence.status === 'pending' ? 'Pendente' : 'Resolvida'}
              </Badge>
            </div>
            <div>
              <Label className="text-sm font-medium text-muted-foreground">ID</Label>
              <p className="text-sm font-mono">{occurrence.id}</p>
            </div>
          </div>
          
          <div>
            <Label className="text-sm font-medium text-muted-foreground">Veículo</Label>
            <p className="text-sm">{vehicle?.plate} - {vehicle?.model} ({vehicle?.category})</p>
          </div>
          
          <div>
            <Label className="text-sm font-medium text-muted-foreground">Operador</Label>
            <p className="text-sm">{operator?.name} ({operator?.role})</p>
          </div>
          
          <div>
            <Label className="text-sm font-medium text-muted-foreground">Check-list</Label>
            <p className="text-sm">{checklist?.name}</p>
          </div>
          
          <div>
            <Label className="text-sm font-medium text-muted-foreground">Item do Check-list</Label>
            <p className="text-sm">{checklistItem?.question}</p>
          </div>
          
          <div>
            <Label className="text-sm font-medium text-muted-foreground">Descrição</Label>
            <div className="bg-muted/50 p-3 rounded-lg">
              <p className="text-sm">{occurrence.description}</p>
            </div>
          </div>
          
          {occurrence.photo && (
            <div>
              <Label className="text-sm font-medium text-muted-foreground">Foto da Não Conformidade</Label>
              <img 
                src={occurrence.photo} 
                alt="Foto da não conformidade"
                className="w-full h-32 object-cover rounded-lg border mt-1 cursor-pointer hover:opacity-75 transition-opacity"
                onClick={() => setEnlargedImage(occurrence.photo)}
              />
            </div>
          )}
          
          <div className="grid grid-cols-2 gap-4 text-sm text-muted-foreground">
            <div>
              <Label className="text-sm font-medium text-muted-foreground">Criado em</Label>
              <p>{new Date(occurrence.createdAt).toLocaleString()}</p>
            </div>
            {occurrence.resolvedAt && (
              <div>
                <Label className="text-sm font-medium text-muted-foreground">Resolvido em</Label>
                <p>{new Date(occurrence.resolvedAt).toLocaleString()}</p>
              </div>
            )}
          </div>
        </div>
      </DialogContent>
      
      {/* Modal de Imagem Ampliada */}
      <Dialog open={!!enlargedImage} onOpenChange={() => setEnlargedImage(null)}>
        <DialogContent className="max-w-4xl max-h-[90vh] p-0">
          <DialogHeader className="p-6 pb-3">
            <DialogTitle className="flex items-center justify-between">
              <span className="flex items-center gap-2">
                <ZoomIn className="w-5 h-5" />
                Foto da Não Conformidade
              </span>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setEnlargedImage(null)}
                className="h-8 w-8 p-0"
              >
                <X className="w-4 h-4" />
              </Button>
            </DialogTitle>
            <DialogDescription>
              Visualização ampliada da foto da não conformidade.
            </DialogDescription>
          </DialogHeader>
          
          {enlargedImage && (
            <div className="flex items-center justify-center p-6 pt-0">
              <img 
                src={enlargedImage} 
                alt="Foto da não conformidade ampliada"
                className="max-w-full max-h-[70vh] object-contain rounded-lg shadow-lg"
              />
            </div>
          )}
        </DialogContent>
      </Dialog>
    </Dialog>
  );
});

OccurrenceDetails.displayName = 'OccurrenceDetails';

const OccurrenceManagement = () => {
  const { state, resolveOccurrence } = useApp();
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [vehicleFilter, setVehicleFilter] = useState('all');
  const [selectedOccurrence, setSelectedOccurrence] = useState<any>(null);
  const [resolutionNotes, setResolutionNotes] = useState('');
  const [showResolutionDialog, setShowResolutionDialog] = useState(false);
  const [occurrenceToResolve, setOccurrenceToResolve] = useState<string>('');
  const [enlargedImage, setEnlargedImage] = useState<string | null>(null);

  // Estatísticas
  const stats = useMemo(() => {
    const total = state.occurrences.length;
    const pending = state.occurrences.filter(o => o.status === 'pending').length;
    const resolved = state.occurrences.filter(o => o.status === 'resolved').length;
    const todayCount = state.occurrences.filter(o => {
      const today = new Date();
      const occurrenceDate = new Date(o.createdAt);
      return occurrenceDate.toDateString() === today.toDateString();
    }).length;

    return { total, pending, resolved, todayCount };
  }, [state.occurrences]);

  // Filtrar ocorrências
  const filteredOccurrences = useMemo(() => {
    return state.occurrences.filter(occurrence => {
      const vehicle = state.vehicles.find(v => v.id === occurrence.vehicleId);
      const operator = state.operators.find(o => o.id === occurrence.operatorId);
      
      const matchesSearch = !searchTerm || 
        vehicle?.plate.toLowerCase().includes(searchTerm.toLowerCase()) ||
        operator?.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        occurrence.description.toLowerCase().includes(searchTerm.toLowerCase());
      
      const matchesStatus = statusFilter === 'all' || occurrence.status === statusFilter;
      const matchesVehicle = vehicleFilter === 'all' || occurrence.vehicleId === vehicleFilter;

      return matchesSearch && matchesStatus && matchesVehicle;
    }).sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }, [state, searchTerm, statusFilter, vehicleFilter]);

  // Separar ocorrências por status
  const pendingOccurrences = useMemo(() => {
    return filteredOccurrences.filter(o => o.status === 'pending');
  }, [filteredOccurrences]);

  const resolvedOccurrences = useMemo(() => {
    return filteredOccurrences.filter(o => o.status === 'resolved');
  }, [filteredOccurrences]);

  const handleResolve = (id: string, notes?: string) => {
    setOccurrenceToResolve(id);
    setShowResolutionDialog(true);
  };

  const confirmResolve = () => {
    resolveOccurrence(occurrenceToResolve);
    setShowResolutionDialog(false);
    setOccurrenceToResolve('');
    setResolutionNotes('');
    toast({
      title: "Ocorrência resolvida",
      description: "A ocorrência foi marcada como resolvida.",
    });
  };

  const handleExport = () => {
    const exportData = filteredOccurrences.map(occurrence => {
      const vehicle = state.vehicles.find(v => v.id === occurrence.vehicleId);
      const operator = state.operators.find(o => o.id === occurrence.operatorId);
      
      return {
        id: occurrence.id,
        data_criacao: new Date(occurrence.createdAt).toLocaleDateString(),
        hora_criacao: new Date(occurrence.createdAt).toLocaleTimeString(),
        placa: vehicle?.plate || 'N/A',
        modelo: vehicle?.model || 'N/A',
        operador: operator?.name || 'N/A',
        descricao: occurrence.description,
        status: occurrence.status === 'pending' ? 'Pendente' : 'Resolvida',
        data_resolucao: occurrence.resolvedAt ? new Date(occurrence.resolvedAt).toLocaleDateString() : 'N/A'
      };
    });

    exportToCSV(exportData, 'relatorio-ocorrencias');
    toast({
      title: "Exportação realizada",
      description: "Relatório de ocorrências exportado com sucesso.",
    });
  };

  const clearFilters = () => {
    setSearchTerm('');
    setStatusFilter('all');
    setVehicleFilter('all');
  };

  return (
    <AdminLayout currentPage="occurrences">
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-gradient-primary rounded-lg">
              <AlertTriangle className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2 className="text-2xl font-bold text-foreground">Gestão de Ocorrências</h2>
              <p className="text-sm text-muted-foreground">
                Monitore e resolva as ocorrências identificadas nas inspeções
              </p>
            </div>
          </div>
          
          <Button 
            onClick={handleExport}
            className="bg-gradient-primary hover:opacity-90 flex items-center gap-2"
            disabled={filteredOccurrences.length === 0}
          >
            <Download className="w-4 h-4" />
            Exportar CSV
          </Button>
        </div>

        {/* Estatísticas */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <Card className="shadow-card bg-gradient-card">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Total</p>
                  <p className="text-2xl font-bold text-primary">{stats.total}</p>
                </div>
                <AlertTriangle className="h-8 w-8 text-primary" />
              </div>
            </CardContent>
          </Card>
          
          <Card className="shadow-card bg-gradient-card">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Pendentes</p>
                  <p className="text-2xl font-bold text-destructive">{stats.pending}</p>
                </div>
                <Clock className="h-8 w-8 text-destructive" />
              </div>
            </CardContent>
          </Card>
          
          <Card className="shadow-card bg-gradient-card">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Resolvidas</p>
                  <p className="text-2xl font-bold text-success">{stats.resolved}</p>
                </div>
                <CheckCircle className="h-8 w-8 text-success" />
              </div>
            </CardContent>
          </Card>
          
          <Card className="shadow-card bg-gradient-card">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Hoje</p>
                  <p className="text-2xl font-bold text-info">{stats.todayCount}</p>
                </div>
                <Calendar className="h-8 w-8 text-info" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Filtros */}
        <Card className="shadow-card bg-gradient-card">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Filter className="w-5 h-5" />
              Filtros
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label>Buscar</Label>
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
                  <Input
                    placeholder="Placa, operador ou descrição..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <Label>Status</Label>
                <select
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value)}
                  className="w-full p-2 border border-input rounded-md bg-background text-sm"
                >
                  <option value="all">Todos os status</option>
                  <option value="pending">Pendentes</option>
                  <option value="resolved">Resolvidas</option>
                </select>
              </div>
              
              <div className="space-y-2">
                <Label>Veículo</Label>
                <select
                  value={vehicleFilter}
                  onChange={(e) => setVehicleFilter(e.target.value)}
                  className="w-full p-2 border border-input rounded-md bg-background text-sm"
                >
                  <option value="all">Todos os veículos</option>
                  {state.vehicles.map(vehicle => (
                    <option key={vehicle.id} value={vehicle.id}>
                      {vehicle.plate} - {vehicle.model}
                    </option>
                  ))}
                </select>
              </div>
            </div>
            
            <div className="flex justify-end mt-4">
              <Button variant="outline" onClick={clearFilters}>
                Limpar Filtros
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Tabs de Ocorrências */}
        <Tabs defaultValue="pending" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="pending" className="flex items-center gap-2">
              <Clock className="w-4 h-4" />
              Pendentes ({stats.pending})
            </TabsTrigger>
            <TabsTrigger value="resolved" className="flex items-center gap-2">
              <CheckCircle className="w-4 h-4" />
              Resolvidas ({stats.resolved})
            </TabsTrigger>
          </TabsList>
          
          {/* Aba Pendentes */}
          <TabsContent value="pending">
            <div className="space-y-4">
              {pendingOccurrences.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                   {pendingOccurrences.map((occurrence) => (
                     <OccurrenceCard
                       key={occurrence.id}
                       occurrence={occurrence}
                       onResolve={handleResolve}
                       onViewDetails={setSelectedOccurrence}
                       onEnlargeImage={setEnlargedImage}
                     />
                   ))}
                </div>
              ) : (
                <Card className="shadow-card bg-gradient-card">
                  <CardContent className="py-12 text-center">
                    {searchTerm || statusFilter !== 'all' || vehicleFilter !== 'all' ? (
                      <>
                        <Search className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                        <h3 className="text-lg font-medium text-foreground mb-2">
                          Nenhuma ocorrência pendente encontrada
                        </h3>
                        <p className="text-muted-foreground mb-4">
                          Tente ajustar os filtros de busca
                        </p>
                        <Button variant="outline" onClick={clearFilters}>
                          Limpar filtros
                        </Button>
                      </>
                    ) : (
                      <>
                        <CheckCircle className="w-12 h-12 text-success mx-auto mb-4" />
                        <h3 className="text-lg font-medium text-foreground mb-2">
                          Nenhuma ocorrência pendente
                        </h3>
                        <p className="text-muted-foreground">
                          Tudo funcionando perfeitamente! 🎉
                        </p>
                      </>
                    )}
                  </CardContent>
                </Card>
              )}
            </div>
          </TabsContent>
          
          {/* Aba Resolvidas */}
          <TabsContent value="resolved">
            <div className="space-y-4">
              {resolvedOccurrences.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                   {resolvedOccurrences.map((occurrence) => (
                     <OccurrenceCard
                       key={occurrence.id}
                       occurrence={occurrence}
                       onResolve={handleResolve}
                       onViewDetails={setSelectedOccurrence}
                       onEnlargeImage={setEnlargedImage}
                     />
                   ))}
                </div>
              ) : (
                <Card className="shadow-card bg-gradient-card">
                  <CardContent className="py-12 text-center">
                    {searchTerm || statusFilter !== 'all' || vehicleFilter !== 'all' ? (
                      <>
                        <Search className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                        <h3 className="text-lg font-medium text-foreground mb-2">
                          Nenhuma ocorrência resolvida encontrada
                        </h3>
                        <p className="text-muted-foreground mb-4">
                          Tente ajustar os filtros de busca
                        </p>
                        <Button variant="outline" onClick={clearFilters}>
                          Limpar filtros
                        </Button>
                      </>
                    ) : (
                      <>
                        <AlertTriangle className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                        <h3 className="text-lg font-medium text-foreground mb-2">
                          Nenhuma ocorrência resolvida
                        </h3>
                        <p className="text-muted-foreground">
                          Ainda não há ocorrências resolvidas no sistema.
                        </p>
                      </>
                    )}
                  </CardContent>
                </Card>
              )}
            </div>
          </TabsContent>
        </Tabs>

        {/* Dialog de Resolução */}
        <Dialog open={showResolutionDialog} onOpenChange={setShowResolutionDialog}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <CheckCircle className="w-5 h-5 text-success" />
                Resolver Ocorrência
              </DialogTitle>
              <DialogDescription>
                Marque esta ocorrência como resolvida e adicione notas se necessário.
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <p className="text-sm text-muted-foreground">
                Confirma que esta ocorrência foi resolvida?
              </p>
              <div className="space-y-2">
                <Label htmlFor="notes">Observações (opcional)</Label>
                <Textarea
                  id="notes"
                  placeholder="Descreva como a ocorrência foi resolvida..."
                  value={resolutionNotes}
                  onChange={(e) => setResolutionNotes(e.target.value)}
                />
              </div>
              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setShowResolutionDialog(false)}>
                  Cancelar
                </Button>
                <Button onClick={confirmResolve} className="bg-gradient-success hover:opacity-90">
                  Marcar como Resolvida
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>

        {/* Dialog de Detalhes */}
        {selectedOccurrence && (
          <OccurrenceDetails
            occurrence={selectedOccurrence}
            onClose={() => setSelectedOccurrence(null)}
          />
        )}
        
        {/* Modal de Imagem Ampliada */}
        <Dialog open={!!enlargedImage} onOpenChange={() => setEnlargedImage(null)}>
          <DialogContent className="max-w-4xl max-h-[90vh] p-0">
          <DialogHeader className="p-6 pb-3">
            <DialogTitle className="flex items-center justify-between">
              <span className="flex items-center gap-2">
                <ZoomIn className="w-5 h-5" />
                Foto da Não Conformidade
              </span>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setEnlargedImage(null)}
                className="h-8 w-8 p-0"
              >
                <X className="w-4 h-4" />
              </Button>
            </DialogTitle>
            <DialogDescription>
              Visualização ampliada da foto da não conformidade.
            </DialogDescription>
          </DialogHeader>
            
            {enlargedImage && (
              <div className="flex items-center justify-center p-6 pt-0">
                <img 
                  src={enlargedImage} 
                  alt="Foto da não conformidade ampliada"
                  className="max-w-full max-h-[70vh] object-contain rounded-lg shadow-lg"
                />
              </div>
            )}
          </DialogContent>
        </Dialog>
      </div>
    </AdminLayout>
  );
};

export default OccurrenceManagement;